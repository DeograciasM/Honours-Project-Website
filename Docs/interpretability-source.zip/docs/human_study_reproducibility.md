# Human-study stimulus reproducibility audit

## Conclusion

The deployed 512-token, 40%-budget, seed-44 stimulus package survives and is internally verifiable, but its exact generating script and four pre-regeneration canonical input files could not be recovered. Full byte-for-byte regeneration from source is therefore not currently possible. No replacement builder has been invented.

## What survives

- `outputs/human_study_final/forms_512_40_seed44/` contains 60 deployed PNGs, `forms_setup_guide.csv`, `replacement_report.csv`, `QA.md`, and `provenance.json` (64 files total).
- The package-level deterministic inventory digest recorded during cleanup is `39434682884d2e487938a9ef6659a21f53935d804ab7fe38ec21da2da26ce6c6` (a SHA-256 over the sorted per-file SHA-256 listing; paths are included in that listing).
- `provenance.json` records generation at commit `41e78a9352f357e5a07a9c28f8cf46cb64158a75`, the frozen seed-44 checkpoint hash, tokenizer hash, source split hash, replacement policy, all 20 final passage identities, per-passage selected indices and offsets, the 60-image manifest, and QA results.
- The frozen seed-44 checkpoint survives locally and matches SHA-256 `c5719cb44822e4bb6c4f001356040b9bd8465c9152bf8831d6a16fb71276a7cc`.
- The deployed package reports 20 unique passages, CH/CM/FP/FN balance of 5/5/5/5, 60 images, exact matched detector/random selection counts, valid surface offsets, and no rendering overflow or metadata leakage.
- A byte-identical copy of the surviving package exists in the local sibling repository `DetectGPT copy`; it supplies redundancy but no missing inputs or generator source.

## What is missing

The following canonical pre-regeneration inputs named and hashed in `provenance.json` are absent from the repository, branches, worktrees, Git object history, local Kaggle packages/downloads, archive files, and the sibling repository copy:

| Missing input | Recorded SHA-256 |
|---|---|
| `outputs/human_study_final/final_20_pool.csv` | `b07e5e131aa849a38fd2c56027827f5f3385e338e821382fc56fdb3a0a409918` |
| `outputs/human_study_final/form_allocation.csv` | `07a59f20ebb326be280a0020119e2fbf3aa991bf6ca22ed47d821f9f55ac4663` |
| `outputs/human_study_final/forms/forms_setup_guide.csv` | `f008ea2d0e94422ae3dc4413af4b8a4c45772f3d696f6563421270186a1c190f` |
| `outputs/human_study_final/stimulus_metadata.jsonl` | `bb366af920b83be5e394a3ab4947f3114d39033eb316f1a644b016ef90a60dc2` |

The exact builder used to render/regenerate the final package is also absent. It appears to have existed only as uncommitted local source after the recorded Git commit.

## Recovery work performed

The audit searched all local and remote-tracking Git branches, tags, reflogs, stashes, registered worktrees, current and deleted paths, Kaggle packages and downloaded results, archive files, repository-wide hash/name references, and the sibling `DetectGPT copy` tree. The stale audit and Transformer worktrees have no surviving directories and predate the human study. No candidate matched the final builder or the four input hashes.

Five historical builder scripts remain recoverable from Git commit `6dd9d78` and earlier. They were reviewed individually. They implement the superseded 256-token, seed-43 workflow (`outputs/human_study*` / `outputs/human_study_surface_v1`) and are not the final 512-token seed-44 generator. They remain recoverable in Git history but were not restored as active code because doing so would make a superseded pipeline look canonical.

## What can be independently verified

An examiner with the surviving package, v3 historical test split, tokenizer source, and frozen checkpoint can verify:

- file and checkpoint hashes;
- the final 20 passage identities and category/domain balance;
- the documented 512-token prefixes;
- deterministic top-k detector selection at a 40% budget;
- matched random-selection counts and the documented random-seed policy;
- form allocation, condition rotation, and image count;
- image readability, dimensions, clipping/overflow, and absence of embedded labels; and
- the mapping used by the human-study processing code.

## What cannot currently be regenerated

The original end-to-end command cannot recreate the deployed directory byte-for-byte because the exact renderer source, its complete command line, and its four pre-regeneration inputs are missing. The rich final `provenance.json` may be sufficient to write a new equivalent renderer, but that would be a reconstruction rather than recovered provenance and must be labelled as such. This cleanup deliberately does not guess or retroactively claim equivalence.
