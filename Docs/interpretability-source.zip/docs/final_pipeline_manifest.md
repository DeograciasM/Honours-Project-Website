# Final Pipeline Manifest

This is the authoritative map from source code and frozen configurations to final results. It was reconstructed from the final-evaluation freeze manifest, campaign provenance, per-run configs, Kaggle package provenance, the evidence dossier, and the results-lock report. Paths are repository-relative. Metrics are test metrics unless explicitly labelled validation-only.

## Shared scientific contract

- Dataset: balanced English `raid_core_en_v3`; train/validation/test sizes are 5,760/1,200/1,200.
- Dataset hashes: train `9ce14d3c…947e1`, validation `f3c0f6b6…19b0`, test `a1dd7952…0790` (full values are in `data/manifests/raid_core_en_v3.json` and the freeze manifest).
- Neural surface processing: case- and punctuation-preserving Unicode tokenization using `\w+|[^\w\s]`; training-only vocabulary, maximum size 10,000, minimum frequency 2.
- Neural context: first 512 visible surface tokens.
- Neural seeds: 42, 43, and 44; all seeds are reported, with no test-driven seed selection.
- Embeddings: 300-dimensional filtered GloVe at `data/embeddings/glove.raid.300d.txt`; exact-token lookup then lowercase fallback; embeddings are fine-tuned.
- Primary metric: machine-class F1. Secondary metrics: accuracy, AUROC, machine precision, and machine recall.
- Canonical numerical source: `results/final/results_lock_report.md`. The older `outputs/archive/pre_surface_final_analysis/` tree is pre-surface/superseded and is not a source for final headline numbers.

## TF-IDF logistic-regression baseline

| Field | Canonical value |
|---|---|
| Training source | Frozen-run SHA-256 `b1330a36ab268f18d02046409b2c6c7b79ebf0550b0767234cbcc9de17297a68`; maintained `scripts/train_surface_tfidf.py` SHA-256 `01d1e0c6f4c7e8ac30a9e16907b7adba8f6dc59c6ca5686cf0b1a16b2ad6ad72` |
| Final evaluation | `scripts/run_v3_final_evaluation.py`; reporting-only recovery in `scripts/finalize_v3_final_evaluation.py` |
| Dataset | `data/processed/raid_core_en_v3` |
| Selection | word, character, and combined candidates trained on train; combined selected using validation only |
| Word features | lowercased word 1–2 grams, `min_df=2`, `max_features=100000` |
| Character features | lowercased `char_wb` 3–5 grams, `min_df=2`, `max_features=100000` |
| Classifier | `LogisticRegression(solver="liblinear", class_weight="balanced", max_iter=1000, random_state=42)` |
| Seed | 42 (classifier random state) |
| Context/budget | raw full text; no neural context cap; no rationale budget |
| Frozen model | `artifacts/models/tfidf/model.joblib` (SHA-256 `0fd38ac6fa2de49e06a231c933227f090d0ffff5783431cba77b210efc8b9817`) |
| Frozen config | `artifacts/models/tfidf/config.json` (SHA-256 `690e9794dafad5cd27511755bfa4c32f64fa40777bd6197e1ba3a7efec579bdf`) |
| Output | selection: `outputs/corrected_surface_v1/tfidf/combined/`; test: `outputs/final_evaluation/v3_final/` |
| Validation | F1 0.9468354430; AUROC 0.9848166667 |
| Final test | F1 0.9486099410; AUROC 0.9888416667; accuracy 0.9491666667 |
| Repository state at snapshot | source tracked; manifest untracked; models/results ignored |

Canonical selection command:

```bash
python scripts/train_surface_tfidf.py \
  --data-dir data/processed/raid_core_en_v3 \
  --out-dir outputs/corrected_surface_v1/tfidf/combined \
  --mode combined
```

The frozen model was reconstructed from the validation-selected combined configuration before the guarded final evaluation. See `docs/experiments/final_tfidf_baseline_manifest.json`.

## Full-context BiLSTM

| Field | Canonical value |
|---|---|
| Training source | `scripts/train_full_context_bilstm.py` (final training-source SHA-256 `92ad26dcd35e513d89c3f79b6b195e72be59329d3683f11438d7b24869ca77e5`) |
| Final evaluation | `scripts/run_v3_final_evaluation.py`; reporting-only recovery in `scripts/finalize_v3_final_evaluation.py` |
| Model | 300-d embedding; bidirectional LSTM with hidden size 128 per direction; dropout 0.2; 3,440,834 parameters |
| Optimisation | Adam; learning rate 0.0004; batch 32; 25 epochs; gradient clipping 5.0 |
| Context | 512 tokens |
| Seeds | 42, 43, 44 |
| Evaluation mode | validation-only training/model selection, then one guarded final-test evaluation |
| Checkpoints | `artifacts/models/bilstm_full/seed{42,43,44}/model.pt` |
| Output | training/model selection under `outputs/corrected_surface_v1/runs/`; final results under `outputs/final_evaluation/v3_final/` |
| Repository state at snapshot | source tracked; checkpoints/configs/results ignored |

Per-seed checkpoint and result record:

| Seed | Best epoch | Checkpoint SHA-256 | Validation F1 | Test F1 | Test AUROC |
|---:|---:|---|---:|---:|---:|
| 42 | 22 | `cb722b6f979fce444be66af7ea4cbf3d1df6aa980901952a5c9d830597536141` | 0.9527824621 | 0.9574645538 | 0.9898416667 |
| 43 | 14 | `5a857c51378c25dd4ba7ddd3527f45d58a136419ed570f8478cd8f5d6fc0b4fa` | 0.9627749577 | 0.9566666667 | 0.9885305556 |
| 44 | 20 | `11a0b7995f3aabb679abf325af803cd2d98de3f7a295dd71ba3738f1bea03b13` | 0.9558823529 | 0.9505766063 | 0.9894097222 |
| Mean ± sample SD | — | — | 0.9571465909 ± 0.0051148036 | 0.9549026089 ± 0.0037676093 | 0.9892606481 ± 0.0006681470 |

Canonical training command template (`SEED` is 42, 43, or 44):

```bash
python scripts/train_full_context_bilstm.py \
  --data-dir data/processed/raid_core_en_v3 \
  --output-dir outputs/corrected_surface_v1/runs/priority3_full_context_bilstm_ctx512_seed${SEED} \
  --run-name priority3_full_context_bilstm_ctx512_seed${SEED} \
  --device auto \
  --embeddings-path data/embeddings/glove.raid.300d.txt \
  --no-freeze-embeddings \
  --epochs 25 --batch-size 32 --lr 0.0004 --max-grad-norm 5 \
  --max-tokens 512 --hidden-dim 128 --dropout 0.2 \
  --seed ${SEED} --validation-only
```

The original runs explicitly used `--device mps`; `auto` is the portable equivalent and does not alter saved final results.

## HardKuma rationale BiLSTM, 40% budget

| Field | Canonical value |
|---|---|
| Training source | Frozen-run SHA-256 `80d9c5947c94bb7269ada9d0e6ae2aacaf9d5085ffca00a2d01c922f67078803`; maintained `scripts/train_kuma_rationale.py` SHA-256 `428a399a247134526a6661bba562d540abf973d43528a029b2be7b641972a3cf` |
| Evaluation/control source | `scripts/evaluate_rationale_strategies.py` plus final-evaluation scripts |
| Model | separate selector/predictor BiLSTMs; 300-d embeddings; hidden size 128; dropout 0.2; stretched HardKuma gates; 3,881,668 parameters |
| Optimisation | Adam; learning rate 0.0004; batch 32; 25 epochs; gradient clipping 5.0 |
| Context/budget | 512 tokens; target selection 0.40; deterministic top-`ceil(0.4 × visible_tokens)` inference |
| Controller | current mode; penalty μ 10; warm-up 300 steps; EMA α 0.5; dual LR 0.02; λ init 0.02, max 1.0; coherence control disabled; continuity weight 0 |
| Seeds | 42, 43, 44 |
| Evaluation mode | validation-only training/model selection, then one guarded final-test evaluation |
| Checkpoints | `artifacts/models/bilstm_hardkuma/seed{42,43,44}/model.pt` |
| Output | campaign under `outputs/final_model_campaign/`; final results under `outputs/final_evaluation/v3_final/` |
| Repository state at snapshot | source tracked; checkpoints/configs/results ignored |

| Seed | Best epoch | Checkpoint SHA-256 | Validation F1 | Test F1 | Test AUROC |
|---:|---:|---|---:|---:|---:|
| 42 | 25 | `2a17cc7c7a960c8dd35f31e1cd0669754dfceb0c3e395d98e2f8e0ef15caf1cb` | 0.9431438127 | 0.9499589828 | 0.9862486111 |
| 43 | 21 | `4316b295ac17c7b736b826c7c648916f853aff4b2fbc19138627f70c13b69337` | 0.9382924768 | 0.9415692821 | 0.9858041667 |
| 44 | 11 | `c5719cb44822e4bb6c4f001356040b9bd8465c9152bf8831d6a16fb71276a7cc` | 0.9411764706 | 0.9442131557 | 0.9858055556 |
| Mean ± sample SD | — | — | 0.9408709200 ± 0.0024400586 | 0.9452471402 ± 0.0042893603 | 0.9859527778 ± 0.0002562001 |

Canonical training command template:

```bash
python scripts/train_kuma_rationale.py \
  --data-dir data/processed/raid_core_en_v3 \
  --output-dir outputs/final_model_campaign/stage2_runs/stage2_rationale_ctx512_budget40_seed${SEED} \
  --run-name stage2_rationale_ctx512_budget40_seed${SEED} \
  --device auto \
  --embeddings-path data/embeddings/glove.raid.300d.txt \
  --no-freeze-embeddings \
  --epochs 25 --batch-size 32 --lr 0.0004 --max-grad-norm 5 \
  --max-tokens 512 --hidden-dim 128 --dropout 0.2 --seed ${SEED} \
  --validation-only --controller-mode current --penalty-mu 10 \
  --warmup-steps 300 --controller-alpha 0.5 --lagrange-lr 0.02 \
  --lambda-init 0.02 --lambda-max 1.0 --no-coherence-control \
  --lambda-continuity 0 --inference-mode topk --target-selection 0.4
```

## Full-context Transformer

| Field | Canonical value |
|---|---|
| Local entry point | `scripts/train_transformer_full_context.py` |
| Exact Kaggle workflow | Restricted external package recorded in `artifacts/artifact_manifest.json`; not included in the submission |
| Evaluation | package `workflow/evaluate_final_test_once.py`; local `scripts/evaluate_transformer.py` can inspect saved runs |
| Model | learned positional encoding; model dim 300; 2 encoder layers; 4 heads; FF dim 600; pre-norm; dropout 0.2; 4,600,802 parameters |
| Optimisation | Adam, weight decay 0; LR sweep 0.0004/0.0002/0.0001 on seed 42; winning LR 0.0004; batch 32; 25 epochs; gradient clipping 5.0; linear 10% LR warm-up |
| Context/budget | 512 tokens; full context, no rationale budget |
| Seeds | 42, 43, 44; seed 42 reused from winning sweep |
| Dataset | v3 train/validation in Stage A; encrypted v3 test revealed only after configuration freeze in Stage B |
| Checkpoints | `artifacts/models/transformer_full/seed{42,43,44}/model.pt` |
| Repository state at snapshot | local sources tracked; exact package and downloaded results untracked |

| Seed | Best epoch | Checkpoint SHA-256 | Validation F1 | Test F1 | Test AUROC |
|---:|---:|---|---:|---:|---:|
| 42 | 15 | `bb2fcddf66f3a095d76919093d26729ad9e9cc012f8ff69a9b1d46ab51cca3bc` | 0.9641965029 | 0.9612530915 | 0.9889708333 |
| 43 | 11 | `26f1434e0d59824430995873f0b73bb86a52263be42c43aa0957ba14e5ad871a` | 0.9592684954 | 0.9653465347 | 0.9892875000 |
| 44 | 9 | `8ae8c36ff63bdc102e010f169b7a32daaa1ceb4278c4fae8e72d174564109e40` | 0.9586497890 | 0.9640768588 | 0.9897597222 |
| Mean ± sample SD | — | — | 0.9607049291 ± 0.0030395748 | 0.9635588283 ± 0.0020953128 | 0.9893393519 ± 0.0003969923 |

The package workflow is the exact reproducibility path because it preserves the Stage-A/Stage-B test gate. Its final-seed training command uses `--device cuda`, the architecture and optimisation values above, `--evaluation-mode validation-only`, and `--lr-warmup-fraction 0.10`.

## HardKuma rationale Transformer

| Field | Canonical value |
|---|---|
| Local entry point | `scripts/train_transformer_rationale.py` |
| Exact Kaggle workflow | Restricted external package recorded in `artifacts/artifact_manifest.json`; not included in the submission |
| Evaluation | package `workflow/evaluate_final_test_once.py`; local `scripts/evaluate_transformer.py` can inspect saved runs |
| Model | separate selector/predictor Transformers; learned positions; model dim 300; 2 layers; 4 heads; FF dim 600; pre-norm; dropout 0.2; stretched HardKuma gates; 6,201,604 parameters |
| Optimisation | Adam, weight decay 0; LR sweep 0.0004/0.0002/0.0001 on seed 42; winning LR 0.0004; batch 32; 25 epochs; gradient clipping 5.0; linear 10% LR warm-up |
| Context/budget | 512 tokens; target selection 0.40; deterministic top-k inference |
| Controller | penalty μ 10; warm-up 300 steps; EMA α 0.5; dual LR 0.02; λ init 0.02, max 1.0; continuity weight 0; HardKuma `a_max=2.0`, `b_min=0.1` |
| Seeds | 42, 43, 44; seed 42 reused from winning sweep |
| Dataset | v3 train/validation in Stage A; encrypted v3 test revealed only after configuration freeze in Stage B |
| Checkpoints | `artifacts/models/transformer_hardkuma/seed{42,43,44}/model.pt` |
| Repository state at snapshot | local sources tracked; exact package and downloaded results untracked |

| Seed | Best epoch | Checkpoint SHA-256 | Validation F1 | Test F1 | Test AUROC |
|---:|---:|---|---:|---:|---:|
| 42 | 24 | `5d2c5f9683b79f57dd4d6b0b3e91f31d79fbd25d4aebc590efee3dcd3a3c53cd` | 0.9325562032 | 0.9304987735 | 0.9798875000 |
| 43 | 23 | `b86470667c9ebdb36740bc44251366a398c9aac8aef6af8a7dd8f6c89bf7eaa7` | 0.9148056245 | 0.9310058188 | 0.9743222222 |
| 44 | 16 | `7c2e224aa90b2b699c039579a136682524adc349bb4da4cd1caab7cd61338d22` | 0.9202037351 | 0.9356725146 | 0.9762666667 |
| Mean ± sample SD | — | — | 0.9225218543 ± 0.0090995065 | 0.9323923690 ± 0.0028519801 | 0.9768254630 ± 0.0028244060 |

The exact package workflow uses the same Stage-A/Stage-B gate as the full Transformer. It additionally passes the rationale-controller settings listed above.

## Final evaluation

| Stage | Source | Purpose |
|---|---|---|
| Freeze | `scripts/prepare_final_evaluation_freeze.py` | hashes selected models/configs and freezes the 512/40, seeds-42/43/44 contract |
| Pre-test audit | `scripts/prepare_v3_final_evaluation.py` | validates frozen inputs and prevents premature inference |
| Evaluation | `scripts/run_v3_final_evaluation.py` | evaluates TF-IDF plus six BiLSTM checkpoints and writes per-example predictions/metrics |
| Reporting recovery | `scripts/finalize_v3_final_evaluation.py` | fixes the one-class AUROC reporting compatibility issue from preserved predictions only; does not rerun models |
| Canonical output | `outputs/final_evaluation/v3_final/` | freeze manifest, predictions, per-run metrics, paired bootstrap, subgroup results, rationale controls/stability, final tables |

The final-evaluation manifest is SHA-256 `cd0627e38e3519aeaddaf1b26793955f08dce2bc29776fb832b73b6926dc259e`. `final_results.csv` is `213e995c03d6ad049bbffbb0c94adb9e5a1d798ad268e821981b2fd48bba9385`. The final evaluation is closed; these commands are provenance, not authorization to tune against the final test set.

## Human-study experiment and analysis

| Field | Canonical value |
|---|---|
| Stimulus contract | final BiLSTM HardKuma, context 512, 40% deterministic token budget, seed 44 |
| Study conditions | Plain, Detector rationale, matched-count Random rationale |
| Deployed materials | `outputs/human_study_final/forms_512_40_seed44/` |
| Stimulus provenance | `outputs/human_study_final/forms_512_40_seed44/provenance.json` (SHA-256 `d946649af694a3b0c6181653a7c47f2ae7c4c1e745753b690d73f212127e8ce3`) |
| Private inputs | six raw workbooks under `Form Responses/`; must not be committed or publicly distributed |
| Processing source | Analysis-run SHA-256 `4db297410ef50f8cbb5556eb8f9807b63c354a3eaa4aada7417bb3e8fba1cee7`; maintained portable source `human_study_analysis/scripts/build_processed_data.py`, SHA-256 `b979bfebff8dd59193fb8c587204e4e80bee19c22fdc6e4ec37af34dc2fdd986` |
| Statistical source | Analysis-run SHA-256 `a063cbdc10b681aa66f26d5eddbbff2eabaeefea66c9e647c970e75c3866b031`; maintained renv source `human_study_analysis/scripts/run_lean_analysis.R`, SHA-256 `51ff067f44bd07a10cbb1e2786c1c3ea6cbb072d13619a71cafb1662b306664c` |
| Sample | 25 participants/submissions; 250 judgements; all passed the attention check |
| Primary analysis | planned logistic mixed model for correctness; singular zero random-intercept variances, so fixed-effects logistic model with participant-and-passage two-way cluster-robust uncertainty is the recorded fallback |
| Public aggregate output | `results/human_study/aggregate/` |
| Public/private status | analysis source and aggregate outputs are submission material; raw workbooks, row-level tables, private hashes, and fitted model objects are ignored |

Frozen descriptive accuracy: Plain 39/83 (47.0%), Detector 37/82 (45.1%), Random 38/85 (44.7%). These are descriptive results, not evidence that rationale highlighting improved accuracy.

Reproduction commands, after placing private workbooks locally and restoring the declared R environment:

```bash
python human_study_analysis/scripts/build_processed_data.py
Rscript human_study_analysis/scripts/run_lean_analysis.R
```

## Source/result precedence

When records disagree, use this precedence:

1. `results/final/results_lock_report.md` for reported final numbers.
2. Frozen per-example predictions and metrics in the canonical final directories.
3. Freeze/package provenance and per-run configs for configuration and hashes.
4. `docs/experiments/final_evidence_dossier.md` for broader scientific context.
5. Historical experiment notes only for provenance, never to replace final corrected-surface results.

## Source maintenance after the freeze

Frozen-run source hashes identify the code that produced existing artifacts. Maintained source hashes identify the submission version after non-scientific cleanup. The TF-IDF entry point was reformatted and given non-empty-output overwrite protection. The HardKuma entry point gained a backwards-compatible fallback for programmatic `Namespace` objects that omit `validation_only`. The final-evaluation entry point’s import was redirected to the archived pre-surface helper after repository reorganisation. Model definitions, hyperparameters, dataset selection, checkpoint selection, final predictions, and reported results were not changed.

Maintained submission-source SHA-256 values for the remaining active entry
points are:

- `src/detectgpt/rationales/transformer_experiment.py`:
  `a79352d8a8b6b30a1a7fc8fdd54128d0d291a071dfe0582a5fe9b70256e16fb8`
- `scripts/run_v3_final_evaluation.py`:
  `9fa6f9a768dc72be3b8a98a80f58fa62170ccbb570262c11344c5f82235253d8`

The exact Transformer execution source remains inside the hashed private Kaggle packages. The local Transformer module contains maintained validation-only and warm-up support but is not substituted for the package source when claiming byte-level provenance.
