"""Baseline model implementations."""

