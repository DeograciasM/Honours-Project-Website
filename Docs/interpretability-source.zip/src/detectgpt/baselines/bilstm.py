from __future__ import annotations

import torch
from torch import nn
from torch.nn.utils.rnn import pack_padded_sequence, pad_packed_sequence


class FullContextBiLSTM(nn.Module):
    """Matched full-context classifier for the HardKuma predictor encoder."""

    def __init__(
        self,
        vocab_size: int,
        embed_dim: int = 128,
        hidden_dim: int = 128,
        dropout: float = 0.2,
        pretrained_embeddings: torch.Tensor | None = None,
        freeze_embeddings: bool = False,
        padding_idx: int = 0,
    ) -> None:
        super().__init__()
        if pretrained_embeddings is not None:
            embed_dim = pretrained_embeddings.shape[1]
            self.embedding = nn.Embedding.from_pretrained(
                pretrained_embeddings, freeze=freeze_embeddings, padding_idx=padding_idx
            )
        else:
            self.embedding = nn.Embedding(vocab_size, embed_dim, padding_idx=padding_idx)
        self.dropout = nn.Dropout(dropout)
        self.encoder = nn.LSTM(embed_dim, hidden_dim, batch_first=True, bidirectional=True)
        self.classifier = nn.Sequential(nn.Dropout(dropout), nn.Linear(hidden_dim * 2, 2))

    def forward(self, input_ids: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
        lengths = mask.sum(dim=1)
        if (lengths < 1).any():
            raise ValueError("Every document must contain at least one real token.")
        embeddings = self.dropout(self.embedding(input_ids))
        packed = pack_padded_sequence(embeddings, lengths.cpu(), batch_first=True, enforce_sorted=False)
        packed_states, _ = self.encoder(packed)
        states, _ = pad_packed_sequence(packed_states, batch_first=True, total_length=input_ids.size(1))
        pooled = (states * mask.unsqueeze(-1)).sum(dim=1) / lengths.unsqueeze(1)
        return self.classifier(pooled)
