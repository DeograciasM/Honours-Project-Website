from __future__ import annotations

from typing import Any

import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import FeatureUnion, Pipeline


DEFAULT_TFIDF_CONFIG: dict[str, Any] = {
    "baseline": "tfidf_logistic_regression",
    "vectorizer": {
        "ngram_range": [1, 2],
        "max_features": 100000,
        "min_df": 2,
        "lowercase": True,
    },
    "classifier": {
        "class_weight": "balanced",
        "max_iter": 1000,
        "solver": "liblinear",
        "random_state": 42,
    },
}

# Proposal section 4.3 commits to word AND character n-grams for the shared
# baseline. Word settings mirror DEFAULT_TFIDF_CONFIG's max_features/min_df;
# char settings use the same values, not a shared/divided budget.
DEFAULT_WORDCHAR_TFIDF_CONFIG: dict[str, Any] = {
    "baseline": "tfidf_wordchar_logistic_regression",
    "vectorizer": {
        "word": {
            "analyzer": "word",
            "ngram_range": [1, 2],
            "max_features": 100000,
            "min_df": 2,
            "lowercase": True,
        },
        "char": {
            "analyzer": "char_wb",
            "ngram_range": [3, 5],
            "max_features": 100000,
            "min_df": 2,
            "lowercase": True,
        },
    },
    "classifier": {
        "class_weight": "balanced",
        "max_iter": 1000,
        "solver": "liblinear",
        "random_state": 42,
    },
}


def build_tfidf_pipeline(config: dict[str, Any] | None = None) -> Pipeline:
    """Build the TF-IDF + Logistic Regression baseline pipeline (word n-grams only)."""
    config = config or DEFAULT_TFIDF_CONFIG
    vectorizer_config = config["vectorizer"]
    classifier_config = config["classifier"]

    vectorizer = TfidfVectorizer(
        ngram_range=tuple(vectorizer_config["ngram_range"]),
        max_features=vectorizer_config["max_features"],
        min_df=vectorizer_config["min_df"],
        lowercase=vectorizer_config["lowercase"],
    )
    classifier = LogisticRegression(**classifier_config)
    return Pipeline([("tfidf", vectorizer), ("classifier", classifier)])


def build_tfidf_wordchar_pipeline(config: dict[str, Any] | None = None) -> Pipeline:
    """Build the TF-IDF + Logistic Regression baseline pipeline with word + char_wb n-grams (proposal section 4.3)."""
    config = config or DEFAULT_WORDCHAR_TFIDF_CONFIG
    word_config = config["vectorizer"]["word"]
    char_config = config["vectorizer"]["char"]
    classifier_config = config["classifier"]

    word_vectorizer = TfidfVectorizer(
        analyzer=word_config["analyzer"],
        ngram_range=tuple(word_config["ngram_range"]),
        max_features=word_config["max_features"],
        min_df=word_config["min_df"],
        lowercase=word_config["lowercase"],
    )
    char_vectorizer = TfidfVectorizer(
        analyzer=char_config["analyzer"],
        ngram_range=tuple(char_config["ngram_range"]),
        max_features=char_config["max_features"],
        min_df=char_config["min_df"],
        lowercase=char_config["lowercase"],
    )
    feature_union = FeatureUnion([("word_tfidf", word_vectorizer), ("char_tfidf", char_vectorizer)])
    classifier = LogisticRegression(**classifier_config)
    return Pipeline([("tfidf", feature_union), ("classifier", classifier)])


def extract_feature_weights(model: Pipeline, top_n: int = 50) -> dict[str, list[dict[str, float | str]]]:
    """Return strongest positive and negative linear TF-IDF coefficients."""
    vectorizer: TfidfVectorizer | FeatureUnion = model.named_steps["tfidf"]
    classifier: LogisticRegression = model.named_steps["classifier"]

    feature_names = np.asarray(vectorizer.get_feature_names_out())
    coefficients = classifier.coef_[0]

    positive_indices = np.argsort(coefficients)[-top_n:][::-1]
    negative_indices = np.argsort(coefficients)[:top_n]

    return {
        "machine_indicative_features": [
            {"feature": str(feature_names[index]), "weight": float(coefficients[index])} for index in positive_indices
        ],
        "human_indicative_features": [
            {"feature": str(feature_names[index]), "weight": float(coefficients[index])} for index in negative_indices
        ],
    }

