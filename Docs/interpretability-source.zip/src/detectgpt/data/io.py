from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Iterable


JsonRow = dict[str, Any]


def load_jsonl(path: str | Path) -> list[JsonRow]:
    """Load a JSONL file and return rows as dictionaries."""
    path = Path(path)
    rows: list[JsonRow] = []

    with path.open("r", encoding="utf-8") as handle:
        for line_no, line in enumerate(handle, start=1):
            line = line.strip()
            if not line:
                continue
            try:
                row = json.loads(line)
            except json.JSONDecodeError as exc:
                raise ValueError(f"{path}:{line_no} invalid JSON: {exc}") from exc
            if not isinstance(row, dict):
                raise ValueError(f"{path}:{line_no} expected JSON object, got {type(row).__name__}")
            rows.append(row)

    return rows


def write_jsonl(path: str | Path, rows: Iterable[JsonRow]) -> None:
    """Write dictionaries to a JSONL file."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)

    with path.open("w", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False, sort_keys=True))
            handle.write("\n")


def load_dataset_splits(data_dir: str | Path, splits: Iterable[str]) -> dict[str, list[JsonRow]]:
    """Load named dataset splits from a directory."""
    data_dir = Path(data_dir)
    return {split: load_jsonl(data_dir / f"{split}.jsonl") for split in splits}

