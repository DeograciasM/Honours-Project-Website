from __future__ import annotations

from pathlib import Path

from detectgpt.data.io import JsonRow


REQUIRED_FIELDS = {
    "id",
    "text",
    "label",
    "label_id",
    "domain",
    "generator",
    "source_id",
    "attack",
    "decoding",
    "split",
}
REQUIRED_SPLITS = ("train", "validation", "test")
EXPECTED_LABEL_IDS = {"human": 0, "machine": 1}


class DatasetValidationError(ValueError):
    """Raised when a dataset does not satisfy the baseline contract."""


def validate_split_files(data_dir: str | Path, splits: tuple[str, ...] = REQUIRED_SPLITS) -> None:
    """Validate that all expected split files exist."""
    data_dir = Path(data_dir)
    missing = [str(data_dir / f"{split}.jsonl") for split in splits if not (data_dir / f"{split}.jsonl").is_file()]
    if missing:
        raise DatasetValidationError("Missing dataset split file(s): " + ", ".join(missing))


def validate_rows(rows_by_split: dict[str, list[JsonRow]], max_reported_errors: int = 30) -> None:
    """Validate required fields, split names, text, and binary label mapping."""
    errors: list[str] = []

    for split, rows in rows_by_split.items():
        if not rows:
            errors.append(f"{split}: split is empty")
            continue

        for line_no, row in enumerate(rows, start=1):
            missing = REQUIRED_FIELDS - set(row)
            if missing:
                errors.append(f"{split}:{line_no} missing fields: {sorted(missing)}")
                continue

            if row["split"] != split:
                errors.append(f"{split}:{line_no} has split={row['split']!r}, expected {split!r}")

            label = row["label"]
            label_id = row["label_id"]
            expected_label_id = EXPECTED_LABEL_IDS.get(label)
            if expected_label_id is None:
                errors.append(f"{split}:{line_no} unsupported label={label!r}; expected 'human' or 'machine'")
            elif label_id != expected_label_id:
                errors.append(
                    f"{split}:{line_no} inconsistent label mapping: label={label!r}, "
                    f"label_id={label_id!r}, expected {expected_label_id}"
                )

            if label_id not in (0, 1):
                errors.append(f"{split}:{line_no} label_id={label_id!r}; expected 0 or 1")

            if not isinstance(row["text"], str) or not row["text"].strip():
                errors.append(f"{split}:{line_no} text must be a non-empty string")

            for field in ("id", "domain", "generator", "source_id"):
                if not isinstance(row[field], str) or not row[field].strip():
                    errors.append(f"{split}:{line_no} {field} must be a non-empty string")

    if errors:
        shown = errors[:max_reported_errors]
        suffix = "" if len(errors) <= max_reported_errors else f"\n... and {len(errors) - max_reported_errors} more"
        raise DatasetValidationError("Dataset validation failed:\n- " + "\n- ".join(shown) + suffix)


def validate_dataset(data_dir: str | Path, rows_by_split: dict[str, list[JsonRow]]) -> None:
    """Run all dataset validations needed before training."""
    validate_split_files(data_dir)
    validate_rows(rows_by_split)

