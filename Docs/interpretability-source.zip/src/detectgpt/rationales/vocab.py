from __future__ import annotations

import re
from collections import Counter
from dataclasses import dataclass
from typing import Iterable

from detectgpt.rationales.sentence_splitter import split_sentences


# Every non-whitespace surface unit is represented: Unicode word/number runs
# stay intact and each punctuation/symbol code point is independently
# selectable.  Match offsets always refer directly to the unmodified input.
_TOKEN_RE = re.compile(r"\w+|[^\w\s]", flags=re.UNICODE)
PAD_TOKEN = "<pad>"
UNK_TOKEN = "<unk>"


def tokenize(text: str) -> list[str]:
    """Return case- and punctuation-preserving surface tokens."""
    return [match.group(0) for match in _TOKEN_RE.finditer(text)]


@dataclass(frozen=True)
class SurfaceToken:
    text: str
    start: int
    end: int


def tokenize_with_offsets(text: str) -> list[SurfaceToken]:
    """Return surface tokens with exact half-open offsets into ``text``."""
    return [SurfaceToken(match.group(0), match.start(), match.end()) for match in _TOKEN_RE.finditer(text)]


@dataclass
class Vocabulary:
    token_to_id: dict[str, int]

    @property
    def pad_id(self) -> int:
        return self.token_to_id[PAD_TOKEN]

    @property
    def unk_id(self) -> int:
        return self.token_to_id[UNK_TOKEN]

    def __len__(self) -> int:
        return len(self.token_to_id)

    def encode(self, text: str, max_tokens: int) -> list[int]:
        token_ids = [self.token_to_id.get(token, self.unk_id) for token in tokenize(text)[:max_tokens]]
        return token_ids or [self.unk_id]

    def to_dict(self) -> dict[str, int]:
        return dict(self.token_to_id)


def build_vocabulary(texts: Iterable[str], max_vocab: int, min_freq: int) -> Vocabulary:
    """Build a frequency-limited vocabulary from sentence tokens."""
    counts: Counter[str] = Counter()
    for text in texts:
        for sentence in split_sentences(text):
            counts.update(tokenize(sentence.text))

    token_to_id = {PAD_TOKEN: 0, UNK_TOKEN: 1}
    kept_tokens = [
        token
        for token, count in counts.most_common()
        if count >= min_freq and token not in token_to_id
    ]

    for token in kept_tokens[: max(0, max_vocab - len(token_to_id))]:
        token_to_id[token] = len(token_to_id)

    return Vocabulary(token_to_id=token_to_id)
