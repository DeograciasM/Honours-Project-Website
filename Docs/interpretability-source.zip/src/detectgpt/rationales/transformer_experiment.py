from __future__ import annotations

import argparse
import copy
import json
import math
import random
import subprocess
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Literal

import numpy as np
import torch
from torch import nn
from torch.utils.data import DataLoader, Dataset

from detectgpt.data.io import JsonRow, load_dataset_splits, write_jsonl
from detectgpt.data.validation import REQUIRED_SPLITS, validate_rows, validate_split_files
from detectgpt.evaluation.metrics import evaluate_split
from detectgpt.rationales.kuma_model import load_pretrained_embeddings
from detectgpt.rationales.rate_controller import RateController
from detectgpt.rationales.transformer_model import (
    FullContextTransformerClassifier,
    TransformerRationaleModel,
    select_topk_tokens,
)
from detectgpt.rationales.vocab import Vocabulary, build_vocabulary, tokenize_with_offsets
from detectgpt.utils.device import DEVICE_CHOICES, resolve_device
from detectgpt.utils.seed import set_seed

ModelKind = Literal["rationale", "full_context"]


@dataclass
class TokenExample:
    row: JsonRow
    tokens: list[str]
    token_ids: list[int]
    label_id: int


class TokenDataset(Dataset[TokenExample]):
    def __init__(self, rows: list[JsonRow], vocab: Vocabulary, max_tokens: int) -> None:
        self.examples = []
        for row in rows:
            spans = tokenize_with_offsets(str(row["text"]))[:max_tokens]
            tokens = [span.text for span in spans] or ["<unk>"]
            token_ids = [vocab.token_to_id.get(token, vocab.unk_id) for token in tokens]
            self.examples.append(TokenExample(row, tokens, token_ids, int(row["label_id"])))

    def __len__(self) -> int:
        return len(self.examples)

    def __getitem__(self, index: int) -> TokenExample:
        return self.examples[index]


def collate_examples(examples: list[TokenExample], pad_id: int) -> dict[str, Any]:
    max_length = max(len(example.token_ids) for example in examples)
    input_ids = torch.full((len(examples), max_length), pad_id, dtype=torch.long)
    mask = torch.zeros((len(examples), max_length), dtype=torch.bool)
    for index, example in enumerate(examples):
        length = len(example.token_ids)
        input_ids[index, :length] = torch.tensor(example.token_ids)
        mask[index, :length] = True
    return {
        "input_ids": input_ids,
        "mask": mask,
        "labels": torch.tensor([example.label_id for example in examples]),
        "examples": examples,
    }


def make_loader(dataset: TokenDataset, batch_size: int, shuffle: bool, seed: int, pad_id: int) -> DataLoader:
    generator = torch.Generator().manual_seed(seed)
    return DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=shuffle,
        collate_fn=lambda examples: collate_examples(examples, pad_id),
        generator=generator,
    )


def rationale_metrics(rows: list[JsonRow]) -> dict[str, Any]:
    counts = [len(row["selected_token_indices"]) for row in rows]
    fractions = [float(row["selected_fraction"]) for row in rows]
    sufficiency = [float(row["sufficiency_drop"]) for row in rows]
    comprehensiveness = [float(row["comprehensiveness_drop"]) for row in rows]
    return {
        "average_selected_fraction": float(np.mean(fractions)) if fractions else 0.0,
        "average_selected_tokens": float(np.mean(counts)) if counts else 0.0,
        "empty_selection_fallback_count": sum(bool(row["used_empty_selection_fallback"]) for row in rows),
        "mean_sufficiency_drop": float(np.mean(sufficiency)) if sufficiency else 0.0,
        "mean_comprehensiveness_drop": float(np.mean(comprehensiveness)) if comprehensiveness else 0.0,
    }


def git_commit() -> str | None:
    try:
        return subprocess.run(
            ["git", "rev-parse", "HEAD"], check=True, capture_output=True, text=True
        ).stdout.strip()
    except (OSError, subprocess.CalledProcessError):
        return None


def git_is_dirty() -> bool | None:
    try:
        return bool(subprocess.run(["git", "status", "--porcelain"], check=True, capture_output=True, text=True).stdout)
    except (OSError, subprocess.CalledProcessError):
        return None


def save_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def save_run_summary(path: Path, config: dict[str, Any], metrics: dict[str, Any]) -> None:
    def display(value: float | None) -> str:
        return f"{value:.4f}" if value is not None else "—"

    lines = [
        f"# {config['run_name']}",
        "",
        f"- Model: `{config['model']['type']}`",
        f"- Seed: {config['seed']}",
        f"- Dataset: `{config['dataset_version']}`",
        f"- Git commit: `{config['git_commit']}`",
        f"- Parameters: {config['parameter_count']['total']}",
        f"- Training time (seconds): {config['training_time_seconds']:.2f}",
        f"- Validation-selected epoch: {config['best_epoch']}",
        "",
        "| Split | Accuracy | Precision | Recall | F1 | AUROC | Selected fraction | Selected tokens | Fallbacks |",
        "| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |",
    ]
    for split in (name for name in ("validation", "test") if name in metrics):
        overall = metrics[split]["overall"]
        rationale = metrics[split].get("rationales", {})
        lines.append(
            f"| {split} | {overall['accuracy']:.4f} | {overall['machine_precision']:.4f} | "
            f"{overall['machine_recall']:.4f} | {overall['machine_f1']:.4f} | {display(overall['auroc'])} | "
            f"{rationale.get('average_selected_fraction', '—')} | "
            f"{rationale.get('average_selected_tokens', '—')} | "
            f"{rationale.get('empty_selection_fallback_count', '—')} |"
        )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def model_config(args: argparse.Namespace, kind: ModelKind) -> dict[str, Any]:
    config: dict[str, Any] = {
        "type": "transformer_rationale" if kind == "rationale" else "transformer_full_context",
        "model_dim": args.model_dim,
        "num_heads": args.num_heads,
        "ff_dim": args.ff_dim,
        "num_layers": args.num_layers,
        "dropout": args.dropout,
        "max_tokens": args.max_tokens,
        "norm_first": True,
        "positional_encoding": "learned",
    }
    if kind == "rationale":
        config["gate"] = {
            "distribution": "stretched_hard_kumaraswamy",
            "left": -0.1,
            "right": 1.1,
            "a_min": 0.01,
            "a_max": args.a_max,
            "b_min": args.b_min,
            "b_max": 10.0,
        }
        config["information_exclusion"] = {
            "word_embedding_gate": True,
            "unselected_key_value_attention_mask": True,
            "selected_only_pooling": True,
            "empty_sample_fallback": "argmax_expected_nonzero_probability",
        }
    return config


def build_model(
    config: dict[str, Any],
    vocab_size: int,
    pretrained_embeddings: torch.Tensor | None = None,
) -> nn.Module:
    model = config["model"]
    common = dict(
        vocab_size=vocab_size,
        model_dim=int(model["model_dim"]),
        num_heads=int(model["num_heads"]),
        ff_dim=int(model["ff_dim"]),
        num_layers=int(model["num_layers"]),
        dropout=float(model["dropout"]),
        max_tokens=int(model["max_tokens"]),
        pretrained_embeddings=pretrained_embeddings,
        freeze_embeddings=bool(config.get("freeze_embeddings", False)),
        padding_idx=int(config.get("pad_id", 0)),
    )
    if model["type"] == "transformer_rationale":
        gate = model["gate"]
        return TransformerRationaleModel(
            **common,
            kuma_left=float(gate["left"]),
            kuma_right=float(gate["right"]),
            a_max=float(gate["a_max"]),
            b_min=float(gate["b_min"]),
        )
    if model["type"] == "transformer_full_context":
        return FullContextTransformerClassifier(**common)
    raise ValueError(f"Unsupported model type: {model['type']}")


def parameter_count(model: nn.Module) -> dict[str, int]:
    return {
        "total": sum(parameter.numel() for parameter in model.parameters()),
        "trainable": sum(parameter.numel() for parameter in model.parameters() if parameter.requires_grad),
    }


def make_linear_warmup_constant_scheduler(
    optimizer: torch.optim.Optimizer,
    total_steps: int,
    warmup_fraction: float,
) -> tuple[torch.optim.lr_scheduler.LambdaLR, int]:
    """Linearly warm the LR for a fixed fraction, then hold it constant."""
    if total_steps < 1:
        raise ValueError("total_steps must be positive.")
    if not 0.0 <= warmup_fraction <= 1.0:
        raise ValueError("warmup_fraction must be between 0 and 1.")
    warmup_steps = min(total_steps, math.ceil(total_steps * warmup_fraction))

    def multiplier(step: int) -> float:
        if warmup_steps == 0:
            return 1.0
        return min((step + 1) / warmup_steps, 1.0)

    return torch.optim.lr_scheduler.LambdaLR(optimizer, multiplier), warmup_steps


def load_vocab(run_dir: Path) -> Vocabulary:
    payload = json.loads((run_dir / "vocab.json").read_text(encoding="utf-8"))
    return Vocabulary(token_to_id={str(token): int(index) for token, index in payload["token_to_id"].items()})


def save_checkpoint(path: Path, model: nn.Module, config: dict[str, Any], vocab: Vocabulary) -> None:
    torch.save(
        {
            "model_state_dict": {key: value.cpu() for key, value in model.state_dict().items()},
            "model_config": config["model"],
            "training_config": config,
            "vocabulary": {"token_to_id": vocab.to_dict()},
        },
        path,
    )


def load_checkpoint(run_dir: Path, device: torch.device) -> tuple[nn.Module, Vocabulary, dict[str, Any]]:
    config = json.loads((run_dir / "config.json").read_text(encoding="utf-8"))
    vocab = load_vocab(run_dir)
    model = build_model(config, len(vocab)).to(device)
    checkpoint = torch.load(run_dir / "model.pt", map_location=device, weights_only=False)
    model.load_state_dict(checkpoint["model_state_dict"])
    model.eval()
    return model, vocab, config


def train_epoch(
    model: nn.Module,
    loader: torch.utils.data.DataLoader,
    optimizer: torch.optim.Optimizer,
    device: torch.device,
    controller: RateController | None,
    lambda_sparsity: float,
    lambda_continuity: float,
    max_grad_norm: float,
    scheduler: torch.optim.lr_scheduler.LRScheduler | None = None,
) -> dict[str, float]:
    model.train()
    totals = {"loss": 0.0, "classification_loss": 0.0, "selection": 0.0, "fallbacks": 0.0}
    examples = 0
    loss_fn = nn.CrossEntropyLoss()
    for batch in loader:
        input_ids = batch["input_ids"].to(device)
        mask = batch["mask"].to(device)
        labels = batch["labels"].to(device)
        optimizer.zero_grad()
        output = model(input_ids, mask)
        classification_loss = loss_fn(output["logits"], labels)
        if controller is not None:
            selection = output["expected_selection_rate"]
            loss = constrained_rationale_loss(
                classification_loss,
                selection,
                output["continuity_loss"],
                controller,
                lambda_continuity,
            )
        else:
            selection = classification_loss.new_zeros(())
            loss = classification_loss
        if not torch.isfinite(loss):
            raise FloatingPointError("Non-finite Transformer training loss.")
        loss.backward()
        if max_grad_norm > 0:
            nn.utils.clip_grad_norm_(model.parameters(), max_grad_norm)
        optimizer.step()
        if scheduler is not None:
            scheduler.step()
        if controller is not None:
            controller.update(float(selection.item()))

        batch_size = labels.size(0)
        examples += batch_size
        totals["loss"] += float(loss.item()) * batch_size
        totals["classification_loss"] += float(classification_loss.item()) * batch_size
        totals["selection"] += float(selection.item()) * batch_size
        totals["fallbacks"] += float(output.get("empty_selection_fallback_count", 0))
    denominator = max(1, examples)
    return {
        "loss": totals["loss"] / denominator,
        "classification_loss": totals["classification_loss"] / denominator,
        "expected_selection_rate": totals["selection"] / denominator,
        "training_empty_selection_fallback_count": totals["fallbacks"],
        "lambda": controller.lam if controller is not None else lambda_sparsity,
    }


def constrained_rationale_loss(
    classification_loss: torch.Tensor,
    expected_selection_rate: torch.Tensor,
    continuity_loss: torch.Tensor,
    controller: RateController,
    lambda_continuity: float,
) -> torch.Tensor:
    """Apply the shared RateController contract to Transformer rationales."""
    return (
        classification_loss
        - controller.penalty(expected_selection_rate)
        + lambda_continuity * continuity_loss
    )


def _base_prediction_row(example: Any, pred: int, machine_probability: float) -> JsonRow:
    return {
        "id": example.row["id"],
        "text": example.row["text"],
        "label_id": int(example.row["label_id"]),
        "label": example.row["label"],
        "predicted_label_id": pred,
        "predicted_label": "machine" if pred else "human",
        "probability_machine": machine_probability,
        "domain": example.row.get("domain"),
        "generator": example.row.get("generator"),
        "source_id": example.row.get("source_id"),
        "split": example.row.get("split"),
    }


def evaluate_rationale(
    model: TransformerRationaleModel,
    loader: torch.utils.data.DataLoader,
    device: torch.device,
    target_selection: float,
) -> tuple[dict[str, Any], list[JsonRow]]:
    model.eval()
    metric_rows: list[JsonRow] = []
    prediction_rows: list[JsonRow] = []
    predictions: list[int] = []
    scores: list[float] = []
    with torch.no_grad():
        for batch in loader:
            input_ids = batch["input_ids"].to(device)
            mask = batch["mask"].to(device)
            embeddings = model.embed_tokens(input_ids)
            a, b = model.gate_parameters(embeddings, mask)
            gate_tensor = model.deterministic_gates(a, b, mask)
            hard_gates = torch.zeros_like(gate_tensor)
            selected_rows: list[list[int]] = []
            fallback_rows: list[bool] = []
            for index, (gates, row_mask) in enumerate(zip(gate_tensor.tolist(), mask.tolist(), strict=True)):
                valid_count = sum(row_mask)
                selected, fallback = select_topk_tokens(gates, valid_count, target_selection)
                hard_gates[index, selected] = 1.0
                selected_rows.append(selected)
                fallback_rows.append(fallback)
            rationale_probabilities = torch.softmax(model.predict_from_gates(embeddings, hard_gates, mask), dim=1)
            full_probabilities = torch.softmax(model.predict_from_gates(embeddings, mask.float(), mask), dim=1)
            complement = mask & ~hard_gates.bool()
            without_probabilities = torch.softmax(
                model.predict_from_gates(embeddings, complement.float(), mask, allow_empty=True), dim=1
            )
            for local_index, (example, probability, gates, row_mask, selected, fallback) in enumerate(zip(
                batch["examples"], rationale_probabilities[:, 1].tolist(), gate_tensor.tolist(), mask.tolist(), selected_rows, fallback_rows,
                strict=True,
            )):
                pred = int(probability >= 0.5)
                valid_count = sum(row_mask)
                full_class_probability = float(full_probabilities[local_index, pred])
                rationale_class_probability = float(rationale_probabilities[local_index, pred])
                without_class_probability = float(without_probabilities[local_index, pred])
                row = _base_prediction_row(example, pred, float(probability))
                row.update(
                    {
                        "selected_token_indices": selected,
                        "selected_tokens": [example.tokens[position] for position in selected],
                        "token_gate_values": [float(value) for value in gates[:valid_count]],
                        "selected_fraction": len(selected) / valid_count,
                        "prediction_mode": "hardkuma_topk_tokens",
                        "used_empty_selection_fallback": fallback,
                        "full_text_probability_for_predicted_class": full_class_probability,
                        "rationale_only_probability_for_predicted_class": rationale_class_probability,
                        "without_rationale_probability_for_predicted_class": without_class_probability,
                        "sufficiency_drop": full_class_probability - rationale_class_probability,
                        "comprehensiveness_drop": full_class_probability - without_class_probability,
                    }
                )
                metric_rows.append(example.row)
                prediction_rows.append(row)
                predictions.append(pred)
                scores.append(float(probability))
    metrics = evaluate_split(metric_rows, predictions, scores)
    metrics["rationales"] = rationale_metrics(prediction_rows)
    return metrics, prediction_rows


def evaluate_full_context(
    model: FullContextTransformerClassifier,
    loader: torch.utils.data.DataLoader,
    device: torch.device,
) -> tuple[dict[str, Any], list[JsonRow]]:
    model.eval()
    metric_rows: list[JsonRow] = []
    prediction_rows: list[JsonRow] = []
    predictions: list[int] = []
    scores: list[float] = []
    with torch.no_grad():
        for batch in loader:
            probabilities = torch.softmax(
                model(batch["input_ids"].to(device), batch["mask"].to(device))["logits"], dim=1
            )[:, 1]
            for example, probability in zip(batch["examples"], probabilities.tolist(), strict=True):
                pred = int(probability >= 0.5)
                prediction_rows.append(_base_prediction_row(example, pred, float(probability)))
                metric_rows.append(example.row)
                predictions.append(pred)
                scores.append(float(probability))
    return evaluate_split(metric_rows, predictions, scores), prediction_rows


def evaluate_saved_run(run_dir: Path, data_dir: Path | None = None) -> dict[str, Any]:
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model, vocab, config = load_checkpoint(run_dir, device)
    source = data_dir or Path(config["data_dir"])
    rows = load_dataset_splits(source, ("validation", "test"))
    configured_limits = config.get("limits", {})
    rows = {
        split: values[: configured_limits.get(split)] if configured_limits.get(split) is not None else values
        for split, values in rows.items()
    }
    loaders = {
        split: make_loader(TokenDataset(split_rows, vocab, config["max_tokens"]), config["batch_size"], False, config["seed"], vocab.pad_id)
        for split, split_rows in rows.items()
    }
    output: dict[str, Any] = {}
    predictions: dict[str, list[JsonRow]] = {}
    for split, loader in loaders.items():
        if config["model_kind"] == "rationale":
            split_metrics, split_predictions = evaluate_rationale(model, loader, device, config["target_selection"])
        else:
            split_metrics, split_predictions = evaluate_full_context(model, loader, device)
        output[split] = split_metrics
        predictions[split] = split_predictions
    return {"metrics": output, "predictions": predictions}


def run_experiment(args: argparse.Namespace, kind: ModelKind) -> dict[str, Any]:
    set_seed(args.seed)
    torch.manual_seed(args.seed)
    random.seed(args.seed)
    started = time.monotonic()
    run_name = args.run_name or f"transformer_{kind}_s{args.seed}"
    output_dir = args.output_dir or Path("outputs") / ("transformer_rationales" if kind == "rationale" else "transformer_full_context") / run_name
    if output_dir.exists() and any(output_dir.iterdir()):
        raise FileExistsError(f"Refusing to overwrite non-empty output directory: {output_dir}")

    evaluation_mode = getattr(args, "evaluation_mode", "final")
    requested_splits = ("train", "validation") if evaluation_mode == "validation-only" else REQUIRED_SPLITS
    rows = load_dataset_splits(args.data_dir, requested_splits)
    validate_split_files(args.data_dir, requested_splits)
    validate_rows(rows)
    limits = {"train": args.limit_train, "validation": args.limit_val, "test": args.limit_test}
    rows = {split: values[: limits[split]] if limits[split] is not None else values for split, values in rows.items()}
    vocab = build_vocabulary((str(row["text"]) for row in rows["train"]), args.max_vocab, args.min_freq)
    loaders = {
        split: make_loader(TokenDataset(values, vocab, args.max_tokens), args.batch_size, split == "train", args.seed, vocab.pad_id)
        for split, values in rows.items()
    }
    embeddings, embedding_stats = load_pretrained_embeddings(args.embeddings_path, vocab)
    if embeddings.shape[1] != args.model_dim:
        raise ValueError(f"GLoVe dimension {embeddings.shape[1]} must equal --model-dim {args.model_dim}.")

    config: dict[str, Any] = {
        "run_name": run_name,
        "model_kind": kind,
        "data_dir": str(args.data_dir),
        "dataset_version": Path(args.data_dir).name,
        "output_dir": str(output_dir),
        "device_requested": getattr(args, "device", "auto"),
        "git_commit": git_commit(),
        "git_dirty": git_is_dirty(),
        "seed": args.seed,
        "epochs": args.epochs,
        "batch_size": args.batch_size,
        "lr": args.lr,
        "weight_decay": getattr(args, "weight_decay", 0.0),
        "max_grad_norm": args.max_grad_norm,
        "max_vocab": args.max_vocab,
        "min_freq": args.min_freq,
        "max_tokens": args.max_tokens,
        "embeddings_path": str(args.embeddings_path),
        "freeze_embeddings": args.freeze_embeddings,
        "embedding_stats": embedding_stats,
        "target_selection": args.target_selection if kind == "rationale" else None,
        "lambda_sparsity": args.lambda_sparsity if kind == "rationale" else None,
        "lambda_continuity": args.lambda_continuity if kind == "rationale" else None,
        "penalty_mu": args.penalty_mu if kind == "rationale" else None,
        "warmup_steps": args.warmup_steps if kind == "rationale" else None,
        "controller_alpha": args.controller_alpha if kind == "rationale" else None,
        "lagrange_lr": args.lagrange_lr if kind == "rationale" else None,
        "lambda_init": args.lambda_init if kind == "rationale" else None,
        "lambda_max": args.lambda_max if kind == "rationale" else None,
        "inference_mode": "topk" if kind == "rationale" else "full_context",
        "prediction_mode": "hardkuma_topk_tokens" if kind == "rationale" else "transformer_full_context",
        "evaluation_mode": evaluation_mode,
        "pad_id": vocab.pad_id,
        "model": model_config(args, kind),
        "limits": limits,
    }
    device = resolve_device(getattr(args, "device", "auto"))
    model = build_model(config, len(vocab), embeddings).to(device)
    config["device"] = str(device)
    config["parameter_count"] = parameter_count(model)
    optimizer = torch.optim.Adam(
        model.parameters(),
        lr=args.lr,
        betas=(0.9, 0.999),
        eps=1e-8,
        weight_decay=getattr(args, "weight_decay", 0.0),
    )
    steps_per_epoch = len(loaders["train"])
    total_training_steps = args.epochs * steps_per_epoch
    lr_scheduler = None
    lr_warmup_steps = 0
    lr_warmup_fraction = getattr(args, "lr_warmup_fraction", 0.10)
    lr_scheduler, lr_warmup_steps = make_linear_warmup_constant_scheduler(
        optimizer, total_training_steps, lr_warmup_fraction
    )
    config["optimizer"] = {
        "type": "Adam",
        "learning_rate": args.lr,
        "betas": [0.9, 0.999],
        "eps": 1e-8,
        "weight_decay": getattr(args, "weight_decay", 0.0),
    }
    config["lr_scheduler"] = {
        "type": "linear_warmup_then_constant",
        "warmup_fraction": lr_warmup_fraction,
        "warmup_steps": lr_warmup_steps,
        "total_training_steps": total_training_steps,
        "steps_per_epoch": steps_per_epoch,
        "post_warmup": "constant",
    }
    print(f"chosen_device={device}", flush=True)
    if device.type == "cuda":
        print(f"cuda_device_name={torch.cuda.get_device_name(device)}", flush=True)
    print(
        f"parameter_count={config['parameter_count']['total']} "
        f"trainable_parameter_count={config['parameter_count']['trainable']}",
        flush=True,
    )
    print(
        f"lr_scheduler=linear_warmup_then_constant warmup_steps={lr_warmup_steps} "
        f"total_training_steps={total_training_steps}",
        flush=True,
    )
    controller = (
        RateController(
            target=args.target_selection,
            lr=args.lagrange_lr,
            init_lambda=args.lambda_init,
            max_lambda=args.lambda_max,
            warmup_steps=args.warmup_steps,
            alpha=args.controller_alpha,
            penalty_mu=args.penalty_mu,
        )
        if kind == "rationale"
        else None
    )

    best_f1 = -1.0
    best_epoch = 0
    best_state: dict[str, torch.Tensor] | None = None
    history: list[dict[str, float]] = []
    training_started = time.monotonic()
    for epoch in range(1, args.epochs + 1):
        train_metrics = train_epoch(
            model, loaders["train"], optimizer, device, controller, args.lambda_sparsity,
            args.lambda_continuity, args.max_grad_norm, lr_scheduler,
        )
        if kind == "rationale":
            validation, _ = evaluate_rationale(model, loaders["validation"], device, args.target_selection)
        else:
            validation, _ = evaluate_full_context(model, loaders["validation"], device)
        validation_f1 = validation["overall"]["machine_f1"]
        history.append({**train_metrics, "validation_f1": validation_f1})
        print(
            f"epoch={epoch} train_loss={train_metrics['loss']:.4f} "
            f"classification_loss={train_metrics['classification_loss']:.4f} "
            f"expected_selection={train_metrics['expected_selection_rate']:.4f} "
            f"val_f1={validation_f1:.4f}"
        )
        if validation_f1 > best_f1:
            best_f1 = validation_f1
            best_epoch = epoch
            best_state = copy.deepcopy(model.state_dict())
    if best_state is None:
        raise RuntimeError("Training produced no validation checkpoint.")
    training_elapsed = time.monotonic() - training_started
    model.load_state_dict(best_state)

    metrics: dict[str, Any] = {
        "run_name": run_name,
        "best_epoch": best_epoch,
        "best_val_f1": best_f1,
        "train_history": history,
        "parameter_count": config["parameter_count"],
        "device": str(device),
    }
    predictions: dict[str, list[JsonRow]] = {}
    evaluation_splits = ("validation",) if evaluation_mode == "validation-only" else ("validation", "test")
    for split in evaluation_splits:
        if kind == "rationale":
            split_metrics, split_predictions = evaluate_rationale(model, loaders[split], device, args.target_selection)
        else:
            split_metrics, split_predictions = evaluate_full_context(model, loaders[split], device)
        metrics[split] = split_metrics
        predictions[split] = split_predictions
    metrics["training_time_seconds"] = training_elapsed
    total_elapsed = time.monotonic() - started
    metrics["total_run_time_seconds"] = total_elapsed
    config.update(
        {
            "best_epoch": best_epoch,
            "best_val_f1": best_f1,
            "training_time_seconds": training_elapsed,
            "total_run_time_seconds": total_elapsed,
            "splits": {split: len(values) for split, values in rows.items()},
            "vocab_size": len(vocab),
        }
    )
    output_dir.mkdir(parents=True, exist_ok=True)
    save_json(output_dir / "config.json", config)
    save_json(output_dir / "metrics.json", metrics)
    save_json(output_dir / "vocab.json", {"token_to_id": vocab.to_dict()})
    save_checkpoint(output_dir / "model.pt", model, config, vocab)
    save_run_summary(output_dir / "run_summary.md", config, metrics)
    for split, split_predictions in predictions.items():
        write_jsonl(output_dir / f"{split}_predictions.jsonl", split_predictions)
    print(f"training_wall_clock_seconds={training_elapsed:.2f}", flush=True)
    print(f"total_run_wall_clock_seconds={time.monotonic() - started:.2f}", flush=True)
    print(f"best_epoch={best_epoch} best_val_f1={best_f1:.4f} saved={output_dir}")
    return metrics


def add_common_arguments(parser: argparse.ArgumentParser, rationale: bool) -> None:
    parser.add_argument("--data-dir", required=True, type=Path)
    parser.add_argument("--embeddings-path", required=True, type=Path)
    parser.add_argument("--output-dir", default=None, type=Path)
    parser.add_argument("--run-name", default=None)
    parser.add_argument("--device", default="auto", choices=DEVICE_CHOICES)
    parser.add_argument("--epochs", default=25, type=int)
    parser.add_argument("--batch-size", default=32, type=int)
    parser.add_argument("--lr", default=4e-4, type=float)
    parser.add_argument(
        "--lr-warmup-fraction",
        default=0.10,
        type=float,
        help="Fixed fraction of maximum training steps used for linear LR warmup.",
    )
    parser.add_argument("--weight-decay", default=0.0, type=float)
    parser.add_argument("--max-grad-norm", default=5.0, type=float)
    parser.add_argument("--max-vocab", default=10000, type=int)
    parser.add_argument("--min-freq", default=2, type=int)
    parser.add_argument("--max-tokens", default=256, type=int)
    parser.add_argument("--model-dim", default=300, type=int)
    parser.add_argument("--num-heads", default=4, type=int)
    parser.add_argument("--ff-dim", default=600, type=int)
    parser.add_argument("--num-layers", default=2, type=int)
    parser.add_argument("--dropout", default=0.2, type=float)
    parser.add_argument("--freeze-embeddings", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument("--seed", default=42, type=int)
    parser.add_argument("--limit-train", default=None, type=int)
    parser.add_argument("--limit-val", default=None, type=int)
    parser.add_argument("--limit-test", default=None, type=int)
    parser.add_argument(
        "--evaluation-mode",
        choices=("validation-only", "final"),
        default="final",
        help="Validation-only never loads or evaluates test; final evaluates test once after validation selection.",
    )
    if rationale:
        parser.add_argument("--target-selection", default=0.30, type=float)
        parser.add_argument("--lambda-sparsity", default=0.01, type=float)
        parser.add_argument("--lambda-continuity", default=0.0, type=float)
        parser.add_argument("--penalty-mu", default=10.0, type=float)
        parser.add_argument("--warmup-steps", default=300, type=int)
        parser.add_argument("--controller-alpha", default=0.5, type=float)
        parser.add_argument("--lagrange-lr", default=0.02, type=float)
        parser.add_argument("--lambda-init", default=0.02, type=float)
        parser.add_argument("--lambda-max", default=1.0, type=float)
        parser.add_argument("--a-max", default=2.0, type=float)
        parser.add_argument("--b-min", default=0.1, type=float)
    else:
        # Keep a common Namespace so configuration/model helpers stay simple.
        parser.set_defaults(
            target_selection=None, lambda_sparsity=0.0, lambda_continuity=0.0, penalty_mu=0.0,
            warmup_steps=0, controller_alpha=0.5, lagrange_lr=0.02, lambda_init=0.02,
            lambda_max=1.0, a_max=2.0, b_min=0.1,
        )
