from __future__ import annotations

import math

import torch
from torch import nn

from detectgpt.rationales.kuma import HardKumaGate


def select_topk_tokens(gates: list[float], valid_count: int, target_fraction: float) -> tuple[list[int], bool]:
    if valid_count < 1:
        return [], True
    count = min(valid_count, max(1, math.ceil(target_fraction * valid_count)))
    order = sorted(range(valid_count), key=lambda index: gates[index], reverse=True)
    return sorted(order[:count]), False


class LearnedPositionEmbedding(nn.Module):
    def __init__(self, max_tokens: int, model_dim: int) -> None:
        super().__init__()
        self.max_tokens = max_tokens
        self.embedding = nn.Embedding(max_tokens, model_dim)

    def forward(self, input_tensor: torch.Tensor) -> torch.Tensor:
        length = input_tensor.size(1)
        if length > self.max_tokens:
            raise ValueError(f"Sequence length {length} exceeds configured maximum {self.max_tokens}.")
        positions = torch.arange(length, device=input_tensor.device)
        return self.embedding(positions).unsqueeze(0)


def make_encoder(model_dim: int, num_heads: int, ff_dim: int, num_layers: int, dropout: float) -> nn.TransformerEncoder:
    if model_dim % num_heads:
        raise ValueError(f"model_dim ({model_dim}) must be divisible by num_heads ({num_heads}).")
    layer = nn.TransformerEncoderLayer(
        d_model=model_dim,
        nhead=num_heads,
        dim_feedforward=ff_dim,
        dropout=dropout,
        activation="gelu",
        batch_first=True,
        norm_first=True,
    )
    return nn.TransformerEncoder(layer, num_layers=num_layers, enable_nested_tensor=False)


class TransformerRationaleModel(nn.Module):
    """HardKuma selector/predictor with independent Transformer encoders.

    The shared word embedding matches the BiLSTM setup. Selector and predictor
    positional embeddings and encoder parameters are independent. Predictor
    keys/values and pooling are restricted to positions whose gate is nonzero.
    """

    def __init__(
        self,
        vocab_size: int,
        model_dim: int = 300,
        num_heads: int = 4,
        ff_dim: int = 600,
        num_layers: int = 2,
        dropout: float = 0.2,
        max_tokens: int = 256,
        kuma_left: float = -0.1,
        kuma_right: float = 1.1,
        a_max: float = 2.0,
        b_min: float = 0.1,
        pretrained_embeddings: torch.Tensor | None = None,
        freeze_embeddings: bool = False,
        padding_idx: int = 0,
    ) -> None:
        super().__init__()
        if pretrained_embeddings is not None:
            if pretrained_embeddings.shape[1] != model_dim:
                raise ValueError(
                    f"Embedding dimension {pretrained_embeddings.shape[1]} does not match model_dim {model_dim}."
                )
            self.embedding = nn.Embedding.from_pretrained(
                pretrained_embeddings, freeze=freeze_embeddings, padding_idx=padding_idx
            )
        else:
            self.embedding = nn.Embedding(vocab_size, model_dim, padding_idx=padding_idx)
        self.embedding_dropout = nn.Dropout(dropout)
        self.selector_positions = LearnedPositionEmbedding(max_tokens, model_dim)
        self.predictor_positions = LearnedPositionEmbedding(max_tokens, model_dim)
        self.selector_encoder = make_encoder(model_dim, num_heads, ff_dim, num_layers, dropout)
        self.predictor_encoder = make_encoder(model_dim, num_heads, ff_dim, num_layers, dropout)
        self.param_head = nn.Linear(model_dim, 2)
        self.gate = HardKumaGate(left=kuma_left, right=kuma_right, a_max=a_max, b_min=b_min)
        self.classifier = nn.Sequential(nn.Dropout(dropout), nn.Linear(model_dim, 2))

    @staticmethod
    def _validate_mask(mask: torch.Tensor) -> None:
        if mask.ndim != 2:
            raise ValueError(f"mask must have shape [batch, length], got {tuple(mask.shape)}")
        if (~mask.any(dim=1)).any():
            raise ValueError("Every example must contain at least one non-padding token.")

    def embed_tokens(self, input_ids: torch.Tensor) -> torch.Tensor:
        return self.embedding_dropout(self.embedding(input_ids))

    def gate_parameters(self, embeddings: torch.Tensor, mask: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        self._validate_mask(mask)
        selector_input = embeddings + self.selector_positions(embeddings)
        selector_states = self.selector_encoder(selector_input, src_key_padding_mask=~mask)
        raw_params = self.param_head(selector_states)
        a, b = self.gate.raw_to_ab(raw_params[..., 0], raw_params[..., 1])
        return a * mask.float(), b * mask.float()

    def sample_gates(self, a: torch.Tensor, b: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
        return self.gate.sample(a.clamp_min(self.gate.eps), b.clamp_min(self.gate.eps), mask)

    def deterministic_gates(self, a: torch.Tensor, b: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
        return self.gate.deterministic(a.clamp_min(self.gate.eps), b.clamp_min(self.gate.eps), mask)

    def expected_selection(self, a: torch.Tensor, b: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
        return self.gate.probability_nonzero(a.clamp_min(self.gate.eps), b.clamp_min(self.gate.eps), mask)

    def _rescue_empty_gates(
        self, gates: torch.Tensor, expected_gates: torch.Tensor, mask: torch.Tensor
    ) -> tuple[torch.Tensor, torch.Tensor]:
        selected = (gates > 0) & mask
        empty = ~selected.any(dim=1)
        if not empty.any():
            return gates, empty
        candidates = expected_gates.masked_fill(~mask, -1.0)
        fallback_indices = candidates.argmax(dim=1)
        fallback = torch.zeros_like(gates).scatter(1, fallback_indices.unsqueeze(1), 1.0)
        # Use the analytic nonzero probability at the fallback token so the
        # selector still receives a gradient on all-zero sampled rows.
        fallback_weights = fallback * expected_gates.clamp_min(self.gate.eps)
        rescued = torch.where(empty.unsqueeze(1), fallback_weights, gates)
        return rescued, empty

    def predict_from_gates(
        self, embeddings: torch.Tensor, gates: torch.Tensor, mask: torch.Tensor, allow_empty: bool = False
    ) -> torch.Tensor:
        self._validate_mask(mask)
        weights = gates * mask.float()
        selected = (weights > 0) & mask
        empty = ~selected.any(dim=1)
        if empty.any() and not allow_empty:
            raise ValueError("Predictor received an empty rationale; apply an explicit fallback first.")

        attention_selected = selected
        if empty.any():
            first_valid = mask.float().argmax(dim=1)
            rescue = torch.zeros_like(mask).scatter(1, first_valid.unsqueeze(1), True)
            attention_selected = selected | (rescue & empty.unsqueeze(1))

        # Positions are added after word gating, but unselected positions are
        # excluded as keys/values and from pooling. Thus their word identity and
        # positional representation cannot influence a selected representation.
        predictor_input = embeddings * weights.unsqueeze(-1) + self.predictor_positions(embeddings)
        predictor_states = self.predictor_encoder(predictor_input, src_key_padding_mask=~attention_selected)
        pooling_weights = weights * selected.float()
        pooled = (predictor_states * pooling_weights.unsqueeze(-1)).sum(dim=1)
        pooled = pooled / pooling_weights.sum(dim=1, keepdim=True).clamp_min(self.gate.eps)
        return self.classifier(pooled)

    def forward(self, input_ids: torch.Tensor, mask: torch.Tensor) -> dict[str, torch.Tensor]:
        self._validate_mask(mask)
        embeddings = self.embed_tokens(input_ids)
        a, b = self.gate_parameters(embeddings, mask)
        expected_gates = self.expected_selection(a, b, mask)
        sampled_gates = self.sample_gates(a, b, mask)
        gates, fallback_rows = self._rescue_empty_gates(sampled_gates, expected_gates, mask)
        logits = self.predict_from_gates(embeddings, gates, mask)

        lengths = mask.float().sum(dim=1)
        expected_selection_rate = (expected_gates.sum(dim=1) / lengths).mean()
        adjacent_mask = mask[:, 1:] & mask[:, :-1]
        adjacent_diffs = (gates[:, 1:] - gates[:, :-1]).abs() * adjacent_mask.float()
        continuity_loss = adjacent_diffs.sum() / adjacent_mask.float().sum().clamp_min(1.0)
        return {
            "logits": logits,
            "embeddings": embeddings,
            "a": a,
            "b": b,
            "gates": gates,
            "expected_gates": expected_gates,
            "expected_selection_rate": expected_selection_rate,
            "continuity_loss": continuity_loss,
            "empty_selection_fallback_count": fallback_rows.sum(),
        }


class FullContextTransformerClassifier(nn.Module):
    """Matched Transformer classifier with no selector or rationale mask."""

    def __init__(
        self,
        vocab_size: int,
        model_dim: int = 300,
        num_heads: int = 4,
        ff_dim: int = 600,
        num_layers: int = 2,
        dropout: float = 0.2,
        max_tokens: int = 256,
        pretrained_embeddings: torch.Tensor | None = None,
        freeze_embeddings: bool = False,
        padding_idx: int = 0,
    ) -> None:
        super().__init__()
        if pretrained_embeddings is not None:
            if pretrained_embeddings.shape[1] != model_dim:
                raise ValueError(
                    f"Embedding dimension {pretrained_embeddings.shape[1]} does not match model_dim {model_dim}."
                )
            self.embedding = nn.Embedding.from_pretrained(
                pretrained_embeddings, freeze=freeze_embeddings, padding_idx=padding_idx
            )
        else:
            self.embedding = nn.Embedding(vocab_size, model_dim, padding_idx=padding_idx)
        self.embedding_dropout = nn.Dropout(dropout)
        self.positions = LearnedPositionEmbedding(max_tokens, model_dim)
        self.encoder = make_encoder(model_dim, num_heads, ff_dim, num_layers, dropout)
        self.classifier = nn.Sequential(nn.Dropout(dropout), nn.Linear(model_dim, 2))

    def forward(self, input_ids: torch.Tensor, mask: torch.Tensor) -> dict[str, torch.Tensor]:
        TransformerRationaleModel._validate_mask(mask)
        embeddings = self.embedding_dropout(self.embedding(input_ids))
        states = self.encoder(embeddings + self.positions(embeddings), src_key_padding_mask=~mask)
        pooled = (states * mask.unsqueeze(-1)).sum(dim=1) / mask.sum(dim=1, keepdim=True)
        return {"logits": self.classifier(pooled)}
