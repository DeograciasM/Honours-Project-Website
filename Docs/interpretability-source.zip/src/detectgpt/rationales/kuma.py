from __future__ import annotations

import torch
from torch import nn


class HardKumaGate(nn.Module):
    """Stretched Kumaraswamy gates for learned token rationale selection."""

    def __init__(
        self,
        left: float = -0.1,
        right: float = 1.1,
        eps: float = 1e-6,
        a_min: float = 0.01,
        a_max: float = 2.0,
        b_min: float = 0.1,
        b_max: float = 10.0,
    ) -> None:
        super().__init__()
        self.left = left
        self.right = right
        self.eps = eps
        self.a_min = a_min
        self.a_max = a_max
        self.b_min = b_min
        self.b_max = b_max

    def raw_to_ab(self, raw_a: torch.Tensor, raw_b: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        """Bounded sigmoid parameterisation of the Kumaraswamy shape params.

        Sigmoid (not clamp) so gradients survive at the boundaries.
        """
        a = self.a_min + (self.a_max - self.a_min) * torch.sigmoid(raw_a)
        b = self.b_min + (self.b_max - self.b_min) * torch.sigmoid(raw_b)
        return a, b

    def sample(self, a: torch.Tensor, b: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
        u = torch.rand_like(a).clamp(self.eps, 1.0 - self.eps)
        y = (1.0 - (1.0 - u).pow(1.0 / b)).pow(1.0 / a)
        z = self._stretch_and_clip(y)
        return z * mask.float()

    def deterministic(self, a: torch.Tensor, b: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
        y = (1.0 - 0.5 ** (1.0 / b)).pow(1.0 / a)
        z = self._stretch_and_clip(y)
        return z * mask.float()

    def probability_nonzero(self, a: torch.Tensor, b: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
        boundary = torch.tensor(
            (0.0 - self.left) / (self.right - self.left),
            device=a.device,
            dtype=a.dtype,
        ).clamp(self.eps, 1.0 - self.eps)
        cdf_at_zero = 1.0 - (1.0 - boundary.pow(a)).pow(b)
        return (1.0 - cdf_at_zero) * mask.float()

    def probability_zero(self, a: torch.Tensor, b: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
        """P(z == 0) = F_Kumaraswamy(boundary0), the rectification's left tail mass.

        Kept independent from `probability_nonzero` (rather than `1 -
        probability_nonzero`) so the two are useful as cross-checks of each
        other in tests, and so this file's behaviour for existing callers of
        `probability_nonzero` is untouched.
        """
        boundary = torch.tensor(
            (0.0 - self.left) / (self.right - self.left),
            device=a.device,
            dtype=a.dtype,
        ).clamp(self.eps, 1.0 - self.eps)
        cdf_at_zero = 1.0 - (1.0 - boundary.pow(a)).pow(b)
        return cdf_at_zero * mask.float()

    def probability_one(self, a: torch.Tensor, b: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
        """P(z == 1) = 1 - F_Kumaraswamy(boundary1), the rectification's right tail mass."""
        boundary = torch.tensor(
            (1.0 - self.left) / (self.right - self.left),
            device=a.device,
            dtype=a.dtype,
        ).clamp(self.eps, 1.0 - self.eps)
        survival_at_one = (1.0 - boundary.pow(a)).pow(b)
        return survival_at_one * mask.float()

    def _stretch_and_clip(self, y: torch.Tensor) -> torch.Tensor:
        z = y * (self.right - self.left) + self.left
        return z.clamp(0.0, 1.0)
