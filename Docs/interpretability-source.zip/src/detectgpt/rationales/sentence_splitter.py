from __future__ import annotations

import re
from dataclasses import dataclass


_SENTENCE_RE = re.compile(r"\S.*?(?:[.!?]+(?=\s+|$)|$)", re.DOTALL)


@dataclass(frozen=True)
class SentenceSpan:
    """A sentence and its character offsets in the original text."""

    text: str
    start: int
    end: int


def split_sentences(text: str) -> list[SentenceSpan]:
    """Split text into sentence-like spans while preserving offsets."""
    spans: list[SentenceSpan] = []

    for match in _SENTENCE_RE.finditer(text):
        sentence = match.group(0).strip()
        if not sentence:
            continue

        leading = len(match.group(0)) - len(match.group(0).lstrip())
        trailing = len(match.group(0).rstrip())
        start = match.start() + leading
        end = match.start() + trailing
        spans.append(SentenceSpan(text=sentence, start=start, end=end))

    if spans:
        return spans

    stripped = text.strip()
    if stripped:
        start = text.find(stripped)
        return [SentenceSpan(text=stripped, start=start, end=start + len(stripped))]

    return [SentenceSpan(text="", start=0, end=0)]
