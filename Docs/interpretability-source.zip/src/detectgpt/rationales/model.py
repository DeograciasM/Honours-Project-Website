from __future__ import annotations

import torch
from torch import nn


class SentenceRationaleModel(nn.Module):
    """Sentence-level selector-predictor for binary machine-text detection."""

    def __init__(self, vocab_size: int, embedding_dim: int = 128, hidden_dim: int = 128, dropout: float = 0.2) -> None:
        super().__init__()
        self.embedding = nn.Embedding(vocab_size, embedding_dim, padding_idx=0)
        self.sentence_projection = nn.Sequential(
            nn.Linear(embedding_dim, hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
        )
        self.selector = nn.Linear(hidden_dim, 1)
        self.predictor = nn.Sequential(
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, 2),
        )

    def encode_sentences(
        self,
        input_ids: torch.Tensor,
        token_mask: torch.Tensor,
    ) -> torch.Tensor:
        """Encode tokens into one representation per sentence."""
        embeddings = self.embedding(input_ids)
        token_mask_float = token_mask.unsqueeze(-1).float()
        token_counts = token_mask_float.sum(dim=2).clamp_min(1.0)
        sentence_embeddings = (embeddings * token_mask_float).sum(dim=2) / token_counts
        return self.sentence_projection(sentence_embeddings)

    def compute_selection_probabilities(
        self,
        sentence_representations: torch.Tensor,
        sentence_mask: torch.Tensor,
    ) -> torch.Tensor:
        """Compute selector probabilities for valid sentences."""
        raw_selection_logits = self.selector(sentence_representations).squeeze(-1)
        selection_logits = raw_selection_logits.masked_fill(~sentence_mask, -1e4)
        return torch.sigmoid(selection_logits) * sentence_mask.float()

    def predict_from_sentence_weights(
        self,
        sentence_representations: torch.Tensor,
        sentence_weights: torch.Tensor,
    ) -> torch.Tensor:
        """Classify from sentence representations using supplied sentence weights."""
        weighted_sentences = sentence_representations * sentence_weights.unsqueeze(-1)
        selection_mass = sentence_weights.sum(dim=1, keepdim=True).clamp_min(1e-6)
        document_representation = weighted_sentences.sum(dim=1) / selection_mass
        return self.predictor(document_representation)

    def predict_from_hard_mask(
        self,
        sentence_representations: torch.Tensor,
        hard_sentence_mask: torch.Tensor,
    ) -> torch.Tensor:
        """Classify from hard-selected sentences only."""
        return self.predict_from_sentence_weights(sentence_representations, hard_sentence_mask.float())

    def forward(
        self,
        input_ids: torch.Tensor,
        token_mask: torch.Tensor,
        sentence_mask: torch.Tensor,
    ) -> dict[str, torch.Tensor]:
        sentence_representations = self.encode_sentences(input_ids, token_mask)
        selection_probabilities = self.compute_selection_probabilities(sentence_representations, sentence_mask)
        logits = self.predict_from_sentence_weights(sentence_representations, selection_probabilities)

        valid_sentence_count = sentence_mask.float().sum(dim=1).clamp_min(1.0)
        mean_selection_probability = (selection_probabilities.sum(dim=1) / valid_sentence_count).mean()

        return {
            "logits": logits,
            "sentence_representations": sentence_representations,
            "selection_probabilities": selection_probabilities,
            "mean_selection_probability": mean_selection_probability,
        }
