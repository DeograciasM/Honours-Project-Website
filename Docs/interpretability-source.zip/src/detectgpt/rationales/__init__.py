"""Rationale models and utilities."""
