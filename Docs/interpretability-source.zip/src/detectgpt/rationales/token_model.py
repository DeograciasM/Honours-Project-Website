from __future__ import annotations

import torch
from torch import nn


class TokenRationaleModel(nn.Module):
    """Token-level selector-predictor for binary machine-text detection."""

    def __init__(self, vocab_size: int, embed_dim: int = 128, hidden_dim: int = 128, dropout: float = 0.2) -> None:
        super().__init__()
        self.embedding = nn.Embedding(vocab_size, embed_dim, padding_idx=0)
        self.dropout = nn.Dropout(dropout)
        self.selector = nn.LSTM(
            input_size=embed_dim,
            hidden_size=hidden_dim,
            batch_first=True,
            bidirectional=True,
        )
        self.selector_head = nn.Linear(hidden_dim * 2, 1)
        self.predictor = nn.LSTM(
            input_size=embed_dim,
            hidden_size=hidden_dim,
            batch_first=True,
            bidirectional=True,
        )
        self.classifier = nn.Sequential(
            nn.Dropout(dropout),
            nn.Linear(hidden_dim * 2, 2),
        )

    def embed_tokens(self, input_ids: torch.Tensor) -> torch.Tensor:
        return self.dropout(self.embedding(input_ids))

    def selection_probs_from_embeddings(self, embeddings: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
        selector_states, _ = self.selector(embeddings)
        logits = self.selector_head(selector_states).squeeze(-1)
        logits = logits.masked_fill(~mask, -1e4)
        return torch.sigmoid(logits) * mask.float()

    def predict_from_weights(
        self,
        embeddings: torch.Tensor,
        token_weights: torch.Tensor,
        mask: torch.Tensor,
    ) -> torch.Tensor:
        """Classify from embeddings after masking unselected token evidence."""
        weights = token_weights * mask.float()
        predictor_input = embeddings * weights.unsqueeze(-1)
        predictor_states, _ = self.predictor(predictor_input)
        weighted_states = predictor_states * weights.unsqueeze(-1)
        denom = weights.sum(dim=1, keepdim=True).clamp_min(1e-6)
        pooled = weighted_states.sum(dim=1) / denom
        return self.classifier(pooled)

    def forward(self, input_ids: torch.Tensor, mask: torch.Tensor) -> dict[str, torch.Tensor]:
        embeddings = self.embed_tokens(input_ids)
        selection_probs = self.selection_probs_from_embeddings(embeddings, mask)
        logits = self.predict_from_weights(embeddings, selection_probs, mask)

        lengths = mask.float().sum(dim=1).clamp_min(1.0)
        mean_selection_probability = (selection_probs.sum(dim=1) / lengths).mean()

        adjacent_mask = mask[:, 1:] & mask[:, :-1]
        adjacent_diffs = (selection_probs[:, 1:] - selection_probs[:, :-1]).abs() * adjacent_mask.float()
        mean_adjacent_probability_difference = adjacent_diffs.sum() / adjacent_mask.float().sum().clamp_min(1.0)

        return {
            "logits": logits,
            "embeddings": embeddings,
            "selection_probabilities": selection_probs,
            "mean_selection_probability": mean_selection_probability,
            "mean_adjacent_probability_difference": mean_adjacent_probability_difference,
        }
