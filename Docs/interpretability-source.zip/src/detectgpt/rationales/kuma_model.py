from __future__ import annotations

from pathlib import Path
from typing import Any

import torch
from torch import nn
from torch.nn.utils.rnn import pack_padded_sequence, pad_packed_sequence

from detectgpt.rationales.kuma import HardKumaGate
from detectgpt.rationales.vocab import PAD_TOKEN, UNK_TOKEN, Vocabulary


def load_pretrained_embeddings(
    path: str | Path,
    vocab: Vocabulary,
    oov_std: float = 0.1,
) -> tuple[torch.Tensor, dict[str, Any]]:
    """Build an embedding matrix aligned to `vocab` from a GloVe-format text file.

    The file is lowercase-only (GloVe 6B convention); tokens are lowercased
    only for this lookup, not for tokenisation elsewhere. Rows for tokens
    absent from the file are drawn from N(0, oov_std); the pad row is zeroed.
    """
    vectors: dict[str, list[float]] = {}
    embed_dim: int | None = None
    with open(path, "r", encoding="utf-8") as handle:
        for line in handle:
            parts = line.rstrip("\n").split(" ")
            if len(parts) < 2:
                continue
            token, values = parts[0], parts[1:]
            if embed_dim is None:
                embed_dim = len(values)
            elif len(values) != embed_dim:
                continue
            vectors[token] = [float(value) for value in values]

    if embed_dim is None:
        raise ValueError(f"No embeddings parsed from {path}")

    matrix = torch.empty((len(vocab), embed_dim), dtype=torch.float32)
    matrix.normal_(mean=0.0, std=oov_std)
    matrix[vocab.pad_id].zero_()

    hits = 0
    exact_hits = 0
    lowercase_fallback_hits = 0
    considered = 0
    for token, index in vocab.token_to_id.items():
        if token in (PAD_TOKEN, UNK_TOKEN):
            continue
        considered += 1
        vector = vectors.get(token)
        if vector is not None:
            exact_hits += 1
        elif token.lower() != token:
            vector = vectors.get(token.lower())
            if vector is not None:
                lowercase_fallback_hits += 1
        if vector is not None:
            matrix[index] = torch.tensor(vector, dtype=torch.float32)
            hits += 1

    stats = {
        "embed_dim": embed_dim,
        "vocab_considered": considered,
        "vocab_hits": hits,
        "exact_token_hits": exact_hits,
        "lowercase_fallback_hits": lowercase_fallback_hits,
        "exact_token_hit_rate": exact_hits / considered if considered else 0.0,
        "lowercase_fallback_hit_rate": lowercase_fallback_hits / considered if considered else 0.0,
        "oov_rate": 1.0 - (hits / considered if considered else 0.0),
    }
    return matrix, stats


class KumaRationaleModel(nn.Module):
    """Bastings-style token selector-predictor with learned HardKuma gates."""

    def __init__(
        self,
        vocab_size: int,
        embed_dim: int = 128,
        hidden_dim: int = 128,
        dropout: float = 0.2,
        kuma_left: float = -0.1,
        kuma_right: float = 1.1,
        a_max: float = 2.0,
        b_min: float = 0.1,
        coherence_mode: str = "transitions",
        pretrained_embeddings: torch.Tensor | None = None,
        freeze_embeddings: bool = True,
        padding_idx: int = 0,
    ) -> None:
        super().__init__()
        if coherence_mode not in ("magnitude", "transitions"):
            raise ValueError(f"Unknown coherence_mode: {coherence_mode!r}")
        self.coherence_mode = coherence_mode
        if pretrained_embeddings is not None:
            # Embedding dim follows the pretrained file, not the embed_dim arg.
            embed_dim = pretrained_embeddings.shape[1]
            self.embedding = nn.Embedding.from_pretrained(
                pretrained_embeddings, freeze=freeze_embeddings, padding_idx=padding_idx
            )
        else:
            self.embedding = nn.Embedding(vocab_size, embed_dim, padding_idx=padding_idx)
        self.dropout = nn.Dropout(dropout)
        self.selector_encoder = nn.LSTM(
            input_size=embed_dim,
            hidden_size=hidden_dim,
            batch_first=True,
            bidirectional=True,
        )
        self.param_head = nn.Linear(hidden_dim * 2, 2)
        self.gate = HardKumaGate(left=kuma_left, right=kuma_right, a_max=a_max, b_min=b_min)
        self.predictor_encoder = nn.LSTM(
            input_size=embed_dim,
            hidden_size=hidden_dim,
            batch_first=True,
            bidirectional=True,
        )
        self.classifier = nn.Sequential(
            nn.Dropout(dropout),
            nn.Linear(hidden_dim * 2, 2),
        )

    def embed_tokens(self, input_ids: torch.Tensor) -> torch.Tensor:
        return self.dropout(self.embedding(input_ids))

    @staticmethod
    def _encode_real_tokens(encoder: nn.LSTM, inputs: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
        """Run an LSTM without letting trailing padding affect real states."""
        lengths = mask.sum(dim=1)
        if (lengths < 1).any():
            raise ValueError("Every document must contain at least one real token.")
        packed = pack_padded_sequence(inputs, lengths.cpu(), batch_first=True, enforce_sorted=False)
        packed_states, _ = encoder(packed)
        states, _ = pad_packed_sequence(packed_states, batch_first=True, total_length=inputs.size(1))
        return states

    def gate_parameters(self, embeddings: torch.Tensor, mask: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        selector_states = self._encode_real_tokens(self.selector_encoder, embeddings, mask)
        raw_params = self.param_head(selector_states)
        a, b = self.gate.raw_to_ab(raw_params[..., 0], raw_params[..., 1])
        return a * mask.float(), b * mask.float()

    def sample_gates(self, a: torch.Tensor, b: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
        return self.gate.sample(a.clamp_min(self.gate.eps), b.clamp_min(self.gate.eps), mask)

    def deterministic_gates(self, a: torch.Tensor, b: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
        return self.gate.deterministic(a.clamp_min(self.gate.eps), b.clamp_min(self.gate.eps), mask)

    def expected_selection(self, a: torch.Tensor, b: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
        return self.gate.probability_nonzero(a.clamp_min(self.gate.eps), b.clamp_min(self.gate.eps), mask)

    def predict_from_gates(self, embeddings: torch.Tensor, gates: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
        """Classify from embeddings masked before predictor contextual encoding."""
        weights = gates * mask.float()
        predictor_input = embeddings * weights.unsqueeze(-1)
        predictor_states = self._encode_real_tokens(self.predictor_encoder, predictor_input, mask)
        weighted_states = predictor_states * weights.unsqueeze(-1)
        denom = weights.sum(dim=1, keepdim=True).clamp_min(1e-6)
        pooled = weighted_states.sum(dim=1) / denom
        return self.classifier(pooled)

    def forward(self, input_ids: torch.Tensor, mask: torch.Tensor) -> dict[str, torch.Tensor]:
        embeddings = self.embed_tokens(input_ids)
        a, b = self.gate_parameters(embeddings, mask)
        gates = self.sample_gates(a, b, mask)
        expected_gates = self.expected_selection(a, b, mask)
        logits = self.predict_from_gates(embeddings, gates, mask)

        lengths = mask.float().sum(dim=1).clamp_min(1.0)
        expected_selection_rate = (expected_gates.sum(dim=1) / lengths).mean()

        adjacent_mask = mask[:, 1:] & mask[:, :-1]

        if self.coherence_mode == "magnitude":
            # Sampled-gate magnitude differences between adjacent real tokens.
            adjacent_diffs = (gates[:, 1:] - gates[:, :-1]).abs() * adjacent_mask.float()
            continuity_loss = adjacent_diffs.sum() / adjacent_mask.float().sum().clamp_min(1.0)
        else:
            # "transitions": analytic P(z=0) transition probability between
            # adjacent real tokens, summed per document, divided by document
            # length, averaged over the batch. Penalises expected zero/nonzero
            # transitions rather than sampled magnitude differences.
            p_zero = (1.0 - expected_gates) * mask.float()
            p_zero_i = p_zero[:, :-1]
            p_zero_j = p_zero[:, 1:]
            transition_term = (
                p_zero_i * (1.0 - p_zero_j) + (1.0 - p_zero_i) * p_zero_j
            ) * adjacent_mask.float()
            continuity_loss = (transition_term.sum(dim=1) / lengths).mean()

        return {
            "logits": logits,
            "embeddings": embeddings,
            "a": a,
            "b": b,
            "gates": gates,
            "expected_gates": expected_gates,
            "expected_selection_rate": expected_selection_rate,
            "transition_rate": continuity_loss,
            "continuity_loss": continuity_loss,
        }
