from __future__ import annotations

from pathlib import Path
from typing import Any


def write_run_summary(path: str | Path, run_name: str, config: dict[str, Any], metrics: dict[str, Any]) -> None:
    """Write a concise Markdown summary for a rationale run."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    model_type = config.get("model", {}).get("type", "sentence_rationale")
    token_models = {"token_rationale", "kuma_rationale"}
    selected_count_key = "average_selected_tokens" if model_type in token_models else "average_selected_sentences"
    selected_count_label = "Avg Selected Tokens" if model_type in token_models else "Avg Selected Sentences"

    lines = [
        f"# {run_name}",
        "",
        "## Model",
        "",
        f"- Type: {model_type}",
        f"- Epochs: {config['epochs']}",
        f"- Batch size: {config['batch_size']}",
        f"- Learning rate: {config['lr']}",
        f"- Sparsity lambda: {config['lambda_sparsity']}",
        f"- Full-text lambda: {config['lambda_full']}" if "lambda_full" in config else None,
        f"- Target lambda: {config['lambda_target']}" if "lambda_target" in config else None,
        f"- Train hard mask: {config['train_hard_mask']}" if "train_hard_mask" in config else None,
        f"- Selection fraction: {config['selection_fraction']}" if config.get("selection_fraction") is not None else None,
        f"- Gate threshold: {config['gate_threshold']}" if config.get("gate_threshold") is not None else None,
        f"- Selection threshold: {config['threshold']}" if config.get("threshold") is not None else None,
        f"- Prediction mode: {config['prediction_mode']}",
        f"- Avg soft selection: {metrics['avg_soft_selection']:.4f}" if "avg_soft_selection" in metrics else None,
        f"- Empty-selection fallback count: {metrics['test']['rationales']['empty_selection_fallback_count']}"
        if metrics.get("test", {}).get("rationales", {}).get("empty_selection_fallback_count") is not None
        else None,
        "",
        "## Metrics",
        "",
        f"| Split | Accuracy | Machine Precision | Machine Recall | Machine F1 | Avg Selected Fraction | {selected_count_label} | Mean Sufficiency Drop | Mean Comprehensiveness Drop |",
        "| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |",
    ]
    lines = [line for line in lines if line is not None]

    for split in ("validation", "test"):
        if split not in metrics:
            if split == "test":
                lines.extend(["", "Test evaluation was not performed for this validation-only run."])
            continue
        overall = metrics[split]["overall"]
        rationale = metrics[split]["rationales"]
        lines.append(
            f"| {split} | {overall['accuracy']:.4f} | {overall['machine_precision']:.4f} | "
            f"{overall['machine_recall']:.4f} | {overall['machine_f1']:.4f} | "
            f"{rationale['average_selected_fraction']:.4f} | "
            f"{rationale[selected_count_key]:.4f} | "
            f"{rationale['mean_sufficiency_drop']:.4f} | "
            f"{rationale['mean_comprehensiveness_drop']:.4f} |"
        )

    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
