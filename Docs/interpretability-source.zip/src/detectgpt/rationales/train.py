from __future__ import annotations

import argparse
import json
import math
import random
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np
import torch
from torch import nn
from torch.utils.data import DataLoader, Dataset

from detectgpt.data.io import JsonRow, load_dataset_splits, write_jsonl
from detectgpt.data.validation import REQUIRED_SPLITS, validate_dataset
from detectgpt.evaluation.metrics import evaluate_split
from detectgpt.rationales.model import SentenceRationaleModel
from detectgpt.rationales.reporting import write_run_summary
from detectgpt.rationales.sentence_splitter import SentenceSpan, split_sentences
from detectgpt.rationales.vocab import Vocabulary, build_vocabulary
from detectgpt.utils.seed import set_seed


@dataclass
class RationaleExample:
    row: JsonRow
    sentences: list[SentenceSpan]
    token_ids: list[list[int]]
    label_id: int


class RationaleDataset(Dataset[RationaleExample]):
    def __init__(
        self,
        rows: list[JsonRow],
        vocabulary: Vocabulary,
        max_sentences: int,
        max_tokens_per_sentence: int,
    ) -> None:
        self.examples: list[RationaleExample] = []
        for row in rows:
            sentences = split_sentences(str(row["text"]))[:max_sentences]
            token_ids = [
                vocabulary.encode(sentence.text, max_tokens=max_tokens_per_sentence)
                for sentence in sentences
            ]
            self.examples.append(
                RationaleExample(
                    row=row,
                    sentences=sentences,
                    token_ids=token_ids,
                    label_id=int(row["label_id"]),
                )
            )

    def __len__(self) -> int:
        return len(self.examples)

    def __getitem__(self, index: int) -> RationaleExample:
        return self.examples[index]


def collate_examples(examples: list[RationaleExample], pad_id: int) -> dict[str, Any]:
    batch_size = len(examples)
    max_sentences = max(len(example.token_ids) for example in examples)
    max_tokens = max(len(tokens) for example in examples for tokens in example.token_ids)

    input_ids = torch.full((batch_size, max_sentences, max_tokens), pad_id, dtype=torch.long)
    token_mask = torch.zeros((batch_size, max_sentences, max_tokens), dtype=torch.bool)
    sentence_mask = torch.zeros((batch_size, max_sentences), dtype=torch.bool)
    labels = torch.tensor([example.label_id for example in examples], dtype=torch.long)

    for batch_index, example in enumerate(examples):
        for sentence_index, sentence_token_ids in enumerate(example.token_ids):
            token_count = len(sentence_token_ids)
            input_ids[batch_index, sentence_index, :token_count] = torch.tensor(sentence_token_ids, dtype=torch.long)
            token_mask[batch_index, sentence_index, :token_count] = True
            sentence_mask[batch_index, sentence_index] = True

    return {
        "input_ids": input_ids,
        "token_mask": token_mask,
        "sentence_mask": sentence_mask,
        "labels": labels,
        "examples": examples,
    }


def make_loader(dataset: RationaleDataset, batch_size: int, shuffle: bool, seed: int, pad_id: int) -> DataLoader:
    generator = torch.Generator()
    generator.manual_seed(seed)
    return DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=shuffle,
        collate_fn=lambda examples: collate_examples(examples, pad_id),
        generator=generator,
    )


def train_epoch(
    model: SentenceRationaleModel,
    loader: DataLoader,
    optimizer: torch.optim.Optimizer,
    loss_fn: nn.Module,
    device: torch.device,
    lambda_sparsity: float,
    lambda_full: float,
) -> dict[str, float]:
    model.train()
    total_loss = 0.0
    total_rationale_loss = 0.0
    total_full_loss = 0.0
    total_selection = 0.0
    total_examples = 0

    for batch in loader:
        input_ids = batch["input_ids"].to(device)
        token_mask = batch["token_mask"].to(device)
        sentence_mask = batch["sentence_mask"].to(device)
        labels = batch["labels"].to(device)

        optimizer.zero_grad()
        outputs = model(input_ids, token_mask, sentence_mask)
        rationale_loss = loss_fn(outputs["logits"], labels)
        full_logits = model.predict_from_hard_mask(outputs["sentence_representations"], sentence_mask)
        full_loss = loss_fn(full_logits, labels)
        mean_selection = outputs["mean_selection_probability"]
        loss = rationale_loss + lambda_full * full_loss + lambda_sparsity * mean_selection
        loss.backward()
        optimizer.step()

        batch_size = labels.size(0)
        total_loss += float(loss.item()) * batch_size
        total_rationale_loss += float(rationale_loss.item()) * batch_size
        total_full_loss += float(full_loss.item()) * batch_size
        total_selection += float(mean_selection.item()) * batch_size
        total_examples += batch_size

    denominator = max(1, total_examples)
    return {
        "loss": total_loss / denominator,
        "rationale_loss": total_rationale_loss / denominator,
        "full_loss": total_full_loss / denominator,
        "avg_soft_selection": total_selection / denominator,
    }


def hard_select_sentences(
    probabilities: list[float],
    valid_count: int,
    selection_fraction: float,
    threshold: float | None = None,
) -> list[int]:
    valid_probabilities = probabilities[:valid_count]
    if threshold is not None:
        selected = [index for index, probability in enumerate(valid_probabilities) if probability >= threshold]
        if selected:
            return selected

    selected_count = max(1, math.ceil(selection_fraction * valid_count))
    selected_count = min(selected_count, valid_count)
    ranked_indices = np.argsort(valid_probabilities)[-selected_count:]
    return sorted(int(index) for index in ranked_indices)


def evaluate_model(
    model: SentenceRationaleModel,
    loader: DataLoader,
    device: torch.device,
    selection_fraction: float,
    threshold: float | None,
) -> tuple[list[int], list[JsonRow], list[JsonRow]]:
    model.eval()
    predicted_labels: list[int] = []
    metric_rows: list[JsonRow] = []
    prediction_rows: list[JsonRow] = []

    with torch.no_grad():
        for batch in loader:
            input_ids = batch["input_ids"].to(device)
            token_mask = batch["token_mask"].to(device)
            sentence_mask = batch["sentence_mask"].to(device)
            sentence_representations = model.encode_sentences(input_ids, token_mask)
            selection_probabilities_tensor = model.compute_selection_probabilities(sentence_representations, sentence_mask)
            selection_probabilities = selection_probabilities_tensor.cpu().numpy()
            sentence_masks = batch["sentence_mask"].cpu().numpy()
            hard_sentence_mask = torch.zeros_like(selection_probabilities_tensor, dtype=torch.bool)

            selected_indices_by_example: list[list[int]] = []
            for batch_index, (sentence_probs, valid_mask) in enumerate(
                zip(selection_probabilities.tolist(), sentence_masks.tolist(), strict=True)
            ):
                valid_count = int(sum(valid_mask))
                selected_indices = hard_select_sentences(
                    sentence_probs,
                    valid_count,
                    selection_fraction=selection_fraction,
                    threshold=threshold,
                )
                selected_indices_by_example.append(selected_indices)
                hard_sentence_mask[batch_index, selected_indices] = True

            rationale_logits = model.predict_from_hard_mask(sentence_representations, hard_sentence_mask)
            full_logits = model.predict_from_hard_mask(sentence_representations, sentence_mask)
            without_rationale_mask = sentence_mask & ~hard_sentence_mask
            without_rationale_logits = model.predict_from_hard_mask(sentence_representations, without_rationale_mask)

            rationale_probabilities = torch.softmax(rationale_logits, dim=1)
            full_probabilities = torch.softmax(full_logits, dim=1)
            without_rationale_probabilities = torch.softmax(without_rationale_logits, dim=1)
            machine_probabilities = rationale_probabilities[:, 1].cpu().numpy()
            predictions = (machine_probabilities >= 0.5).astype(int).tolist()

            for local_batch_index, (
                example,
                predicted_label,
                machine_probability,
                sentence_probs,
                valid_mask,
                selected_indices,
            ) in enumerate(
                zip(
                    batch["examples"],
                    predictions,
                    machine_probabilities.tolist(),
                    selection_probabilities.tolist(),
                    sentence_masks.tolist(),
                    selected_indices_by_example,
                    strict=True,
                )
            ):
                valid_count = int(sum(valid_mask))
                selected_sentences = [example.sentences[index].text for index in selected_indices]
                selected_fraction = len(selected_indices) / max(1, valid_count)
                predicted_class = int(predicted_label)
                full_class_probability = float(full_probabilities[local_batch_index, predicted_class].item())
                rationale_class_probability = float(rationale_probabilities[local_batch_index, predicted_class].item())
                without_rationale_class_probability = float(
                    without_rationale_probabilities[local_batch_index, predicted_class].item()
                )
                sufficiency_drop = full_class_probability - rationale_class_probability
                comprehensiveness_drop = full_class_probability - without_rationale_class_probability

                predicted_labels.append(int(predicted_label))
                metric_rows.append(example.row)
                prediction_rows.append(
                    {
                        "id": example.row["id"],
                        "gold_label": example.row["label"],
                        "predicted_label": "machine" if predicted_label == 1 else "human",
                        "machine_probability": float(machine_probability),
                        "selected_sentence_indices": selected_indices,
                        "selected_sentences": selected_sentences,
                        "selection_probabilities": [float(probability) for probability in sentence_probs[:valid_count]],
                        "selected_fraction": float(selected_fraction),
                        "selection_fraction": selection_fraction,
                        "prediction_mode": "hard_selected_rationales_only",
                        "full_text_probability_for_predicted_class": full_class_probability,
                        "rationale_only_probability_for_predicted_class": rationale_class_probability,
                        "without_rationale_probability_for_predicted_class": without_rationale_class_probability,
                        "sufficiency_drop": float(sufficiency_drop),
                        "comprehensiveness_drop": float(comprehensiveness_drop),
                        "domain": example.row["domain"],
                        "generator": example.row["generator"],
                    }
                )

    return predicted_labels, metric_rows, prediction_rows


def rationale_metrics(prediction_rows: list[JsonRow]) -> dict[str, float]:
    selected_counts = [len(row["selected_sentence_indices"]) for row in prediction_rows]
    selected_fractions = [float(row["selected_fraction"]) for row in prediction_rows]
    sufficiency_drops = [float(row["sufficiency_drop"]) for row in prediction_rows]
    comprehensiveness_drops = [float(row["comprehensiveness_drop"]) for row in prediction_rows]
    return {
        "average_selected_fraction": float(np.mean(selected_fractions)) if selected_fractions else 0.0,
        "average_selected_sentences": float(np.mean(selected_counts)) if selected_counts else 0.0,
        "mean_sufficiency_drop": float(np.mean(sufficiency_drops)) if sufficiency_drops else 0.0,
        "mean_comprehensiveness_drop": float(np.mean(comprehensiveness_drops)) if comprehensiveness_drops else 0.0,
        "median_sufficiency_drop": float(np.median(sufficiency_drops)) if sufficiency_drops else 0.0,
        "median_comprehensiveness_drop": float(np.median(comprehensiveness_drops)) if comprehensiveness_drops else 0.0,
    }


def save_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def save_model_checkpoint(
    path: Path,
    model: SentenceRationaleModel,
    config: dict[str, Any],
    vocabulary: Vocabulary,
) -> None:
    """Save enough state to reload the trained rationale model."""
    path.parent.mkdir(parents=True, exist_ok=True)
    torch.save(
        {
            "model_state_dict": {key: value.cpu() for key, value in model.state_dict().items()},
            "model_config": config["model"],
            "training_config": config,
            "vocabulary": {
                "token_to_id": vocabulary.to_dict(),
                "pad_token": "<pad>",
                "unk_token": "<unk>",
                "pad_id": vocabulary.pad_id,
                "unk_id": vocabulary.unk_id,
                "vocab_size": len(vocabulary),
            },
        },
        path,
    )


def build_config(args: argparse.Namespace, run_name: str, out_dir: Path) -> dict[str, Any]:
    return {
        "run_name": run_name,
        "data_dir": str(args.data_dir),
        "out_dir": str(out_dir),
        "epochs": args.epochs,
        "batch_size": args.batch_size,
        "lr": args.lr,
        "lambda_sparsity": args.lambda_sparsity,
        "lambda_full": args.lambda_full,
        "max_vocab": args.max_vocab,
        "min_freq": args.min_freq,
        "max_sentences": args.max_sentences,
        "max_tokens_per_sentence": args.max_tokens_per_sentence,
        "selection_fraction": args.selection_fraction,
        "threshold": args.threshold,
        "prediction_mode": "hard_selected_rationales_only",
        "seed": args.seed,
        "model": {
            "type": "sentence_rationale",
            "embedding_dim": args.embedding_dim,
            "hidden_dim": args.hidden_dim,
            "dropout": args.dropout,
        },
        "limits": {
            "train": args.limit_train,
            "validation": args.limit_val,
            "test": args.limit_test,
        },
    }


def maybe_limit(rows: list[JsonRow], limit: int | None) -> list[JsonRow]:
    return rows[:limit] if limit is not None else rows


def run_training(args: argparse.Namespace) -> dict[str, Any]:
    set_seed(args.seed)
    torch.manual_seed(args.seed)
    random.seed(args.seed)

    run_name = args.run_name or "rationale"
    out_dir = args.out_dir or Path("outputs") / "rationales" / run_name

    rows_by_split = load_dataset_splits(args.data_dir, REQUIRED_SPLITS)
    validate_dataset(args.data_dir, rows_by_split)
    rows_by_split = {
        "train": maybe_limit(rows_by_split["train"], args.limit_train),
        "validation": maybe_limit(rows_by_split["validation"], args.limit_val),
        "test": maybe_limit(rows_by_split["test"], args.limit_test),
    }

    vocabulary = build_vocabulary(
        (str(row["text"]) for row in rows_by_split["train"]),
        max_vocab=args.max_vocab,
        min_freq=args.min_freq,
    )
    datasets = {
        split: RationaleDataset(
            rows,
            vocabulary=vocabulary,
            max_sentences=args.max_sentences,
            max_tokens_per_sentence=args.max_tokens_per_sentence,
        )
        for split, rows in rows_by_split.items()
    }
    loaders = {
        "train": make_loader(datasets["train"], args.batch_size, True, args.seed, vocabulary.pad_id),
        "validation": make_loader(datasets["validation"], args.batch_size, False, args.seed, vocabulary.pad_id),
        "test": make_loader(datasets["test"], args.batch_size, False, args.seed, vocabulary.pad_id),
    }

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = SentenceRationaleModel(
        vocab_size=len(vocabulary),
        embedding_dim=args.embedding_dim,
        hidden_dim=args.hidden_dim,
        dropout=args.dropout,
    ).to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr)
    loss_fn = nn.CrossEntropyLoss()

    train_history = []
    for epoch in range(1, args.epochs + 1):
        epoch_metrics = train_epoch(
            model,
            loaders["train"],
            optimizer,
            loss_fn,
            device,
            args.lambda_sparsity,
            args.lambda_full,
        )
        train_history.append(epoch_metrics)
        print(
            f"epoch={epoch} "
            f"train_loss={epoch_metrics['loss']:.4f} "
            f"rationale_loss={epoch_metrics['rationale_loss']:.4f} "
            f"full_loss={epoch_metrics['full_loss']:.4f} "
            f"avg_soft_selection={epoch_metrics['avg_soft_selection']:.4f}"
        )

    metrics: dict[str, Any] = {
        "run_name": run_name,
        "data_dir": str(args.data_dir),
        "train_losses": [epoch_metrics["loss"] for epoch_metrics in train_history],
        "train_history": train_history,
        "avg_soft_selection": train_history[-1]["avg_soft_selection"] if train_history else 0.0,
        "lambda_full": args.lambda_full,
        "vocab_size": len(vocabulary),
        "device": str(device),
    }
    predictions_by_split: dict[str, list[JsonRow]] = {}

    for split in ("validation", "test"):
        predicted_labels, metric_rows, prediction_rows = evaluate_model(
            model,
            loaders[split],
            device,
            selection_fraction=args.selection_fraction,
            threshold=args.threshold,
        )
        split_metrics = evaluate_split(metric_rows, predicted_labels)
        split_metrics["rationales"] = rationale_metrics(prediction_rows)
        metrics[split] = split_metrics
        predictions_by_split[split] = prediction_rows

    config = build_config(args, run_name, out_dir)
    config["vocab_size"] = len(vocabulary)
    config["splits"] = {split: len(rows) for split, rows in rows_by_split.items()}

    out_dir.mkdir(parents=True, exist_ok=True)
    save_json(out_dir / "config.json", config)
    save_json(out_dir / "metrics.json", metrics)
    save_json(out_dir / "vocab.json", {"token_to_id": vocabulary.to_dict()})
    save_model_checkpoint(out_dir / "model.pt", model, config, vocabulary)
    write_jsonl(out_dir / "validation_predictions.jsonl", predictions_by_split["validation"])
    write_jsonl(out_dir / "test_predictions.jsonl", predictions_by_split["test"])
    write_run_summary(out_dir / "run_summary.md", run_name, config, metrics)

    for split in ("validation", "test"):
        overall = metrics[split]["overall"]
        rationale = metrics[split]["rationales"]
        print(
            f"{run_name} {split}: "
            f"accuracy={overall['accuracy']:.4f}, "
            f"precision={overall['machine_precision']:.4f}, "
            f"recall={overall['machine_recall']:.4f}, "
            f"f1={overall['machine_f1']:.4f}, "
            f"avg_selected_fraction={rationale['average_selected_fraction']:.4f}"
        )
    print(f"Saved outputs to {out_dir}")

    return metrics


def add_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--data-dir", required=True, type=Path, help="Dataset directory with train/validation/test JSONL files.")
    parser.add_argument("--out-dir", default=None, type=Path, help="Output directory. Defaults to outputs/rationales/<run-name>.")
    parser.add_argument("--run-name", default=None, help="Run name used for the default output directory.")
    parser.add_argument("--epochs", default=5, type=int, help="Number of training epochs.")
    parser.add_argument("--batch-size", default=32, type=int, help="Mini-batch size.")
    parser.add_argument("--lr", default=1e-3, type=float, help="Adam learning rate.")
    parser.add_argument("--lambda-sparsity", default=0.01, type=float, help="Weight for the mean selection probability penalty.")
    parser.add_argument("--lambda-full", default=0.5, type=float, help="Weight for the auxiliary full-text classification loss.")
    parser.add_argument("--max-vocab", default=30000, type=int, help="Maximum vocabulary size, including special tokens.")
    parser.add_argument("--min-freq", default=2, type=int, help="Minimum token frequency for vocabulary inclusion.")
    parser.add_argument("--max-sentences", default=32, type=int, help="Maximum sentences kept per document.")
    parser.add_argument("--max-tokens-per-sentence", default=64, type=int, help="Maximum tokens kept per sentence.")
    parser.add_argument("--threshold", default=None, type=float, help="Optional probability threshold for hard selection.")
    parser.add_argument("--selection-fraction", default=0.2, type=float, help="Top fraction of sentences selected at evaluation.")
    parser.add_argument("--seed", default=42, type=int, help="Random seed.")
    parser.add_argument("--embedding-dim", default=128, type=int, help="Word embedding dimension.")
    parser.add_argument("--hidden-dim", default=128, type=int, help="Sentence representation dimension.")
    parser.add_argument("--dropout", default=0.2, type=float, help="Dropout used in the selector-predictor model.")
    parser.add_argument("--limit-train", default=None, type=int, help="Optional training row limit for smoke tests.")
    parser.add_argument("--limit-val", default=None, type=int, help="Optional validation row limit for smoke tests.")
    parser.add_argument("--limit-test", default=None, type=int, help="Optional test row limit for smoke tests.")


def main() -> None:
    parser = argparse.ArgumentParser(description="Train a learned sentence-level rationale model.")
    add_arguments(parser)
    args = parser.parse_args()
    run_training(args)


if __name__ == "__main__":
    main()
