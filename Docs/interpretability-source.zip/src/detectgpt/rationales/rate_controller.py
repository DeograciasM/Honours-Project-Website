import math

class RateController:

    """Dual ascent on E[selection] -> target.

    Auto-tunes the sparsity weight instead of guessing it.

    mode="current": warmup, panic escape hatch, linear penalty (unless
    penalty_mu > 0, which adds an always-on augmented-Lagrangian quadratic
    term and disables panic).
    mode="bastings": no warmup, no panic, multiplicative/log-space dual
    ascent from step 0, penalty stays linear regardless of penalty_mu."""

    def __init__(self, target, lr=0.02, init_lambda=0.02,
                 max_lambda=1.0, warmup_steps=300,
                 floor_ratio=0.3, panic_patience=20, alpha=0.5,
                 mode="current", penalty_mu=0.0, min_lambda=1e-4):
        self.target = target
        self.lr = lr
        self.mode = mode
        self.log_lambda = math.log(init_lambda)
        self.max_log = math.log(max_lambda)
        self.min_log = math.log(min_lambda)
        # Bastings replication applies pressure from step 0 (no warmup).
        self.warmup_steps = 0 if mode == "bastings" else warmup_steps
        # Bastings replication has no panic branch; the augmented Lagrangian's
        # always-on quadratic term supersedes panic's job too, so disable it
        # whenever penalty_mu is active. Penalty stays linear in bastings mode
        # regardless of what penalty_mu is passed.
        self.penalty_mu = 0.0 if mode == "bastings" else penalty_mu
        self.panic_enabled = mode != "bastings" and self.penalty_mu <= 0
        self.floor = floor_ratio * target      # death-spiral threshold
        self.panic_patience = panic_patience
        self.below_floor = 0
        self.step = 0
        self.alpha = alpha
        self.c_ma = None                        # EMA of observed selection rate

    @property
    def lam(self):
        if self.step < self.warmup_steps:
            return 0.0                          # let the predictor learn first
        return math.exp(self.log_lambda)

    def penalty(self, measured_rate):
        """Return the constrained-objective reward subtracted from the loss.

        Negating the augmented-Lagrangian terms here lets callers write the
        objective as ``classification_loss - controller.penalty(rate)`` while
        retaining the usual minimisation pressure on rates above the target.
        """
        violation = measured_rate - self.target
        linear = -self.lam * violation
        if self.penalty_mu > 0:
            # Augmented Lagrangian quadratic term: active from step 0,
            # independent of warmup/lam.
            return linear - 0.5 * self.penalty_mu * violation ** 2
        return linear

    def update(self, selection_value):
        self.step += 1
        if self.c_ma is None:
            self.c_ma = selection_value
        else:
            self.c_ma = self.alpha * self.c_ma + (1 - self.alpha) * selection_value

        if self.step < self.warmup_steps:
            return

        # Escape hatch: collapsing toward zero is unrecoverable, so react
        # hard and early rather than waiting for normal dual ascent.
        if self.panic_enabled and self.c_ma < self.floor:
            self.below_floor += 1
            if self.below_floor >= self.panic_patience:
                self.log_lambda = max(self.min_log, self.log_lambda - 0.5)
                self.below_floor = 0
            return

        self.below_floor = 0
        violation = self.c_ma - self.target
        self.log_lambda = min(self.max_log,
                              max(self.min_log,
                                  self.log_lambda + self.lr * violation))
