from __future__ import annotations

import torch


DEVICE_CHOICES = ("auto", "cpu", "cuda", "mps")


def resolve_device(requested: str = "auto") -> torch.device:
    """Resolve an accelerator, failing clearly for unavailable explicit choices."""
    if requested not in DEVICE_CHOICES:
        raise ValueError(f"Unknown device {requested!r}; choose from {DEVICE_CHOICES}.")
    if requested == "auto":
        if torch.cuda.is_available():
            return torch.device("cuda")
        if torch.backends.mps.is_available():
            return torch.device("mps")
        return torch.device("cpu")
    if requested == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA was requested but is not available in this PyTorch environment.")
    if requested == "mps" and not torch.backends.mps.is_available():
        reason = "PyTorch was not built with MPS support" if not torch.backends.mps.is_built() else "MPS is unavailable at runtime"
        raise RuntimeError(f"MPS was requested but is unavailable: {reason}.")
    return torch.device(requested)
