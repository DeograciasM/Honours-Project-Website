from __future__ import annotations

from pathlib import Path
from typing import Any


def write_run_summary(path: str | Path, run_name: str, config: dict[str, Any], metrics: dict[str, Any]) -> None:
    """Write a concise Markdown summary for a baseline run."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)

    vectorizer_config = config["vectorizer"]
    if "word" in vectorizer_config and "char" in vectorizer_config:
        word_config = vectorizer_config["word"]
        char_config = vectorizer_config["char"]
        vectorizer_lines = [
            f"- N-grams: word {word_config['ngram_range']} + char_wb {char_config['ngram_range']}",
            f"- Max features: word {word_config['max_features']}, char {char_config['max_features']}",
            f"- min_df: word {word_config['min_df']}, char {char_config['min_df']}",
        ]
    else:
        vectorizer_lines = [
            f"- N-grams: {vectorizer_config['ngram_range']}",
            f"- Max features: {vectorizer_config['max_features']}",
            f"- min_df: {vectorizer_config['min_df']}",
        ]

    lines = [
        f"# {run_name}",
        "",
        "## Baseline",
        "",
        f"- Model: {config['baseline']}",
        *vectorizer_lines,
        f"- Class weight: {config['classifier']['class_weight']}",
        "",
        "## Overall Metrics",
        "",
        "| Split | Accuracy | Machine Precision | Machine Recall | Machine F1 |",
        "| --- | ---: | ---: | ---: | ---: |",
    ]

    for split in ("validation", "test"):
        overall = metrics[split]["overall"]
        lines.append(
            f"| {split} | {overall['accuracy']:.4f} | {overall['machine_precision']:.4f} | "
            f"{overall['machine_recall']:.4f} | {overall['machine_f1']:.4f} |"
        )

    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
