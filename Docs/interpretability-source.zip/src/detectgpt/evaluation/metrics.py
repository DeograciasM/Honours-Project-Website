from __future__ import annotations

from collections import defaultdict
from typing import Any

import numpy as np
from sklearn.metrics import accuracy_score, confusion_matrix, f1_score, precision_score, recall_score, roc_auc_score

from detectgpt.data.io import JsonRow


def paired_bootstrap_f1(
    y_true: list[int],
    pred_a: list[int],
    pred_b: list[int],
    *,
    resamples: int = 10_000,
    seed: int = 20260805,
) -> dict[str, Any]:
    """Estimate a paired bootstrap interval for F1(B) minus F1(A)."""
    truth = np.asarray(y_true)
    a = np.asarray(pred_a)
    b = np.asarray(pred_b)
    observed = float(f1_score(truth, b, zero_division=0) - f1_score(truth, a, zero_division=0))
    rng = np.random.default_rng(seed)
    differences = np.empty(resamples, dtype=np.float64)
    true_positive_a = ((truth == 1) & (a == 1)).astype(np.int8)
    false_positive_a = ((truth == 0) & (a == 1)).astype(np.int8)
    false_negative_a = ((truth == 1) & (a == 0)).astype(np.int8)
    true_positive_b = ((truth == 1) & (b == 1)).astype(np.int8)
    false_positive_b = ((truth == 0) & (b == 1)).astype(np.int8)
    false_negative_b = ((truth == 1) & (b == 0)).astype(np.int8)
    for index in range(resamples):
        sample = rng.integers(0, len(truth), size=len(truth))
        tp_a = int(true_positive_a[sample].sum())
        fp_a = int(false_positive_a[sample].sum())
        fn_a = int(false_negative_a[sample].sum())
        tp_b = int(true_positive_b[sample].sum())
        fp_b = int(false_positive_b[sample].sum())
        fn_b = int(false_negative_b[sample].sum())
        denom_a = 2 * tp_a + fp_a + fn_a
        denom_b = 2 * tp_b + fp_b + fn_b
        f1_a = 2 * tp_a / denom_a if denom_a else 0.0
        f1_b = 2 * tp_b / denom_b if denom_b else 0.0
        differences[index] = f1_b - f1_a
    lower, upper = np.quantile(differences, [0.025, 0.975])
    return {
        "definition": "F1(B) - F1(A)",
        "observed_difference": observed,
        "confidence_interval_95": [float(lower), float(upper)],
        "resamples": resamples,
        "seed": seed,
    }


def safe_roc_auc(y_true: list[int], y_score: list[float] | None) -> float | None:
    """Compute ROC-AUC, returning None when scores are absent or only one class is present."""
    if y_score is None:
        return None
    if len(set(y_true)) < 2:
        return None
    try:
        return float(roc_auc_score(y_true, y_score))
    except ValueError:
        return None


def binary_classification_metrics(
    y_true: list[int], y_pred: list[int], y_score: list[float] | None = None
) -> dict[str, Any]:
    """Compute overall binary metrics with machine as the positive class."""
    matrix = confusion_matrix(y_true, y_pred, labels=[0, 1])
    return {
        "accuracy": float(accuracy_score(y_true, y_pred)),
        "machine_precision": float(precision_score(y_true, y_pred, pos_label=1, zero_division=0)),
        "machine_recall": float(recall_score(y_true, y_pred, pos_label=1, zero_division=0)),
        "machine_f1": float(f1_score(y_true, y_pred, pos_label=1, zero_division=0)),
        "auroc": safe_roc_auc(y_true, y_score),
        "confusion_matrix": {
            "labels": ["human", "machine"],
            "matrix": matrix.tolist(),
            "tn_human_as_human": int(matrix[0][0]),
            "fp_human_as_machine": int(matrix[0][1]),
            "fn_machine_as_human": int(matrix[1][0]),
            "tp_machine_as_machine": int(matrix[1][1]),
        },
        "support": {
            "human": int(sum(label == 0 for label in y_true)),
            "machine": int(sum(label == 1 for label in y_true)),
            "total": len(y_true),
        },
    }


def grouped_metrics(
    rows: list[JsonRow], y_pred: list[int], group_field: str, y_score: list[float] | None = None
) -> dict[str, Any]:
    """Compute binary metrics for each value of a metadata field."""
    grouped_indices: dict[str, list[int]] = defaultdict(list)
    for index, row in enumerate(rows):
        grouped_indices[str(row[group_field])].append(index)

    output: dict[str, Any] = {}
    for group_value in sorted(grouped_indices):
        indices = grouped_indices[group_value]
        y_true_group = [int(rows[index]["label_id"]) for index in indices]
        y_pred_group = [int(y_pred[index]) for index in indices]
        y_score_group = [float(y_score[index]) for index in indices] if y_score is not None else None
        output[group_value] = binary_classification_metrics(y_true_group, y_pred_group, y_score_group)
    return output


def by_generator_metrics(
    rows: list[JsonRow], y_pred: list[int], y_score: list[float] | None = None
) -> dict[str, Any]:
    """Compute generator-specific metrics with label-aware reporting."""
    grouped_indices: dict[str, list[int]] = defaultdict(list)
    for index, row in enumerate(rows):
        grouped_indices[str(row["generator"])].append(index)

    output: dict[str, Any] = {}
    for generator in sorted(grouped_indices):
        indices = grouped_indices[generator]
        y_true_group = [int(rows[index]["label_id"]) for index in indices]
        y_pred_group = [int(y_pred[index]) for index in indices]
        y_score_group = [float(y_score[index]) for index in indices] if y_score is not None else None
        matrix = confusion_matrix(y_true_group, y_pred_group, labels=[0, 1])
        support = len(indices)
        # Note: a single-generator subset is always one-class (human rows are
        # all label_id=0, any machine generator's rows are all label_id=1), so
        # AUROC is mathematically undefined here and safe_roc_auc returns None.
        auroc = safe_roc_auc(y_true_group, y_score_group)

        if generator == "human":
            human_support = int(sum(label == 0 for label in y_true_group))
            human_as_human = int(matrix[0][0])
            human_as_machine = int(matrix[0][1])
            output[generator] = {
                "human_accuracy": human_as_human / human_support if human_support else 0.0,
                "false_positive_rate": human_as_machine / human_support if human_support else 0.0,
                "auroc": auroc,
                "support": support,
            }
            continue

        machine_support = int(sum(label == 1 for label in y_true_group))
        missed_as_human = int(matrix[1][0])
        machine_as_machine = int(matrix[1][1])
        output[generator] = {
            "machine_recall": machine_as_machine / machine_support if machine_support else 0.0,
            "missed_as_human": missed_as_human,
            "auroc": auroc,
            "support": support,
        }

    return output


def evaluate_split(rows: list[JsonRow], y_pred: list[int], y_score: list[float] | None = None) -> dict[str, Any]:
    """Evaluate a split overall and by important metadata fields."""
    y_true = [int(row["label_id"]) for row in rows]
    return {
        "overall": binary_classification_metrics(y_true, y_pred, y_score),
        "by_domain": grouped_metrics(rows, y_pred, "domain", y_score),
        "by_generator": by_generator_metrics(rows, y_pred, y_score),
    }
