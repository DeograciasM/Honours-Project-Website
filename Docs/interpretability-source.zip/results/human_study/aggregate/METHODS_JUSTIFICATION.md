# Human-study methods justification

This note is a defence aid for the honours paper. The main paper only needs a concise version.

## Why one descriptive table?

The study has one primary question: whether presentation condition changes classification correctness. Accuracy, cannot-tell responses, confidence, helpfulness and relevance are displayed so the observed pattern is transparent. Only correctness receives confirmatory inference; this avoids turning a small human study into many loosely related hypothesis tests.

## Why logistic rather than a t-test or ANOVA?

Each judgement is either correct or not correct. “Cannot tell” is treated as not correct for this primary outcome and is also reported separately. Logistic regression models the probability of a binary outcome directly. Treating binary observations as normally distributed can give inappropriate standard errors and impossible fitted values. Jaeger (2008) specifically recommends logit mixed models for categorical behavioural responses.

## Why participant and passage effects?

The 250 rows are not 250 independent people. Each of 25 participants answered ten questions, and each of 20 passages was judged repeatedly. The planned random intercepts represented these two sources of repeated observation. Judd, Westfall and Kenny (2012) explain why participant and stimulus variation should both be considered in experiments of this form.

## Why adjust for item position?

The six form schedules associate condition with ordinal position; for example, positions 3 and 7 are always Plain. Position could capture practice, fatigue or ordering effects. It is therefore included as a categorical adjustment rather than assuming a linear trend. This makes Detector-versus-Plain estimation less precise, but ignoring position would risk attributing an order effect to highlighting.

## Why was the mixed model not used for inference?

It converged, but both participant and passage random-intercept variances were estimated as exactly zero. This is a boundary or singular fit: the dataset does not support estimating that random-effects structure. The decision to reject it followed the recorded diagnostic rule and did not depend on the condition coefficients or their significance.

## Why the fallback?

The fallback retains the same binary outcome, condition effect and item-position adjustment. It replaces unsupported random-intercept variance estimates with two-way cluster-robust uncertainty by participant and passage. Cameron, Gelbach and Miller (2011) developed this estimator for nonlinear models, including logistic regression, when observations may be correlated along two non-nested clustering dimensions. The reference degrees of freedom are conservatively based on the smaller number of clusters: 20 passages, giving 19 degrees of freedom.

Twenty passage clusters and 25 participant clusters are still a modest sample for cluster-robust inference. The finite-cluster adjustment and 19-degree-of-freedom reference are intended to be conservative, but the resulting wide intervals must remain visible in interpretation.

## Why two comparisons and Holm adjustment?

- Detector versus Plain asks whether selected highlighting improves on no highlighting.
- Detector versus Random asks whether any effect is specific to selected words rather than generic highlighting.

Testing two related contrasts increases the chance of a false-positive result. Holm adjustment controls that family-wise error while being less conservative than applying a simple Bonferroni threshold to every test. No secondary outcome was promoted to a confirmatory test.

## What can be concluded?

The analysis can assess evidence for a condition effect in this deliberately stratified 20-passage study. It cannot estimate natural population-wide human detection accuracy. A non-significant contrast is not proof of no effect; the confidence interval describes the benefits and harms compatible with these data.

## Core references

- Jaeger, T. F. (2008). *Categorical data analysis: Away from ANOVAs (transformation or not) and towards logit mixed models*. Journal of Memory and Language, 59(4), 434–446. https://doi.org/10.1016/j.jml.2007.11.007
- Judd, C. M., Westfall, J., & Kenny, D. A. (2012). *Treating stimuli as a random factor in social psychology: A new and comprehensive solution to a pervasive but largely ignored problem*. Journal of Personality and Social Psychology, 103(1), 54–69. https://doi.org/10.1037/a0028347
- Cameron, A. C., Gelbach, J. B., & Miller, D. L. (2011). *Robust inference with multiway clustering*. Journal of Business & Economic Statistics, 29(2), 238–249. https://doi.org/10.1198/jbes.2010.07136
- Holm, S. (1979). *A simple sequentially rejective multiple test procedure*. Scandinavian Journal of Statistics, 6(2), 65–70. https://doi.org/10.2307/4615733
