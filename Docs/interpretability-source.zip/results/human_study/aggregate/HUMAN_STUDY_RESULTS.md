# Human-study results

## Scope

This analysis uses all 25 valid submissions (250 experimental judgements). It follows the approved lean plan: one descriptive condition table and one primary analysis of classification correctness. No participants or forms were excluded or downsampled. Secondary questionnaire outcomes are descriptive only.

Because the 20 passages were deliberately stratified into CH/CM/FP/FN detector outcomes, the overall accuracy values describe this constructed study pool; they are not estimates of natural population-level human detection accuracy.

## Descriptive results

| Condition | Judgements | Accuracy, n/N (%) | Cannot tell, n/N (%) | Confidence, mean (SD) | Helpfulness, mean (SD) | Relevance, mean (SD) |
| --- | --- | --- | --- | --- | --- | --- |
| Plain | 83 | 39/83 (47.0%) | 8/83 (9.6%) | 3.58 (1.11) | — | — |
| Detector | 82 | 37/82 (45.1%) | 7/82 (8.5%) | 3.30 (1.06) | 3.07 (1.16) | 3.30 (1.05) |
| Random | 85 | 38/85 (44.7%) | 13/85 (15.3%) | 3.51 (1.08) | 3.08 (1.14) | 3.36 (1.13) |

Confidence, helpfulness and relevance use 1–5 scales. Highlight ratings are unavailable for Plain by design.

## Primary condition-effect model

The planned binomial logistic mixed-effects model included presentation condition, categorical item position, and random intercepts for participant and passage. It converged, but it was singular: both random-intercept variances were estimated as zero. Under the prespecified diagnostic rule, its inferential results were not used.

The fallback retained the same condition and item-position fixed effects and used logistic regression with two-way cluster-robust uncertainty by participant and passage. This accounts for both repeated-answer structures without trying to estimate unsupported random-effect variances.

Adjusted correctness probabilities were:

- Plain: 48.9%, 95% CI [21.56, 76.23]
- Detector: 42.5%, 95% CI [21.88, 63.17]
- Random: 45.4%, 95% CI [28.52, 62.23]

For Detector versus Plain, the adjusted difference was -6.4 percentage points (95% CI [-52.08, 39.34]), OR 0.77 (95% CI [0.12, 5.03]), Holm-adjusted p = 1.000. Detector highlighting did not provide clear evidence of a difference relative to Plain.

For Detector versus Random, the adjusted difference was -2.8 percentage points (95% CI [-21.59, 15.89]), OR 0.89 (95% CI [0.41, 1.93]), Holm-adjusted p = 1.000. Detector highlighting did not provide clear evidence of a difference relative to matched Random highlighting.

## Interpretation boundary

The analysis tests the presentation-condition effect while accounting for repeated participants, repeated passages and item position. It does not establish population-wide human detection accuracy, and the descriptive confidence/helpfulness ratings are not treated as additional confirmatory hypothesis tests.

The Detector-versus-Plain estimate is particularly imprecise because presentation condition and ordinal position have incomplete overlap: positions 3 and 7 were always Plain, while several later positions were always highlighted. Adjusting for position is preferable to ignoring this design feature, but it requires an additive model assumption and yields a wide interval. The result should therefore be described as no clear evidence of improvement, not proof that highlighting has no effect.

## Reproducibility

- Planned model: `correct ~ condition + factor(item position) + (1 | participant) + (1 | passage)`; singular because both random-intercept variances were zero
- Activated fallback: `correct ~ condition + factor(item position)` with participant-and-passage two-way cluster-robust covariance
- Reference degrees of freedom: 19 (the smaller cluster count minus one)
- Fallback selection basis: the zero-variance/singularity diagnostic only, before inspecting fallback estimates
- Planned contrasts: Detector–Plain and Detector–Random
- Multiplicity: Holm adjustment across the two planned p-values
- Full coefficients, adjusted probabilities, contrasts, variance components and diagnostics are saved as machine-readable files in this directory.

