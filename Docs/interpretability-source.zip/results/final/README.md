# Final machine-evaluation results

- `metrics/`: aggregate/per-seed metrics and statistical comparisons.
- `tables/`: domain, generator, and length breakdowns plus the LaTeX summary.
- `figures/`: figures derived from the frozen final campaign or final predictions.
- `manifests/`: unchanged copies of final freeze and package provenance records.

The locked narrative source of truth is `results/final/results_lock_report.md`. Copies derived from ignored `outputs/` are verified against the hashes in the freeze/package manifests and `artifacts/artifact_manifest.json`.
