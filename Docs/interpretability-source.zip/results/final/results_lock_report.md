# Results Lock Report

**Audit date:** 2026-08-28

**Scope:** final corrected-surface/frozen `raid_core_en_v3` results only

**Purpose:** numerical source of truth for the final Results section

## Status definitions

- **VERIFIED:** the value agrees with a canonical frozen artefact or was independently recomputed from frozen per-example predictions/raw frozen splits.
- **CORRECTED:** the dossier or proposed value is stale, incorrectly labelled, or differs from the final artefact; the value here replaces it.
- **NOT AVAILABLE:** the requested statistic is not stored and cannot be reconstructed from the final artefacts.

No value from `outputs/final_analysis/`, pre-surface `outputs/rationales/`, old Transformer outputs, v1/v2 data, or cached pre-representation token-length reports is admitted. No model was run and no test split was newly evaluated. Read-only recomputation was limited to metrics from already-frozen predictions and token counts from the frozen raw v3 JSONL files.

Because no separate draft Results-section file was supplied, this report audits the numerical claims in `paper_evidence_dossier.md` as the proposed Results evidence.

## Canonical source index

| Code | Canonical source |
|---|---|
| B-TEST | `outputs/final_evaluation/v3_final/final_results.csv` and `metrics/*_test_metrics.json` |
| B-PRED | `outputs/final_evaluation/v3_final/predictions/*_test_predictions.jsonl` |
| BOOT | `outputs/final_evaluation/v3_final/metrics/statistical_comparisons.json` |
| CTX | `outputs/final_model_campaign/stage1_aggregate.csv`, `stage1_per_seed.csv`, `stage1_provenance.json` |
| BUD | `outputs/final_model_campaign/stage2_aggregate.csv`, `stage2_per_seed.csv`, `stage2_provenance.json` |
| RAT | `outputs/final_evaluation/v3_final/rationale_quality/aggregate.json`, per-seed control JSONs, and `cross_seed_stability.json` |
| B-SUB | `outputs/final_evaluation/v3_final/breakdowns/domain_breakdown.csv` and `generator_breakdown.csv` |
| TF-FULL | `kaggle_downloads/notebook3b54a9ed11/outputs/transformer_full_context_512/final_summary.csv` and `final/seed*/test_predictions.jsonl` |
| TF-RAT | `kaggle_downloads/notebook2da03c8d12/outputs/transformer_rationale_512_40/final_summary.csv` and `final/seed*/test_predictions.jsonl` |
| HUMAN-D | `human_study_analysis/reports/descriptive_by_condition.csv` and `processed/responses_long.csv` |
| HUMAN-I | `human_study_analysis/reports/model_adjusted_probabilities.csv`, `model_planned_contrasts.csv`, diagnostics and variance-component files |
| FREEZE | `outputs/final_evaluation/v3_final/freeze_manifest.json` |

# 1. Final Test Metrics

All precisions, recalls and F1s use machine as the positive class. Neural `±` values are sample SD across seeds 42/43/44. Independent recomputation from the seven local frozen prediction sets and six Kaggle Transformer prediction sets exactly reproduced the stored metrics.

## 1.1 TF-IDF, full-context BiLSTM and rationale BiLSTM

**Source:** B-TEST; independently checked against B-PRED.

| Status | System | Seed | Accuracy | Precision | Recall | F1 | AUROC |
|---|---|---:|---:|---:|---:|---:|---:|
| VERIFIED | Word+character TF-IDF | — | 0.949167 | 0.959114 | 0.938333 | 0.948610 | 0.988842 |
| VERIFIED | Full-context BiLSTM 512 | 42 | 0.957500 | 0.958264 | 0.956667 | 0.957465 | 0.989842 |
| VERIFIED |  | 43 | 0.956667 | 0.956667 | 0.956667 | 0.956667 | 0.988531 |
| VERIFIED |  | 44 | 0.950000 | 0.939739 | 0.961667 | 0.950577 | 0.989410 |
| VERIFIED |  | mean ± SD | 0.954722 ± 0.004111 | 0.951557 ± 0.010265 | 0.958333 ± 0.002887 | 0.954903 ± 0.003768 | 0.989261 ± 0.000668 |
| VERIFIED | HardKuma BiLSTM 512/40% | 42 | 0.949167 | 0.935380 | 0.965000 | 0.949959 | 0.986249 |
| VERIFIED |  | 43 | 0.941667 | 0.943144 | 0.940000 | 0.941569 | 0.985804 |
| VERIFIED |  | 44 | 0.944167 | 0.943428 | 0.945000 | 0.944213 | 0.985806 |
| VERIFIED |  | mean ± SD | 0.945000 ± 0.003819 | 0.940650 ± 0.004567 | 0.950000 ± 0.013229 | 0.945247 ± 0.004289 | 0.985953 ± 0.000256 |

## 1.2 Full-context Transformer and Transformer-HardKuma

**Sources:** TF-FULL and TF-RAT; independently recomputed from each package's frozen test predictions.

| Status | System | Seed | Accuracy | Precision | Recall | F1 | AUROC |
|---|---|---:|---:|---:|---:|---:|---:|
| VERIFIED | Full Transformer 512 | 42 | 0.960833 | 0.951060 | 0.971667 | 0.961253 | 0.988971 |
| VERIFIED |  | 43 | 0.965000 | 0.955882 | 0.975000 | 0.965347 | 0.989288 |
| VERIFIED |  | 44 | 0.964167 | 0.966499 | 0.961667 | 0.964077 | 0.989760 |
| VERIFIED |  | mean ± SD | 0.963333 ± 0.002205 | 0.957814 ± 0.007899 | 0.969444 ± 0.006939 | 0.963559 ± 0.002095 | 0.989339 ± 0.000397 |
| VERIFIED | Transformer-HardKuma 512/40% | 42 | 0.929167 | 0.913323 | 0.948333 | 0.930499 | 0.979887 |
| VERIFIED |  | 43 | 0.930833 | 0.928690 | 0.933333 | 0.931006 | 0.974322 |
| VERIFIED |  | 44 | 0.935833 | 0.938023 | 0.933333 | 0.935673 | 0.976267 |
| VERIFIED |  | mean ± SD | 0.931944 ± 0.003469 | 0.926679 ± 0.012473 | 0.938333 ± 0.008660 | 0.932392 ± 0.002852 | 0.976825 ± 0.002824 |

# 2. Paired-Bootstrap F1 Differences

**Status: VERIFIED. Source: BOOT.** These are paired nonparametric bootstraps over the same 1,200 test examples with 10,000 resamples. Aggregate neural comparisons recompute each seed's F1 in a resample and then average across seeds; seeds are not treated as independent examples.

## 2.1 Aggregate comparisons

| Status | Comparison | Observed F1 difference | 95% CI | Bootstrap seed |
|---|---|---:|---:|---:|
| VERIFIED | Rationale BiLSTM − full BiLSTM | -0.009655469 | [-0.017161647, -0.002287521] | 20260818 |
| VERIFIED | Rationale BiLSTM − TF-IDF | -0.003362801 | [-0.016153218, 0.009498889] | 20260819 |
| VERIFIED | Full BiLSTM − TF-IDF | +0.006292668 | [-0.004580793, 0.017982213] | 20260820 |

## 2.2 Per-seed comparisons

| Status | Comparison | Observed F1 difference | 95% CI |
|---|---|---:|---:|
| VERIFIED | Rationale − full, seed 42 | -0.007505571 | [-0.018075067, 0.003052683] |
| VERIFIED | Rationale − full, seed 43 | -0.015097385 | [-0.027038152, -0.003753023] |
| VERIFIED | Rationale − full, seed 44 | -0.006363451 | [-0.018103413, 0.005211356] |
| VERIFIED | Rationale seed 42 − TF-IDF | +0.001349042 | [-0.012097992, 0.015315668] |
| VERIFIED | Rationale seed 43 − TF-IDF | -0.007040659 | [-0.022217651, 0.008137664] |
| VERIFIED | Rationale seed 44 − TF-IDF | -0.004396785 | [-0.018805239, 0.009765239] |
| VERIFIED | Full seed 42 − TF-IDF | +0.008854613 | [-0.004342100, 0.022185645] |
| VERIFIED | Full seed 43 − TF-IDF | +0.008056726 | [-0.003783260, 0.020177416] |
| VERIFIED | Full seed 44 − TF-IDF | +0.001966665 | [-0.010580629, 0.014856581] |

**NOT AVAILABLE:** no final paired-bootstrap intervals were produced for either Transformer family or Transformer-versus-BiLSTM comparisons. Only three-seed sample SDs are available for those systems.

# 3. Final Corrected-Surface Context Sweep

The context sweep is validation-only, seeds 42/43/44, and uses the final surface tokenizer. Source: CTX.

## 3.1 Aggregate validation metrics and runtime

| Status | Context | Accuracy mean ± SD | Precision mean ± SD | Recall mean ± SD | F1 mean ± SD | AUROC mean ± SD | Runtime seconds mean ± SD |
|---|---:|---:|---:|---:|---:|---:|---:|
| VERIFIED | 256 | 0.939444 ± 0.002927 | 0.936643 ± 0.021320 | 0.943333 ± 0.018028 | 0.939702 ± 0.001683 | 0.983939 ± 0.000486 | 2,786.689 ± 454.336 |
| VERIFIED | 512 | 0.957222 ± 0.005358 | 0.959776 ± 0.020438 | 0.955000 ± 0.017638 | 0.957147 ± 0.005115 | 0.988119 ± 0.000840 | 4,862.356 ± 19.965 |
| VERIFIED | 1,024 | 0.958056 ± 0.002927 | 0.962950 ± 0.003210 | 0.952778 ± 0.005358 | 0.957830 ± 0.003014 | 0.988590 ± 0.001200 | 10,450.905 ± 1,922.801 |

## 3.2 Per-seed F1, checkpoint epoch and runtime

| Status | Context | Seed | Validation F1 | Best epoch | Runtime seconds |
|---|---:|---:|---:|---:|---:|
| VERIFIED | 256 | 42 | 0.939719 | 21 | 2,302.895 |
| VERIFIED | 256 | 43 | 0.938010 | 12 | 2,852.864 |
| VERIFIED | 256 | 44 | 0.941376 | 15 | 3,204.309 |
| VERIFIED | 512 | 42 | 0.952782 | 22 | 4,842.279 |
| VERIFIED | 512 | 43 | 0.962775 | 14 | 4,862.584 |
| VERIFIED | 512 | 44 | 0.955882 | 20 | 4,882.207 |
| VERIFIED | 1,024 | 42 | 0.960604 | 18 | 10,660.280 |
| VERIFIED | 1,024 | 43 | 0.958264 | 25 | 8,431.985 |
| VERIFIED | 1,024 | 44 | 0.954622 | 9 | 12,260.450 |

## 3.3 Final-tokenizer passage coverage

**Sources:** raw `data/processed/raid_core_en_v3/{train,validation,test}.jsonl`; tokenizer `src/detectgpt/rationales/vocab.py`; hashes verified against FREEZE. Counts were recomputed from every raw `text` field with Unicode regex `\w+|[^\w\s]`, with no context cap and no cached length artefact.

| Status | Split | Context | Complete ≤ context | Truncated > context |
|---|---|---:|---:|---:|
| VERIFIED | Train (N=5,760) | 256 | 2,428 (42.1528%) | 3,332 (57.8472%) |
| VERIFIED |  | 512 | 5,261 (91.3368%) | 499 (8.6632%) |
| VERIFIED |  | 1,024 | 5,650 (98.0903%) | 110 (1.9097%) |
| VERIFIED | Validation (N=1,200) | 256 | 514 (42.8333%) | 686 (57.1667%) |
| VERIFIED |  | 512 | 1,092 (91.0000%) | 108 (9.0000%) |
| VERIFIED |  | 1,024 | 1,178 (98.1667%) | 22 (1.8333%) |
| VERIFIED | Test (N=1,200) | 256 | 476 (39.6667%) | 724 (60.3333%) |
| VERIFIED |  | 512 | 1,097 (91.4167%) | 103 (8.5833%) |
| VERIFIED |  | 1,024 | 1,176 (98.0000%) | 24 (2.0000%) |

Length summaries, also recomputed: train min/median/mean/max `86 / 281 / 338.0686 / 14,480`; validation `88 / 280 / 344.1242 / 16,039`; test `89 / 285.5 / 341.1792 / 6,723`.

# 4. Final Corrected-Surface Rationale-Budget Sweep

All runs use context 512, seeds 42/43/44, validation-only checkpoint selection, and final surface semantics. Source: BUD.

## 4.1 Aggregate results

| Status | Budget | Accuracy mean ± SD | Precision mean ± SD | Recall mean ± SD | F1 mean ± SD | AUROC mean ± SD | Achieved fraction | Mean selected tokens | Runtime seconds mean ± SD |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| VERIFIED | 20% | 0.905833 ± 0.020361 | 0.878299 ± 0.037392 | 0.943889 ± 0.009623 | 0.909556 ± 0.017784 | 0.971188 ± 0.005147 | 0.201680555 | 60.315 | 10,000.822 ± 61.868 |
| VERIFIED | 30% | 0.926111 ± 0.014561 | 0.915494 ± 0.036718 | 0.940556 ± 0.015123 | 0.927381 ± 0.012336 | 0.973857 ± 0.003936 | 0.301802147 | 90.274 | 13,490.470 ± 2,457.288 |
| VERIFIED | 40% | 0.941389 ± 0.002097 | 0.949145 ± 0.002832 | 0.932778 ± 0.007515 | 0.940871 ± 0.002440 | 0.979786 ± 0.001772 | 0.401572789 | 120.164 | 10,127.679 ± 133.908 |

The achieved selection fraction and deterministic token counts are identical across seeds because each seed evaluates the same validation lengths with the same target top-k count.

## 4.2 Per-seed validation F1 and selection accounting

| Status | Budget | Seed | Validation F1 | Achieved fraction | Mean / median / range selected | Best epoch |
|---|---:|---:|---:|---:|---:|---:|
| VERIFIED | 20% | 42 | 0.902362 | 0.201680555 | 60.315 / 56 / 18–103 | 25 |
| VERIFIED | 20% | 43 | 0.896497 | 0.201680555 | 60.315 / 56 / 18–103 | 24 |
| VERIFIED | 20% | 44 | 0.929810 | 0.201680555 | 60.315 / 56 / 18–103 | 20 |
| VERIFIED | 30% | 42 | 0.913600 | 0.301802147 | 90.274 / 84 / 27–154 | 24 |
| VERIFIED | 30% | 43 | 0.937394 | 0.301802147 | 90.274 / 84 / 27–154 | 25 |
| VERIFIED | 30% | 44 | 0.931148 | 0.301802147 | 90.274 / 84 / 27–154 | 18 |
| VERIFIED | 40% | 42 | 0.943144 | 0.401572789 | 120.164 / 112 / 36–205 | 25 |
| VERIFIED | 40% | 43 | 0.938292 | 0.401572789 | 120.164 / 112 / 36–205 | 21 |
| VERIFIED | 40% | 44 | 0.941176 | 0.401572789 | 120.164 / 112 / 36–205 | 11 |

# 5. Final Rationale Size and Diagnostics

## 5.1 Selected-token size on frozen test data

**Status: VERIFIED.** BiLSTM source: B-TEST/B-PRED. Transformer source: TF-RAT. Counts were independently recomputed from every `selected_token_indices` array.

| Rationale family | Seed(s) | Selected fraction | Mean count | Median count | Range | Empty-selection fallbacks |
|---|---|---:|---:|---:|---:|---:|
| BiLSTM-HardKuma 512/40% | 42, 43, 44 individually | 0.401510165 | 121.0525 | 114.5 | 36–205 | 0 |
| Transformer-HardKuma 512/40% | 42, 43, 44 individually | 0.401510165 | 121.0525 | 114.5 | 36–205 | 0 |

The final-test fraction differs slightly from the validation-sweep fraction `0.401572789` because validation and test have different passage-length distributions. They must not be treated as the same statistic.

## 5.2 BiLSTM learned and control rationale results

**Status: VERIFIED. Source: RAT.** Random is the F1 obtained after averaging probabilities across five deterministic, equal-count random masks per example—not the mean of the five replicate F1 values.

| Seed | Learned F1 | Random F1 | First F1 | Last F1 | Mean sufficiency drop | Mean comprehensiveness drop |
|---:|---:|---:|---:|---:|---:|---:|
| 42 | 0.949959 | 0.894737 | 0.754895 | 0.744828 | -0.313389 | 0.455404 |
| 43 | 0.941569 | 0.887960 | 0.774749 | 0.769331 | -0.258051 | 0.546563 |
| 44 | 0.944213 | 0.815175 | 0.794643 | 0.845133 | -0.109671 | 0.547125 |
| Mean ± seed SD | 0.945247 ± 0.004289 | 0.865957 ± 0.044109 | 0.774762 ± 0.019874 | 0.786430 ± 0.052293 | -0.227037 ± 0.105340 | 0.516364 ± 0.052794 |

## 5.3 BiLSTM cross-seed rationale stability

**Status: VERIFIED. Source: `outputs/final_evaluation/v3_final/rationale_quality/cross_seed_stability.json`.** Support is 1,200 examples and overlap is exact visible-token index overlap, not semantic similarity.

| Metric | Exact value |
|---|---:|
| Mean pairwise Jaccard, mean | 0.632853963 |
| Mean pairwise Jaccard, median | 0.632859883 |
| Mean pairwise Jaccard, SD across examples | 0.059618236 |
| Mean pairwise overlap coefficient, mean | 0.771842198 |
| Mean pairwise overlap coefficient, median | 0.773504274 |
| Mean pairwise overlap coefficient, SD across examples | 0.045303945 |
| Three-seed prediction-label agreement | 0.940833333 |

## 5.4 Transformer-HardKuma rationale results

**Status: VERIFIED. Source: TF-RAT.** The package stores the per-seed controls; means/SDs are in `final_summary.csv`.

| Seed | Learned F1 | Random F1 | First F1 | Last F1 | Mean sufficiency drop | Mean comprehensiveness drop |
|---:|---:|---:|---:|---:|---:|---:|
| 42 | 0.930499 | 0.917369 | 0.802016 | 0.892282 | -0.035966 | 0.075238 |
| 43 | 0.931006 | 0.886726 | 0.803691 | 0.890034 | -0.044108 | 0.115763 |
| 44 | 0.935673 | 0.876046 | 0.760491 | 0.884858 | -0.064328 | 0.125933 |
| Mean ± seed SD | 0.932392 ± 0.002852 | 0.893380 ± 0.021450 | 0.788733 ± 0.024473 | 0.889058 ± 0.003807 | -0.048134 ± 0.014603 | 0.105645 ± 0.026819 |

The Transformer package did not save a stability summary, but the statistic is reconstructable from its final selected-index arrays. Read-only recomputation from `TF-RAT/final/seed*/test_predictions.jsonl` gives:

| Status | Metric | Exact value |
|---|---|---:|
| VERIFIED (recomputed) | Mean pairwise Jaccard, mean | 0.285407434 |
| VERIFIED (recomputed) | Mean pairwise Jaccard, median | 0.279962410 |
| VERIFIED (recomputed) | Mean pairwise Jaccard, SD across examples | 0.024032767 |
| VERIFIED (recomputed) | Mean pairwise overlap coefficient, mean | 0.443112540 |
| VERIFIED (recomputed) | Mean pairwise overlap coefficient, median | 0.437090874 |
| VERIFIED (recomputed) | Mean pairwise overlap coefficient, SD across examples | 0.028311646 |
| VERIFIED (recomputed) | Three-seed prediction-label agreement | 0.867500000 |

# 6. Domain F1

Each domain has 300 test examples. TF-IDF has one deterministic result; all neural means/SDs are across seeds 42/43/44. BiLSTM values come from B-SUB. Transformer values were recomputed from TF-FULL/TF-RAT frozen predictions because their packages did not save subgroup CSVs.

| Status | System | Domain | Seed F1s (42 / 43 / 44) | Mean ± sample SD |
|---|---|---|---|---:|
| VERIFIED | TF-IDF | abstracts | — | 0.936455 |
| VERIFIED | TF-IDF | books | — | 0.970100 |
| VERIFIED | TF-IDF | news | — | 0.940767 |
| VERIFIED | TF-IDF | poetry | — | 0.946667 |
| VERIFIED | Full BiLSTM | abstracts | 0.943144 / 0.947020 / 0.945946 | 0.945370 ± 0.002001 |
| VERIFIED | Full BiLSTM | books | 0.973333 / 0.970100 / 0.954248 | 0.965894 ± 0.010214 |
| VERIFIED | Full BiLSTM | news | 0.959459 / 0.948805 / 0.956811 | 0.955025 ± 0.005547 |
| VERIFIED | Full BiLSTM | poetry | 0.953947 / 0.960526 / 0.945338 | 0.953270 ± 0.007617 |
| VERIFIED | Rationale BiLSTM | abstracts | 0.941176 / 0.931507 / 0.933775 | 0.935486 ± 0.005057 |
| VERIFIED | Rationale BiLSTM | books | 0.960265 / 0.960265 / 0.950495 | 0.957008 ± 0.005641 |
| VERIFIED | Rationale BiLSTM | news | 0.962963 / 0.945946 / 0.952703 | 0.953871 ± 0.008568 |
| VERIFIED | Rationale BiLSTM | poetry | 0.936306 / 0.928571 / 0.940000 | 0.934959 ± 0.005832 |
| VERIFIED (recomputed) | Full Transformer | abstracts | 0.954248 / 0.960265 / 0.963696 | 0.959403 ± 0.004783 |
| VERIFIED (recomputed) | Full Transformer | books | 0.973510 / 0.973510 / 0.983278 | 0.976766 ± 0.005639 |
| VERIFIED (recomputed) | Full Transformer | news | 0.960265 / 0.967320 / 0.966216 | 0.964600 ± 0.003795 |
| VERIFIED (recomputed) | Full Transformer | poetry | 0.957096 / 0.960265 / 0.943144 | 0.953501 ± 0.009109 |
| VERIFIED (recomputed) | Transformer rationale | abstracts | 0.894737 / 0.890365 / 0.912162 | 0.899088 ± 0.011531 |
| VERIFIED (recomputed) | Transformer rationale | books | 0.951140 / 0.948052 / 0.959459 | 0.952884 ± 0.005900 |
| VERIFIED (recomputed) | Transformer rationale | news | 0.935484 / 0.938356 / 0.943144 | 0.938995 ± 0.003870 |
| VERIFIED (recomputed) | Transformer rationale | poetry | 0.940397 / 0.947020 / 0.928105 | 0.938507 ± 0.009598 |

# 7. Generator Detection Rates

Each generator subgroup contains 100 machine examples. Therefore this statistic is machine recall/detection rate, **not F1**. BiLSTM values come from B-SUB; Transformer values were recomputed from final predictions.

| Status | System | Generator | Seed rates (42 / 43 / 44) | Mean ± sample SD |
|---|---|---|---|---:|
| VERIFIED | TF-IDF | chatgpt | — | 0.910000 |
| VERIFIED | TF-IDF | gpt2 | — | 0.910000 |
| VERIFIED | TF-IDF | gpt4 | — | 0.930000 |
| VERIFIED | TF-IDF | llama-chat | — | 0.990000 |
| VERIFIED | TF-IDF | mistral | — | 0.920000 |
| VERIFIED | TF-IDF | mistral-chat | — | 0.970000 |
| VERIFIED | Full BiLSTM | chatgpt | 0.95 / 0.95 / 0.95 | 0.950000 ± 0.000000 |
| VERIFIED | Full BiLSTM | gpt2 | 0.93 / 0.94 / 0.96 | 0.943333 ± 0.015275 |
| VERIFIED | Full BiLSTM | gpt4 | 0.93 / 0.92 / 0.92 | 0.923333 ± 0.005774 |
| VERIFIED | Full BiLSTM | llama-chat | 0.98 / 0.99 / 1.00 | 0.990000 ± 0.010000 |
| VERIFIED | Full BiLSTM | mistral | 0.96 / 0.95 / 0.96 | 0.956667 ± 0.005774 |
| VERIFIED | Full BiLSTM | mistral-chat | 0.99 / 0.99 / 0.98 | 0.986667 ± 0.005774 |
| VERIFIED | Rationale BiLSTM | chatgpt | 0.95 / 0.95 / 0.93 | 0.943333 ± 0.011547 |
| VERIFIED | Rationale BiLSTM | gpt2 | 0.96 / 0.96 / 0.92 | 0.946667 ± 0.023094 |
| VERIFIED | Rationale BiLSTM | gpt4 | 0.95 / 0.89 / 0.92 | 0.920000 ± 0.030000 |
| VERIFIED | Rationale BiLSTM | llama-chat | 0.99 / 0.96 / 0.98 | 0.976667 ± 0.015275 |
| VERIFIED | Rationale BiLSTM | mistral | 0.95 / 0.90 / 0.93 | 0.926667 ± 0.025166 |
| VERIFIED | Rationale BiLSTM | mistral-chat | 0.99 / 0.98 / 0.99 | 0.986667 ± 0.005774 |
| VERIFIED (recomputed) | Full Transformer | chatgpt | 0.99 / 0.98 / 0.97 | 0.980000 ± 0.010000 |
| VERIFIED (recomputed) | Full Transformer | gpt2 | 0.94 / 0.96 / 0.95 | 0.950000 ± 0.010000 |
| VERIFIED (recomputed) | Full Transformer | gpt4 | 0.94 / 0.95 / 0.91 | 0.933333 ± 0.020817 |
| VERIFIED (recomputed) | Full Transformer | llama-chat | 0.97 / 0.99 / 0.98 | 0.980000 ± 0.010000 |
| VERIFIED (recomputed) | Full Transformer | mistral | 0.99 / 0.98 / 0.97 | 0.980000 ± 0.010000 |
| VERIFIED (recomputed) | Full Transformer | mistral-chat | 1.00 / 0.99 / 0.99 | 0.993333 ± 0.005774 |
| VERIFIED (recomputed) | Transformer rationale | chatgpt | 0.96 / 0.90 / 0.95 | 0.936667 ± 0.032146 |
| VERIFIED (recomputed) | Transformer rationale | gpt2 | 0.88 / 0.90 / 0.89 | 0.890000 ± 0.010000 |
| VERIFIED (recomputed) | Transformer rationale | gpt4 | 0.97 / 0.95 / 0.94 | 0.953333 ± 0.015275 |
| VERIFIED (recomputed) | Transformer rationale | llama-chat | 0.98 / 0.97 / 0.94 | 0.963333 ± 0.020817 |
| VERIFIED (recomputed) | Transformer rationale | mistral | 0.94 / 0.92 / 0.90 | 0.920000 ± 0.020000 |
| VERIFIED (recomputed) | Transformer rationale | mistral-chat | 0.96 / 0.96 / 0.98 | 0.966667 ± 0.011547 |

# 8. Human-Study Results

## 8.1 Sample and condition counts

**Status: VERIFIED. Sources:** HUMAN-D; `human_study_analysis/reports/per_form_counts.csv`, `condition_counts.csv`, and `passage_condition_exposure.csv`.

- Participants: **25**.
- Experimental judgements: **250** (10 per participant).
- Unique passages: **20**.
- Each condition reaches all 25 participants and all 20 passages, but unequal form enrolment yields unequal row counts.
- Per-form participant counts: form 1 = 5, form 2 = 3, form 3 = 4, form 4 = 3, form 5 = 4, form 6 = 6.

## 8.2 Descriptive condition results

Independent recomputation from `processed/responses_long.csv` exactly matches `descriptive_by_condition.csv`.

| Status | Condition | N | Correct n/N (accuracy) | Cannot Tell n/N (rate) | Confidence mean (SD) | Helpfulness mean (SD) | Relevance mean (SD) |
|---|---|---:|---:|---:|---:|---:|---:|
| VERIFIED | Plain | 83 | 39/83 (0.469880; 47.0%) | 8/83 (0.096386; 9.6%) | 3.578313 (1.105645) | NOT AVAILABLE by design | NOT AVAILABLE by design |
| VERIFIED | Detector | 82 | 37/82 (0.451220; 45.1%) | 7/82 (0.085366; 8.5%) | 3.304878 (1.062132) | 3.073171 (1.163015) | 3.304878 (1.050444) |
| VERIFIED | Random | 85 | 38/85 (0.447059; 44.7%) | 13/85 (0.152941; 15.3%) | 3.505882 (1.075966) | 3.082353 (1.136115) | 3.364706 (1.132287) |

## 8.3 Adjusted probabilities

**Status: VERIFIED. Source:** `human_study_analysis/reports/model_adjusted_probabilities.csv` (HUMAN-I). Intervals use the activated two-way cluster-robust fallback with 19 reference degrees of freedom.

| Status | Condition | Adjusted probability | Cluster-robust SE | 95% CI |
|---|---|---:|---:|---:|
| VERIFIED | Plain | 0.488926 | 0.130600 | [0.215578, 0.762274] |
| VERIFIED | Detector | 0.425234 | 0.098652 | [0.218754, 0.631714] |
| VERIFIED | Random | 0.453734 | 0.080528 | [0.285187, 0.622280] |

## 8.4 Planned contrasts

**Status: VERIFIED. Source:** `human_study_analysis/reports/model_planned_contrasts.csv` (HUMAN-I).

| Status | Contrast | Adjusted probability difference | 95% difference CI | Odds ratio | 95% OR CI | Unadjusted p | Holm-adjusted p |
|---|---|---:|---:|---:|---:|---:|---:|
| VERIFIED | Detector − Plain | -0.063692 | [-0.520796, 0.393412] | 0.770559 | [0.118119, 5.026783] | 0.774293 | 1.000000 |
| VERIFIED | Detector − Random | -0.028499 | [-0.215918, 0.158919] | 0.889285 | [0.409843, 1.929587] | 0.754674 | 1.000000 |

## 8.5 Singular-fit diagnostic and clustered inference

**Status: VERIFIED. Sources:** `human_study_analysis/reports/model_diagnostics.txt`, `model_variance_components.csv`, and `fallback_model_diagnostics.txt`.

| Item | Exact final value |
|---|---|
| Planned GLMM | `correct ~ condition + item_position + (1 | participant_id) + (1 | passage_id)` |
| Rows | 250 |
| Participants | 25 |
| Passages | 20 |
| Optimizer | `bobyqa` |
| Optimizer code | 0 |
| Convergence message | `boundary (singular) fit: see help('isSingular')` |
| Captured warnings | none |
| Singular at tolerance 1e-4 | TRUE |
| Fixed estimates finite | TRUE |
| Participant random-intercept variance / SD | 0 / 0 |
| Passage random-intercept variance / SD | 0 / 0 |
| Planned GLMM diagnostics pass | FALSE |
| Fallback trigger | planned GLMM singular; both variances zero |
| Fallback model | `correct ~ condition + item_position` |
| Fallback convergence | TRUE; no warnings |
| Covariance | Cameron–Gelbach–Miller two-way participant/passage cluster-robust sandwich |
| Covariance options | HC1; finite-cluster adjustment; singleton-intersection HC0 subtraction; PSD correction enabled |
| Participant clusters | 25 |
| Passage clusters | 20 |
| Reference degrees of freedom | 19 |
| Fixed-design rank | 12/12 |
| Fallback diagnostics pass | TRUE |

# 9. Corrections and Unavailable Results

## 9.1 Stale or incorrect numbers/labels in the dossier

| Status | Dossier location/claim | Locked correction | Evidence |
|---|---|---|---|
| **CORRECTED** | `paper_evidence_dossier.md:123`: validation 93.33% and test 93.50% complete at 512 “final tokens” | Final-tokenizer coverage is validation **91.0000% (1,092/1,200)** and test **91.4167% (1,097/1,200)**. Train is 91.3368% (5,261/5,760). | Raw frozen JSONL + final `vocab.py`; hashes match FREEZE. The old values came from cached pre-lock tokenisation. |
| **CORRECTED** | The dossier omits final-tokenizer 256/1024 coverage | At 256: train 42.1528%, validation 42.8333%, test 39.6667%. At 1,024: 98.0903%, 98.1667%, 98.0000%. | Section 3.3 of this report. |
| **CORRECTED** | `paper_evidence_dossier.md:388` can be read as saying the canonical paired-bootstrap seed is 20260818 for all comparisons | Only rationale-minus-full uses 20260818. Rationale-minus-TF-IDF uses 20260819; full-minus-TF-IDF uses 20260820. | BOOT. The differences/CIs printed in the dossier are correct. |
| **CORRECTED (terminology)** | `paper_evidence_dossier.md:384` calls generator-only values “machine-generator F1” | Generator-only groups contain no human negatives; the values are machine recall/detection rates, not binary F1. GPT-4 remains the lowest mean rate for both final BiLSTMs: full 0.923333 ± 0.005774, rationale 0.920000 ± 0.030000. | B-SUB. |
| VERIFIED | Dossier headline TF-IDF/BiLSTM/Transformer test metrics | All agree with final artefacts at the displayed precision. | Sections 1.1–1.2. |
| VERIFIED | Dossier aggregate bootstrap differences and CIs | All three displayed values agree after rounding. | Section 2.1. |
| VERIFIED | Dossier context sweep F1 and runtime means | All agree after rounding. | Section 3.1. |
| VERIFIED | Dossier 20/30/40 budget results, selection rates and counts | All agree after rounding. | Section 4. |
| VERIFIED | Dossier final rationale counts, controls, sufficiency/comprehensiveness and BiLSTM stability | All agree after rounding. | Section 5. |
| VERIFIED | Dossier human descriptive and inferential values | All agree after rounding. | Section 8. |

## 9.2 Results not available under the final contract

| Status | Requested result | Reason |
|---|---|---|
| NOT AVAILABLE | Paired-bootstrap/significance intervals for Transformer comparisons | No final Transformer bootstrap artefact exists. |
| NOT AVAILABLE | A seed SD for TF-IDF | Only one deterministic frozen TF-IDF model was evaluated. |
| NOT AVAILABLE | Plain-condition helpfulness/relevance | Questions are missing by design for Plain, not missing-data failures. |
| NOT AVAILABLE | Final corrected-surface fixed-102 numerical comparison | Completion is recorded, but metrics/checkpoints are absent from the current repository; pre-lock fixed-102 outputs are inadmissible. |
| NOT AVAILABLE | Population-level human detection accuracy | The 20 passages were deliberately CH/CM/FP/FN stratified and realised condition exposures are unequal. |

# 10. Results Lock

The values in Sections 1–8 are the locked numerical values for the final paper. The principal headline values are:

- TF-IDF: F1 `0.948610`, AUROC `0.988842`.
- Full BiLSTM: F1 `0.954903 ± 0.003768`, AUROC `0.989261 ± 0.000668`.
- Rationale BiLSTM: F1 `0.945247 ± 0.004289`, AUROC `0.985953 ± 0.000256`, test selected fraction `0.401510`, mean/median/range `121.0525 / 114.5 / 36–205`.
- Full Transformer: F1 `0.963559 ± 0.002095`, AUROC `0.989339 ± 0.000397`.
- Transformer rationale: F1 `0.932392 ± 0.002852`, AUROC `0.976825 ± 0.002824`.
- Primary paired difference, rationale BiLSTM minus full BiLSTM: `-0.009655`, 95% CI `[-0.017162, -0.002288]`.
- Human study: Detector minus Plain `-0.063692`, 95% CI `[-0.520796, 0.393412]`, OR `0.770559`, Holm `p=1`; Detector minus Random `-0.028499`, 95% CI `[-0.215918, 0.158919]`, OR `0.889285`, Holm `p=1`.

The paper must replace the old 512-token coverage statement with the final-tokenizer figures in Section 3.3. No other stale final Results number was found in the dossier at its displayed precision.
