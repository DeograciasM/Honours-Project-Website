# Sparse Token Rationales for Machine-Generated Text Detection

University of Cape Town Computer Science Honours research project.

This project studies binary detection of machine-generated text on an English subset of
the RAID benchmark. It compares a word-and-character TF-IDF baseline with full-context
BiLSTM and Transformer classifiers.

The main models use HardKuma gates to select sparse token rationales before making a
prediction. Full-context and rationale models are evaluated with matched architectures
and three random seeds. A separate human study compares plain text, detector
highlighting, and random highlighting.

## Setup

Python 3.11 to 3.13 is supported. Create and activate a virtual environment, then install
the development environment:

```bash
python3 -m venv .venv
source .venv/bin/activate
make install-dev
```

Use `make install` for runtime dependencies only. Dependencies for downloading external
RAID data can be installed separately with:

```bash
python3 -m pip install -r requirements-data.txt
```

## Data

The final dataset is `raid_en_balanced`. RAID is external licensed data and is not
included in the submission. Restore the three split files at:

```text
data/processed/raid_en_balanced/train.jsonl
data/processed/raid_en_balanced/validation.jsonl
data/processed/raid_en_balanced/test.jsonl
```

Expected sizes and SHA-256 hashes are recorded in
`data/manifests/raid_en_balanced.json`. Validate restored data with `make check-data`.

Neural training also requires the filtered 300-dimensional GloVe file at
`data/embeddings/glove.raid.300d.txt`. It is not included in the submission.

## Running the project

The Makefile is the main interface:

| Target | Purpose |
|---|---|
| `make test` | Run the Python test suite |
| `make lint` | Run Ruff on the retained source and tests |
| `make check` | Run linting and tests |
| `make check-data` | Validate dataset fields, splits, duplicates, and source leakage |
| `make train-tfidf` | Train the final TF-IDF baseline |
| `make train-bilstm` | Train the full-context BiLSTM for seeds 42, 43, and 44 |
| `make train-hardkuma` | Train the HardKuma BiLSTM for all final seeds |
| `make train-transformer` | Train the full-context Transformer for all final seeds |
| `make train-transformer-rationale` | Train the HardKuma Transformer for all final seeds |
| `make evaluate` | Run the guarded final BiLSTM and TF-IDF evaluation |
| `make figures` | Regenerate the final context and budget figures |
| `make human-study` | Run the R human-study analysis |

Training targets write new runs under `outputs/reproduction/` and do not overwrite
non-empty run directories. They default to Apple MPS, matching the original BiLSTM
runs. Override the device when needed, for example `make train-bilstm DEVICE=cpu`.

Final experiment settings are recorded in `configs/final/`. Model checkpoints are not
included in this submission.

## Evaluation

Re-running checkpoint-based evaluation requires the trained model checkpoints and the
external RAID splits to be restored separately. The workflow also expects Apple MPS and a
new final-evaluation output directory; it refuses to repeat or overwrite a started run.

Compact metrics, tables, and figures are available under `results/final/`.

## Human study

The public repository contains the R analysis and aggregate outputs only. Participant
responses are private. `make human-study` requires the authorised processed inputs to be
restored under `human_study_analysis/processed/` and the locked R environment to be
installed from `human_study_analysis/renv.lock`.

## Repository structure

```text
configs/final/          final experiment settings
data/                   dataset manifest metadata
human_study_analysis/   R analysis and environment lockfile
results/                final aggregate outputs
scripts/                data, training, evaluation, and figure entry points
src/detectgpt/          Python package
tests/                  Python tests
```

## Citation and licence

The dataset is described in Dugan et al., "RAID: A Shared Benchmark for Robust Evaluation
of Machine-Generated Text Detectors", ACL 2024. RAID, GloVe, participant data, and
third-party models remain subject to their respective terms. No licence has been selected
for the original project code.
