from __future__ import annotations

import argparse
import json
from collections import Counter, defaultdict
from pathlib import Path


SPLITS = ("train", "validation", "test")
REQUIRED_FIELDS = {
    "id", "text", "label", "label_id", "language", "domain", "source_dataset",
    "source_id", "generator", "generator_type", "decoding", "attack", "title",
    "prompt", "split", "word_count", "sentence_count",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Validate the processed balanced English RAID dataset directory."
    )
    parser.add_argument(
        "--data-dir",
        default=Path("data/processed/raid_en_balanced"),
        type=Path,
        help="Dataset directory to validate.",
    )
    return parser.parse_args()


def main() -> None:
    data_dir = parse_args().data_dir
    print(f"Validating: {data_dir}\n")
    all_ids: set[str] = set()
    all_texts: set[str] = set()
    errors: list[str] = []
    split_label_counts: dict[str, Counter[str]] = defaultdict(Counter)
    split_domain_counts: dict[str, Counter[str]] = defaultdict(Counter)
    split_generator_counts: dict[str, Counter[str]] = defaultdict(Counter)

    for split in SPLITS:
        with (data_dir / f"{split}.jsonl").open("r", encoding="utf-8") as handle:
            for line_no, line in enumerate(handle, start=1):
                row = json.loads(line)
                missing = REQUIRED_FIELDS - set(row)
                if missing:
                    errors.append(f"{split}:{line_no} missing fields: {missing}")
                if row["split"] != split:
                    errors.append(f"{split}:{line_no} has split={row['split']}")
                if row["label"] == "human" and row["label_id"] != 0:
                    errors.append(f"{split}:{line_no} human has wrong label_id")
                if row["label"] == "machine" and row["label_id"] != 1:
                    errors.append(f"{split}:{line_no} machine has wrong label_id")
                if row["language"] != "en":
                    errors.append(f"{split}:{line_no} non-English language value")
                if row["attack"] != "none":
                    errors.append(f"{split}:{line_no} attack is not none")
                if not isinstance(row["text"], str) or not row["text"].strip():
                    errors.append(f"{split}:{line_no} empty text")
                if row["id"] in all_ids:
                    errors.append(f"{split}:{line_no} duplicate id: {row['id']}")
                all_ids.add(row["id"])
                if row["text"] in all_texts:
                    errors.append(f"{split}:{line_no} duplicate text found")
                all_texts.add(row["text"])
                split_label_counts[split][row["label"]] += 1
                split_domain_counts[split][row["domain"]] += 1
                split_generator_counts[split][row["generator"]] += 1

    for heading, counts in (
        ("Split label counts:", split_label_counts),
        ("\nSplit domain counts:", split_domain_counts),
        ("\nSplit generator counts:", split_generator_counts),
    ):
        print(heading)
        for split in SPLITS:
            print(split, dict(counts[split]))

    if errors:
        print(f"\nFound {len(errors)} issues. Showing first 20:")
        for error in errors[:20]:
            print("-", error)
        raise SystemExit(1)
    print("\nValidation passed.")


if __name__ == "__main__":
    main()
