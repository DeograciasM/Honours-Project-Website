from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path
from typing import Any

from detectgpt.baselines.tfidf import DEFAULT_TFIDF_CONFIG, build_tfidf_pipeline, extract_feature_weights
from detectgpt.data.io import JsonRow, load_dataset_splits, write_jsonl
from detectgpt.data.validation import REQUIRED_SPLITS, validate_dataset
from detectgpt.evaluation.metrics import evaluate_split
from detectgpt.evaluation.reporting import write_run_summary
from detectgpt.utils.seed import set_seed

MACHINE_GENERATORS = ["gpt2", "mistral", "mistral-chat", "llama-chat", "chatgpt", "gpt4"]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Held-out-generator TF-IDF evaluation: for each machine generator G, "
        "train on human + the other five generators and test on human + G only."
    )
    parser.add_argument("--data-dir", required=True, type=Path, help="Dataset directory with train/validation/test JSONL files.")
    parser.add_argument("--out-dir", default=Path("outputs/baselines"), type=Path, help="Parent output directory; each generator gets its own subdirectory.")
    parser.add_argument("--seed", default=42, type=int, help="Random seed.")
    return parser.parse_args()


def split_texts_and_labels(rows: list[JsonRow]) -> tuple[list[str], list[int]]:
    return [str(row["text"]) for row in rows], [int(row["label_id"]) for row in rows]


def filter_exclude_generator(rows: list[JsonRow], generator: str) -> list[JsonRow]:
    return [row for row in rows if row["generator"] != generator]


def filter_human_or_generator(rows: list[JsonRow], generator: str) -> list[JsonRow]:
    return [row for row in rows if row["generator"] == "human" or row["generator"] == generator]


def make_predictions(model, rows: list[JsonRow]) -> tuple[list[int], list[float], list[JsonRow]]:
    texts = [str(row["text"]) for row in rows]
    predicted_labels = [int(label) for label in model.predict(texts)]
    machine_probabilities = [float(probability) for probability in model.predict_proba(texts)[:, 1]]

    prediction_rows: list[JsonRow] = []
    for row, predicted_label, machine_probability in zip(rows, predicted_labels, machine_probabilities, strict=True):
        prediction_rows.append(
            {
                "id": row["id"],
                "source_id": row["source_id"],
                "split": row["split"],
                "domain": row["domain"],
                "generator": row["generator"],
                "attack": row["attack"],
                "decoding": row["decoding"],
                "label": row["label"],
                "label_id": int(row["label_id"]),
                "predicted_label_id": predicted_label,
                "predicted_label": "machine" if predicted_label == 1 else "human",
                "machine_probability": machine_probability,
                "correct": predicted_label == int(row["label_id"]),
            }
        )

    return predicted_labels, machine_probabilities, prediction_rows


def save_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def run_for_generator(
    rows_by_split: dict[str, list[JsonRow]],
    generator: str,
    out_dir: Path,
    run_name: str,
    seed: int,
) -> dict[str, Any]:
    set_seed(seed)

    train_rows = filter_exclude_generator(rows_by_split["train"], generator)
    validation_rows = filter_exclude_generator(rows_by_split["validation"], generator)
    test_rows = filter_human_or_generator(rows_by_split["test"], generator)

    config = copy.deepcopy(DEFAULT_TFIDF_CONFIG)
    config.update(
        {
            "run_name": run_name,
            "held_out_generator": generator,
            "seed": seed,
            "splits": {
                "train": len(train_rows),
                "validation": len(validation_rows),
                "test": len(test_rows),
            },
        }
    )

    train_texts, train_labels = split_texts_and_labels(train_rows)
    model = build_tfidf_pipeline(config)
    model.fit(train_texts, train_labels)

    metrics: dict[str, Any] = {"run_name": run_name, "held_out_generator": generator}
    predictions_by_split: dict[str, list[JsonRow]] = {}
    eval_rows = {"validation": validation_rows, "test": test_rows}

    for split, rows in eval_rows.items():
        predicted_labels, machine_probabilities, prediction_rows = make_predictions(model, rows)
        metrics[split] = evaluate_split(rows, predicted_labels, machine_probabilities)
        predictions_by_split[split] = prediction_rows

    feature_weights = extract_feature_weights(model)

    out_dir.mkdir(parents=True, exist_ok=True)
    save_json(out_dir / "config.json", config)
    save_json(out_dir / "metrics.json", metrics)
    save_json(out_dir / "feature_weights.json", feature_weights)
    write_jsonl(out_dir / "validation_predictions.jsonl", predictions_by_split["validation"])
    write_jsonl(out_dir / "test_predictions.jsonl", predictions_by_split["test"])
    write_run_summary(out_dir / "run_summary.md", run_name, config, metrics)

    return metrics


def main() -> None:
    args = parse_args()
    rows_by_split = load_dataset_splits(args.data_dir, REQUIRED_SPLITS)
    validate_dataset(args.data_dir, rows_by_split)

    results = []
    for generator in MACHINE_GENERATORS:
        run_name = f"tfidf_heldout_{generator}"
        out_dir = args.out_dir / run_name
        metrics = run_for_generator(rows_by_split, generator, out_dir, run_name, args.seed)

        test_overall = metrics["test"]["overall"]
        results.append(
            {
                "generator": generator,
                "test_f1": test_overall["machine_f1"],
                "test_auroc": test_overall["auroc"],
                "test_support": test_overall["support"]["total"],
            }
        )
        auroc_display = f"{test_overall['auroc']:.4f}" if test_overall["auroc"] is not None else "n/a"
        print(
            f"{run_name}: test_f1={test_overall['machine_f1']:.4f} "
            f"test_auroc={auroc_display} test_support={test_overall['support']['total']}"
        )

    print("\n## Held-out generator summary")
    print("generator\ttest_f1\ttest_auroc\ttest_support")
    for row in results:
        auroc_display = f"{row['test_auroc']:.4f}" if row["test_auroc"] is not None else "n/a"
        print(f"{row['generator']}\t{row['test_f1']:.4f}\t{auroc_display}\t{row['test_support']}")


if __name__ == "__main__":
    main()
