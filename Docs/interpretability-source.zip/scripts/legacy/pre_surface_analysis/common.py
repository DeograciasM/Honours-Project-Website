from __future__ import annotations

import json
import math
from collections.abc import Iterable
from pathlib import Path
from typing import Any

import numpy as np
from scipy.stats import binomtest
from sklearn.metrics import (
    brier_score_loss,
    confusion_matrix,
    f1_score,
    log_loss,
    precision_score,
    recall_score,
    roc_auc_score,
)


Json = dict[str, Any]


def read_json(path: Path) -> Json:
    return json.loads(path.read_text(encoding="utf-8"))


def read_jsonl(path: Path) -> list[Json]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line]


def write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def write_jsonl(path: Path, rows: Iterable[Json]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(row, sort_keys=True) + "\n")


def probability(row: Json) -> float:
    if "probability_machine" in row:
        return float(row["probability_machine"])
    return float(row["machine_probability"])


def predictions_by_id(path: Path) -> dict[str, Json]:
    rows = read_jsonl(path)
    output = {str(row["id"]): row for row in rows}
    if len(output) != len(rows):
        raise ValueError(f"Duplicate IDs in {path}")
    return output


def aligned_rows(*mappings: dict[str, Json]) -> list[tuple[Json, ...]]:
    if not mappings:
        return []
    ids = set(mappings[0])
    for mapping in mappings[1:]:
        if set(mapping) != ids:
            missing = ids.symmetric_difference(mapping)
            raise ValueError(f"Prediction IDs do not align; example differences: {sorted(missing)[:5]}")
    return [tuple(mapping[example_id] for mapping in mappings) for example_id in sorted(ids)]


def binary_metrics(y_true: list[int], y_pred: list[int], y_prob: list[float]) -> Json:
    if not y_true:
        return {
            "support": 0,
            "human_support": 0,
            "machine_support": 0,
            "machine_precision": None,
            "machine_recall": None,
            "machine_f1": None,
            "macro_f1": None,
            "auroc": None,
            "human_false_positive_rate": None,
            "machine_false_negative_rate": None,
            "confusion_matrix": [[0, 0], [0, 0]],
        }
    matrix = confusion_matrix(y_true, y_pred, labels=[0, 1])
    return {
        "support": len(y_true),
        "human_support": int(sum(value == 0 for value in y_true)),
        "machine_support": int(sum(value == 1 for value in y_true)),
        "machine_precision": float(precision_score(y_true, y_pred, zero_division=0)),
        "machine_recall": float(recall_score(y_true, y_pred, zero_division=0)),
        "machine_f1": float(f1_score(y_true, y_pred, zero_division=0)),
        "macro_f1": float(f1_score(y_true, y_pred, average="macro", zero_division=0)),
        "auroc": float(roc_auc_score(y_true, y_prob)) if len(set(y_true)) == 2 else None,
        "human_false_positive_rate": float(matrix[0, 1] / matrix[0].sum()) if matrix[0].sum() else None,
        "machine_false_negative_rate": float(matrix[1, 0] / matrix[1].sum()) if matrix[1].sum() else None,
        "confusion_matrix": matrix.tolist(),
    }


def metrics_from_rows(rows: list[Json]) -> Json:
    y_true = [int(row["label_id"]) for row in rows]
    y_prob = [probability(row) for row in rows]
    y_pred = [int(row.get("predicted_label_id", value >= 0.5)) for row, value in zip(rows, y_prob, strict=True)]
    return binary_metrics(y_true, y_pred, y_prob)


def length_bucket(token_count: int) -> str:
    if token_count <= 128:
        return "1-128"
    if token_count <= 256:
        return "129-256"
    if token_count <= 512:
        return "257-512"
    return ">512"


def confidence_bucket(probability_machine: float) -> str:
    confidence = max(probability_machine, 1.0 - probability_machine)
    if confidence < 0.60:
        return "0.50-0.60"
    if confidence < 0.75:
        return "0.60-0.75"
    if confidence < 0.90:
        return "0.75-0.90"
    return "0.90-1.00"


def paired_bootstrap_f1(
    y_true: list[int],
    pred_a: list[int],
    pred_b: list[int],
    *,
    resamples: int = 10_000,
    seed: int = 20260805,
) -> Json:
    truth = np.asarray(y_true)
    a = np.asarray(pred_a)
    b = np.asarray(pred_b)
    observed = float(f1_score(truth, b, zero_division=0) - f1_score(truth, a, zero_division=0))
    rng = np.random.default_rng(seed)
    differences = np.empty(resamples, dtype=np.float64)
    true_positive_a = ((truth == 1) & (a == 1)).astype(np.int8)
    false_positive_a = ((truth == 0) & (a == 1)).astype(np.int8)
    false_negative_a = ((truth == 1) & (a == 0)).astype(np.int8)
    true_positive_b = ((truth == 1) & (b == 1)).astype(np.int8)
    false_positive_b = ((truth == 0) & (b == 1)).astype(np.int8)
    false_negative_b = ((truth == 1) & (b == 0)).astype(np.int8)
    for index in range(resamples):
        sample = rng.integers(0, len(truth), size=len(truth))
        tp_a = int(true_positive_a[sample].sum())
        fp_a = int(false_positive_a[sample].sum())
        fn_a = int(false_negative_a[sample].sum())
        tp_b = int(true_positive_b[sample].sum())
        fp_b = int(false_positive_b[sample].sum())
        fn_b = int(false_negative_b[sample].sum())
        denom_a = 2 * tp_a + fp_a + fn_a
        denom_b = 2 * tp_b + fp_b + fn_b
        f1_a = 2 * tp_a / denom_a if denom_a else 0.0
        f1_b = 2 * tp_b / denom_b if denom_b else 0.0
        differences[index] = f1_b - f1_a
    lower, upper = np.quantile(differences, [0.025, 0.975])
    return {
        "definition": "F1(B) - F1(A)",
        "observed_difference": observed,
        "confidence_interval_95": [float(lower), float(upper)],
        "resamples": resamples,
        "seed": seed,
    }


def exact_mcnemar(y_true: list[int], pred_a: list[int], pred_b: list[int]) -> Json:
    correct_a = np.asarray(pred_a) == np.asarray(y_true)
    correct_b = np.asarray(pred_b) == np.asarray(y_true)
    both_correct = int(np.sum(correct_a & correct_b))
    a_only = int(np.sum(correct_a & ~correct_b))
    b_only = int(np.sum(~correct_a & correct_b))
    both_wrong = int(np.sum(~correct_a & ~correct_b))
    discordant = a_only + b_only
    p_value = float(binomtest(min(a_only, b_only), discordant, 0.5).pvalue) if discordant else 1.0
    statistic = float((abs(a_only - b_only) - 1) ** 2 / discordant) if discordant else 0.0
    return {
        "table_a_correct_rows_b_correct_columns": [
            [both_wrong, b_only],
            [a_only, both_correct],
        ],
        "both_correct": both_correct,
        "a_only_correct_b_newly_broken": a_only,
        "b_only_correct_b_corrects_a": b_only,
        "both_incorrect": both_wrong,
        "discordant": discordant,
        "continuity_corrected_chi_square_statistic": statistic,
        "exact_two_sided_p_value": p_value,
    }


def calibration_metrics(y_true: list[int], y_prob: list[float], bins: int = 10) -> Json:
    truth = np.asarray(y_true, dtype=np.int64)
    probs = np.asarray(y_prob, dtype=np.float64)
    boundaries = np.linspace(0.0, 1.0, bins + 1)
    bin_rows: list[Json] = []
    ece = 0.0
    maximum = 0.0
    for index in range(bins):
        if index == bins - 1:
            mask = (probs >= boundaries[index]) & (probs <= boundaries[index + 1])
        else:
            mask = (probs >= boundaries[index]) & (probs < boundaries[index + 1])
        count = int(mask.sum())
        if count:
            mean_probability = float(probs[mask].mean())
            observed_rate = float(truth[mask].mean())
            gap = abs(mean_probability - observed_rate)
            ece += count / len(truth) * gap
            maximum = max(maximum, gap)
        else:
            mean_probability = None
            observed_rate = None
            gap = None
        bin_rows.append(
            {
                "lower": float(boundaries[index]),
                "upper": float(boundaries[index + 1]),
                "support": count,
                "mean_probability": mean_probability,
                "observed_machine_rate": observed_rate,
                "absolute_gap": gap,
            }
        )
    return {
        "brier_score": float(brier_score_loss(truth, probs)),
        "negative_log_likelihood": float(log_loss(truth, np.column_stack([1.0 - probs, probs]), labels=[0, 1])),
        "expected_calibration_error": float(ece),
        "maximum_calibration_error": float(maximum),
        "bins": bins,
        "bin_definition": "equal-width machine-probability bins; left-inclusive, right-exclusive except final bin",
        "reliability": bin_rows,
    }


def threshold_at_validation_fpr(rows: list[Json], target_fpr: float) -> Json:
    human_probabilities = sorted((probability(row) for row in rows if int(row["label_id"]) == 0), reverse=True)
    if not human_probabilities:
        raise ValueError("Validation rows contain no human examples")
    allowed_false_positives = math.floor(target_fpr * len(human_probabilities))
    if allowed_false_positives == 0:
        threshold = math.nextafter(human_probabilities[0], math.inf)
    else:
        threshold = human_probabilities[allowed_false_positives - 1]
    achieved = sum(value >= threshold for value in human_probabilities) / len(human_probabilities)
    return {
        "target_human_fpr": target_fpr,
        "threshold": float(threshold),
        "validation_human_support": len(human_probabilities),
        "validation_achieved_fpr": float(achieved),
    }


def apply_operating_point(rows: list[Json], threshold_info: Json) -> Json:
    threshold = float(threshold_info["threshold"])
    human = [row for row in rows if int(row["label_id"]) == 0]
    machine = [row for row in rows if int(row["label_id"]) == 1]
    return {
        **threshold_info,
        "test_human_support": len(human),
        "test_machine_support": len(machine),
        "test_achieved_fpr": sum(probability(row) >= threshold for row in human) / len(human),
        "test_machine_recall": sum(probability(row) >= threshold for row in machine) / len(machine),
    }
