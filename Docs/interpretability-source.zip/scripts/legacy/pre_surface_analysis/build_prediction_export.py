from __future__ import annotations

import argparse
import csv
import json
import re
import statistics
import sys
from pathlib import Path
from typing import Any

REPO_ROOT = Path(__file__).resolve().parents[2]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from detectgpt.rationales.vocab import tokenize
from scripts.legacy.pre_surface_analysis.common import predictions_by_id, probability, read_json, read_jsonl, write_jsonl


OUTPUT_ROOT = REPO_ROOT / "outputs/archive/pre_surface_final_analysis"
DOC_ROOT = REPO_ROOT / "docs/archive/pre_surface_final_analysis"
TOKEN_RE = re.compile(r"[A-Za-z0-9]+(?:'[A-Za-z0-9]+)?")
STOP_WORDS = {
    "a", "an", "and", "are", "as", "at", "be", "been", "but", "by", "for", "from", "had", "has", "have",
    "he", "her", "his", "i", "in", "is", "it", "its", "of", "on", "or", "she", "that", "the", "their", "they",
    "this", "to", "was", "we", "were", "which", "with", "you", "your",
}
BOILERPLATE_PROXY = {
    "analysis", "approach", "data", "method", "methods", "paper", "research", "results", "said", "study", "system",
}


def best_run(template: str) -> tuple[int, Path]:
    candidates = []
    for seed in (42, 43, 44):
        run_dir = REPO_ROOT / template.format(seed=seed)
        metrics_path = run_dir / "metrics.json"
        if not metrics_path.exists():
            raise FileNotFoundError(metrics_path)
        candidates.append((float(read_json(metrics_path)["validation"]["overall"]["machine_f1"]), seed, run_dir))
    _, seed, run_dir = max(candidates)
    return seed, run_dir


def visible_prefix(text: str, limit: int) -> str:
    matches = list(TOKEN_RE.finditer(text))
    if len(matches) <= limit:
        return text
    return text[: matches[limit - 1].end()]


def export_rows() -> tuple[list[dict[str, Any]], dict[str, Any]]:
    selected = {
        128: best_run("outputs/rationales/kuma_corrected_t40_len128_ratefix_s{seed}"),
        256: best_run("outputs/rationales/kuma_corrected_t40_ratefix_s{seed}"),
        512: best_run("outputs/rationales/kuma_corrected_t40_len512_ratefix_s{seed}"),
    }
    context_predictions = {
        context: predictions_by_id(run_dir / "test_predictions.jsonl")
        for context, (_, run_dir) in selected.items()
    }
    seed_predictions = {
        seed: predictions_by_id(REPO_ROOT / f"outputs/rationales/kuma_corrected_t40_len512_ratefix_s{seed}/test_predictions.jsonl")
        for seed in (42, 43, 44)
    }
    metadata = {str(row["id"]): row for row in read_jsonl(REPO_ROOT / "data/processed/raid_core_en_v3/test.jsonl")}
    stability_path = OUTPUT_ROOT / "rationale_stability_per_example.json"
    stability = {str(row["id"]): row for row in read_json(stability_path)} if stability_path.exists() else {}
    analytical_path = OUTPUT_ROOT / "hardkuma_diagnostics/per_example_controller.jsonl"
    analytical = predictions_by_id(analytical_path) if analytical_path.exists() else {}

    output = []
    for example_id in sorted(metadata):
        source = metadata[example_id]
        tokens = tokenize(source["text"])
        context_rows = {context: context_predictions[context][example_id] for context in (128, 256, 512)}
        main = context_rows[512]
        indices = [int(value) for value in main["selected_token_indices"]]
        gate_values = [float(value) for value in main["token_gate_values"]]
        selected_scores = [gate_values[index] for index in indices]
        after_128 = [index for index in indices if index >= 128]
        after_256 = [index for index in indices if index >= 256]
        labels = [int(context_rows[context]["predicted_label_id"]) for context in (128, 256, 512)]
        seed_rows = {seed: seed_predictions[seed][example_id] for seed in (42, 43, 44)}
        row: dict[str, Any] = {
            "id": example_id,
            "source_id": source.get("source_id"),
            "domain": source.get("domain"),
            "generator": source.get("generator"),
            "true_label": source.get("label"),
            "label_id": int(source["label_id"]),
            "attack": source.get("attack"),
            "decoding": source.get("decoding"),
            "original_text": source["text"],
            "original_token_count": len(tokens),
            "visible_text_128": visible_prefix(source["text"], 128),
            "visible_text_256": visible_prefix(source["text"], 256),
            "visible_text_512": visible_prefix(source["text"], 512),
            "visible_token_count_128": min(128, len(tokens)),
            "visible_token_count_256": min(256, len(tokens)),
            "visible_token_count_512": min(512, len(tokens)),
            "visible_fraction_128": min(128, len(tokens)) / max(1, len(tokens)),
            "visible_fraction_256": min(256, len(tokens)) / max(1, len(tokens)),
            "visible_fraction_512": min(512, len(tokens)) / max(1, len(tokens)),
            "exceeds_128": len(tokens) > 128,
            "exceeds_256": len(tokens) > 256,
            "exceeds_512": len(tokens) > 512,
            "label_changes_across_contexts": len(set(labels)) > 1,
            "probability_change_128_to_256": probability(context_rows[256]) - probability(context_rows[128]),
            "probability_change_256_to_512": probability(context_rows[512]) - probability(context_rows[256]),
            "selected_tokens": main["selected_tokens"],
            "selected_token_indices": indices,
            "selected_token_scores": selected_scores,
            "rationale_length": len(indices),
            "rationale_fraction": float(main["selected_fraction"]),
            "selected_indices_after_128": after_128,
            "selected_tokens_after_128": [tokens[index] for index in after_128 if index < len(tokens)],
            "selected_indices_after_256": after_256,
            "selected_tokens_after_256": [tokens[index] for index in after_256 if index < len(tokens)],
            "rationale_proportion_after_256": len(after_256) / max(1, len(indices)),
            "zero_selection_fallback": bool(main["used_empty_selection_fallback"]),
            "analytical_expected_gate_rate": analytical.get(example_id, {}).get("expected_nonzero_rate"),
            "deterministic_selection_rate": float(main["selected_fraction"]),
            "all_seeds_agree_label": len({int(value["predicted_label_id"]) for value in seed_rows.values()}) == 1,
            "mean_pairwise_seed_jaccard": stability.get(example_id, {}).get("mean_pairwise_jaccard"),
        }
        for context in (128, 256, 512):
            prediction = context_rows[context]
            row[f"selected_checkpoint_seed_{context}"] = selected[context][0]
            row[f"predicted_label_{context}"] = prediction["predicted_label"]
            row[f"predicted_label_id_{context}"] = int(prediction["predicted_label_id"])
            row[f"machine_probability_{context}"] = probability(prediction)
            row[f"correct_{context}"] = int(prediction["predicted_label_id"]) == int(source["label_id"])
        for seed, prediction in seed_rows.items():
            row[f"seed_{seed}_predicted_label"] = prediction["predicted_label"]
            row[f"seed_{seed}_predicted_label_id"] = int(prediction["predicted_label_id"])
            row[f"seed_{seed}_machine_probability"] = probability(prediction)
            row[f"seed_{seed}_selected_indices"] = prediction["selected_token_indices"]
        output.append(row)
    selection = {
        str(context): {"seed": seed, "checkpoint": str(run_dir.relative_to(REPO_ROOT) / "model.pt")}
        for context, (seed, run_dir) in selected.items()
    }
    return output, selection


def write_flat_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        for row in rows:
            writer.writerow({key: json.dumps(value, ensure_ascii=False) if isinstance(value, (list, dict)) else value for key, value in row.items()})


def highlighted_rationale(row: dict[str, Any]) -> str:
    selected = set(row["selected_token_indices"])
    visible_tokens = tokenize(row["visible_text_512"])
    return " ".join(f"**{token}**" if index in selected else token for index, token in enumerate(visible_tokens))


def selected_ratio(row: dict[str, Any], vocabulary: set[str]) -> float:
    selected = row["selected_tokens"]
    return sum(token in vocabulary for token in selected) / max(1, len(selected))


def capitalized_selected_ratio(row: dict[str, Any]) -> float:
    matches = list(TOKEN_RE.finditer(row["visible_text_512"]))
    selected = row["selected_token_indices"]
    return sum(index < len(matches) and matches[index].group(0)[:1].isupper() for index in selected) / max(1, len(selected))


def quoted_selected_ratio(row: dict[str, Any]) -> float:
    text = row["visible_text_512"]
    matches = list(TOKEN_RE.finditer(text))
    quote_ranges = [(match.start(), match.end()) for match in re.finditer(r'"[^"\n]+"', text)]
    selected = row["selected_token_indices"]
    inside = 0
    for index in selected:
        if index < len(matches) and any(start <= matches[index].start() < end for start, end in quote_ranges):
            inside += 1
    return inside / max(1, len(selected))


def stratified_take(rows: list[dict[str, Any]], group_field: str, count: int) -> list[dict[str, Any]]:
    groups: dict[str, list[dict[str, Any]]] = {}
    for row in rows:
        groups.setdefault(str(row[group_field]), []).append(row)
    selected = []
    offset = 0
    while len(selected) < count:
        added = False
        for group in sorted(groups):
            if offset < len(groups[group]):
                selected.append(groups[group][offset])
                added = True
                if len(selected) == count:
                    break
        if not added:
            break
        offset += 1
    return selected


def qualitative_report(rows: list[dict[str, Any]]) -> None:
    false_positives = sorted((row for row in rows if row["label_id"] == 0 and not row["correct_512"]), key=lambda row: row["machine_probability_512"], reverse=True)[:10]
    false_negatives = sorted((row for row in rows if row["label_id"] == 1 and not row["correct_512"]), key=lambda row: row["machine_probability_512"])[:10]
    correct = [row for row in rows if row["correct_512"]]
    low_confidence = sorted(correct, key=lambda row: abs(row["machine_probability_512"] - 0.5))[:10]
    confident_human = stratified_take(
        sorted((row for row in correct if row["label_id"] == 0), key=lambda row: row["machine_probability_512"]),
        "domain",
        10,
    )
    confident_machine = stratified_take(
        sorted((row for row in correct if row["label_id"] == 1), key=lambda row: row["machine_probability_512"], reverse=True),
        "generator",
        10,
    )
    changed = [row for row in rows if row["label_changes_across_contexts"]][:10]
    corrected = [row for row in rows if not row["correct_256"] and row["correct_512"]][:10]
    broken = [row for row in rows if row["correct_256"] and not row["correct_512"]][:10]
    corrected_with_late_evidence = sorted(
        (row for row in rows if not row["correct_256"] and row["correct_512"] and row["selected_indices_after_256"]),
        key=lambda row: row["rationale_proportion_after_256"],
        reverse=True,
    )
    late_by_share = sorted((row for row in rows if row["selected_indices_after_256"]), key=lambda row: row["rationale_proportion_after_256"], reverse=True)
    after_256 = (corrected_with_late_evidence + [row for row in late_by_share if row not in corrected_with_late_evidence])[:10]
    stable_low = sorted((row for row in rows if row["all_seeds_agree_label"] and row["mean_pairwise_seed_jaccard"] is not None), key=lambda row: row["mean_pairwise_seed_jaccard"])[:10]
    stable_high = sorted((row for row in rows if row["all_seeds_agree_label"] and row["mean_pairwise_seed_jaccard"] is not None), key=lambda row: row["mean_pairwise_seed_jaccard"], reverse=True)[:10]
    seed_disagreement = [row for row in rows if not row["all_seeds_agree_label"]][:10]
    repeated = sorted(rows, key=lambda row: 1.0 - len(set(row["selected_tokens"])) / max(1, len(row["selected_tokens"])), reverse=True)[:10]
    stopword = sorted(rows, key=lambda row: selected_ratio(row, STOP_WORDS), reverse=True)[:10]
    names = sorted(rows, key=capitalized_selected_ratio, reverse=True)[:10]
    quoted = [row for row in sorted(rows, key=quoted_selected_ratio, reverse=True) if quoted_selected_ratio(row) > 0][:10]
    formatting = [row for row in sorted(rows, key=lambda row: row["visible_text_512"].count("\n"), reverse=True) if row["visible_text_512"].count("\n") > 0][:10]
    boilerplate = sorted(rows, key=lambda row: selected_ratio(row, BOILERPLATE_PROXY), reverse=True)[:10]
    categories = [
        ("Highest-confidence false positives", false_positives),
        ("Highest-confidence false negatives", false_negatives),
        ("Lowest-confidence correct predictions", low_confidence),
        ("Confident correct human predictions", confident_human),
        ("Confident correct machine predictions", confident_machine),
        ("Label changes across 128/256/512", changed),
        ("Corrected from 256 to 512", corrected),
        ("Broken from 256 to 512", broken),
        ("Candidates where selected evidence after position 256 may matter", after_256),
        ("Seeds agree on label but have low index overlap", stable_low),
        ("Seeds agree on label and have high index overlap", stable_high),
        ("Seeds disagree on the predicted label", seed_disagreement),
        ("Mechanical candidates: formatting-heavy visible text", formatting),
        ("Mechanical candidates: repeated selected words", repeated),
        ("Mechanical candidates: stop-word-heavy rationale", stopword),
        ("Mechanical candidates: capitalized/name-like selected tokens", names),
        ("Mechanical candidates: selected tokens inside double-quoted text", quoted),
        ("Mechanical candidates: domain-boilerplate proxy terms", boilerplate),
    ]
    lines = [
        "# Qualitative error-analysis material",
        "",
        "Examples are selected by explicit numerical rules. No behavioural explanation is generated automatically. Bold tokens are the validation-selected 512-token HardKuma rationale. Manual interpretation fields are intentionally blank.",
        "",
        "The word tokenizer excludes punctuation, so a punctuation-dominated selected rationale is structurally impossible for this model. Shortcut-category candidates below use mechanical surface rules (newlines, token repetition, a fixed stop-word list, capitalization, double-quote spans, or a fixed boilerplate proxy list). They are retrieval aids, not explanations and require manual inspection.",
        "",
    ]
    for title, examples in categories:
        lines.extend([f"## {title}", ""])
        if not examples:
            lines.extend(["No matching test examples.", ""])
            continue
        for index, row in enumerate(examples, 1):
            lines.extend(
                [
                    f"### {index}. `{row['id']}`",
                    "",
                    f"- Source ID: `{row['source_id']}`",
                    f"- Domain / generator: {row['domain']} / {row['generator']}",
                    f"- True / predicted: {row['true_label']} / {row['predicted_label_512']} (P(machine)={row['machine_probability_512']:.4f})",
                    f"- Original / visible length: {row['original_token_count']} / {row['visible_token_count_512']}",
                    f"- Context predictions 128/256/512: {row['predicted_label_128']} ({row['machine_probability_128']:.4f}) / {row['predicted_label_256']} ({row['machine_probability_256']:.4f}) / {row['predicted_label_512']} ({row['machine_probability_512']:.4f})",
                    f"- All 512 seeds agree: {row['all_seeds_agree_label']}; mean seed Jaccard: {row['mean_pairwise_seed_jaccard']}",
                    f"- Selected indices: `{row['selected_token_indices']}`",
                    "",
                    "Visible text (original formatting):",
                    "",
                    "\n".join(f"> {line}" for line in row["visible_text_512"].splitlines()),
                    "",
                    "Tokenized text with selected rationale in bold:",
                    "",
                    highlighted_rationale(row),
                    "",
                    "Manual notes:",
                    "",
                    "- Likely reason for prediction:",
                    "- Whether the rationale supports the prediction:",
                    "- Possible shortcut:",
                    "- Whether truncation matters:",
                    "- Include in human study:",
                    "",
                ]
            )
    lines.extend(
        [
            "## Manual shortcut-review headings",
            "",
            "Punctuation-dominated rationale: not applicable because punctuation is excluded by the selector tokenizer. All behavioural interpretation fields above remain unfilled to avoid inventing explanations.",
            "",
        ]
    )
    (DOC_ROOT / "qualitative_errors.md").write_text("\n".join(lines), encoding="utf-8")


def field_description(field: str) -> str:
    exact = {
        "id": "RAID dataset row identifier.",
        "source_id": "RAID source-document identifier.",
        "domain": "RAID domain label.",
        "generator": "Machine generator, or human for human-written rows.",
        "true_label": "Human-readable gold label.",
        "label_id": "Gold label ID: 0 human, 1 machine.",
        "attack": "Original RAID attack field; current benchmark is none.",
        "decoding": "Generator decoding method when available.",
        "original_text": "Complete original test text before model truncation.",
        "original_token_count": "Number of model word tokens before truncation.",
        "label_changes_across_contexts": "Whether selected 128/256/512 checkpoints produce more than one label.",
        "probability_change_128_to_256": "P(machine, 256) minus P(machine, 128).",
        "probability_change_256_to_512": "P(machine, 512) minus P(machine, 256).",
        "selected_tokens": "Validation-selected 512 model's rationale tokens in original order.",
        "selected_token_indices": "Zero-based indices of selected model tokens.",
        "selected_token_scores": "Deterministic HardKuma gate values at selected indices.",
        "rationale_length": "Number of deterministically selected tokens.",
        "rationale_fraction": "Selected count divided by visible valid-token count.",
        "selected_indices_after_128": "Selected zero-based indices at or beyond 128.",
        "selected_tokens_after_128": "Selected tokens at or beyond position 128.",
        "selected_indices_after_256": "Selected zero-based indices at or beyond 256.",
        "selected_tokens_after_256": "Selected tokens at or beyond position 256.",
        "rationale_proportion_after_256": "Fraction of selected indices at or beyond 256.",
        "zero_selection_fallback": "Whether empty-selection fallback was used.",
        "analytical_expected_gate_rate": "Mean analytical P(HardKuma gate non-zero) over real visible tokens; distinct from top-k.",
        "deterministic_selection_rate": "Actual deterministic top-k selected fraction.",
        "all_seeds_agree_label": "Whether 512-token seeds 42/43/44 predict the same label.",
        "mean_pairwise_seed_jaccard": "Mean pairwise token-index Jaccard across 512 seeds; lexical, not semantic.",
    }
    if field in exact:
        return exact[field]
    for context in (128, 256, 512):
        if field == f"visible_text_{context}":
            return f"Original characters through the end of model token {context}, or full text when shorter."
        if field == f"visible_token_count_{context}":
            return f"Number of tokens visible under the {context}-token limit."
        if field == f"visible_fraction_{context}":
            return f"Fraction of original model tokens visible under the {context}-token limit."
        if field == f"exceeds_{context}":
            return f"Whether original token count exceeds {context}."
        if field == f"selected_checkpoint_seed_{context}":
            return f"Validation-selected seed used for the {context}-token context prediction."
        if field == f"predicted_label_{context}":
            return f"Human-readable prediction from the selected {context}-token HardKuma checkpoint."
        if field == f"predicted_label_id_{context}":
            return f"Prediction ID from the selected {context}-token checkpoint."
        if field == f"machine_probability_{context}":
            return f"Machine probability from the selected {context}-token checkpoint."
        if field == f"correct_{context}":
            return f"Whether the selected {context}-token prediction equals the gold label."
    match = re.fullmatch(r"seed_(42|43|44)_(.+)", field)
    if match:
        suffix = match.group(2)
        descriptions = {
            "predicted_label": "human-readable predicted label",
            "predicted_label_id": "predicted label ID",
            "machine_probability": "machine probability",
            "selected_indices": "zero-based selected token indices",
        }
        return f"512-token HardKuma seed {match.group(1)} {descriptions[suffix]}."
    raise KeyError(f"No data-dictionary description for {field}")


def data_dictionary(example: dict[str, Any]) -> None:
    lines = [
        "# Final test-export data dictionary",
        "",
        "The machine-readable export is `outputs/archive/pre_surface_final_analysis/test_predictions.jsonl`; the CSV is a flat equivalent whose list values are JSON strings. Context predictions come from the highest-validation-F1 predefined seed at each context length; the checkpoint manifest records the paths.",
        "",
        "| Field | JSON type | Description |",
        "|---|---|---|",
    ]
    for field, value in example.items():
        json_type = "null" if value is None else "array" if isinstance(value, list) else "boolean" if isinstance(value, bool) else "number" if isinstance(value, (int, float)) else "string"
        lines.append(f"| `{field}` | {json_type} | {field_description(field)} |")
    lines.append("")
    (DOC_ROOT / "data_dictionary.md").write_text("\n".join(lines), encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser(description="Build the unified RAID v3 test export and qualitative material.")
    parser.parse_args()
    rows, selection = export_rows()
    write_jsonl(OUTPUT_ROOT / "test_predictions.jsonl", rows)
    write_flat_csv(OUTPUT_ROOT / "test_predictions.csv", rows)
    (OUTPUT_ROOT / "prediction_export_manifest.json").write_text(json.dumps({"rows": len(rows), "validation_selected_checkpoints": selection}, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    qualitative_report(rows)
    data_dictionary(rows[0])
    print(f"Exported {len(rows)} test examples; checkpoint seeds: {selection}")


if __name__ == "__main__":
    main()
