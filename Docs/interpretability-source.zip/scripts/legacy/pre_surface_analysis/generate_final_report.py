from __future__ import annotations

import csv
import json
import statistics
import sys
from pathlib import Path
from typing import Any

REPO_ROOT = Path(__file__).resolve().parents[2]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from scripts.legacy.pre_surface_analysis.common import read_json, write_json


OUTPUT_ROOT = REPO_ROOT / "outputs/archive/pre_surface_final_analysis"
DOC_ROOT = REPO_ROOT / "docs/archive/pre_surface_final_analysis"


def fmt(value: float | None, digits: int = 4) -> str:
    return "undefined" if value is None else f"{value:.{digits}f}"


def require(path: Path) -> Path:
    if not path.exists():
        raise FileNotFoundError(f"Required final-analysis artifact is missing: {path}")
    return path


def context_section(rows: list[dict[str, Any]]) -> list[str]:
    lines = [
        "## Context-length comparison",
        "",
        "All values below are mean ± sample standard deviation across predefined seeds 42/43/44. Metrics were independently recalculated from saved per-example predictions.",
        "",
        "| Model | Context | Budget | Val F1 | Test precision | Test recall | Test F1 | AUROC | Mean selected |",
        "|---|---:|---|---:|---:|---:|---:|---:|---:|",
    ]
    for row in rows:
        lines.append(
            f"| {row['model']} | {row['visible_context_tokens']} | {row['selected_token_budget']} | "
            f"{fmt(row['validation_f1_mean'])} ± {fmt(row['validation_f1_sd'])} | "
            f"{fmt(row['test_precision_mean'])} ± {fmt(row['test_precision_sd'])} | "
            f"{fmt(row['test_recall_mean'])} ± {fmt(row['test_recall_sd'])} | "
            f"{fmt(row['test_f1_mean'])} ± {fmt(row['test_f1_sd'])} | "
            f"{fmt(row['test_auroc_mean'])} ± {fmt(row['test_auroc_sd'])} | {row['actual_selected_tokens_mean']:.2f} |"
        )
    def find(model: str, context: int, budget: str) -> dict[str, Any]:
        return next(row for row in rows if row["model"] == model and row["visible_context_tokens"] == context and row["selected_token_budget"] == budget)

    hard_256 = find("HardKuma BiLSTM", 256, "40%")
    hard_512 = find("HardKuma BiLSTM", 512, "40%")
    fixed_512 = find("HardKuma BiLSTM", 512, "102 tokens")
    full_256 = find("Full-context BiLSTM", 256, "all")
    full_512 = find("Full-context BiLSTM", 512, "all")
    lines.extend(
        [
            "",
            "Measured separations:",
            "",
            f"- Seeing more input while retaining the same 40% proportional rule (256→512) changes mean validation F1 by {hard_512['validation_f1_mean'] - hard_256['validation_f1_mean']:+.4f} and mean test F1 by {hard_512['test_f1_mean'] - hard_256['test_f1_mean']:+.4f}.",
            f"- At the same 512-token visible context, proportional 40% versus fixed 102 changes mean validation F1 by {hard_512['validation_f1_mean'] - fixed_512['validation_f1_mean']:+.4f} and mean test F1 by {hard_512['test_f1_mean'] - fixed_512['test_f1_mean']:+.4f}; this isolates the larger selected budget more directly.",
            f"- For full-context BiLSTM, 256→512 changes mean validation F1 by {full_512['validation_f1_mean'] - full_256['validation_f1_mean']:+.4f} and mean test F1 by {full_512['test_f1_mean'] - full_256['test_f1_mean']:+.4f}.",
            "",
            "The fixed-102 row is a deterministic count diagnostic: 102/512 is 19.92% only for a full window. Its per-document fraction is higher for shorter texts.",
            "",
        ]
    )
    return lines


def paired_section(paired: dict[str, Any]) -> list[str]:
    lines = [
        "## Paired statistical comparisons",
        "",
        "Differences are F1(B) − F1(A), using 10,000 paired bootstrap resamples (seed 20260805). McNemar p-values are exact and two-sided.",
        "",
        "| A → B | F1 difference | 95% CI | Exact p | B corrects A | B breaks A |",
        "|---|---:|---:|---:|---:|---:|",
    ]
    for values in paired.values():
        bootstrap = values["paired_bootstrap"]
        mcnemar = values["mcnemar"]
        lines.append(
            f"| {values['model_a']} → {values['model_b']} | {fmt(bootstrap['observed_difference'])} | "
            f"[{fmt(bootstrap['confidence_interval_95'][0])}, {fmt(bootstrap['confidence_interval_95'][1])}] | "
            f"{mcnemar['exact_two_sided_p_value']:.3g} | {mcnemar['b_only_correct_b_corrects_a']} | "
            f"{mcnemar['a_only_correct_b_newly_broken']} |"
        )
    lines.extend(["", "A non-significant comparison does not establish equivalence. These paired rows use the audit's validation-selected single checkpoints; seed-mean context trends are reported separately above.", ""])
    return lines


def controls_section(aggregate: dict[str, Any], run_summaries: list[dict[str, Any]]) -> list[str]:
    lines = [
        "## Rationale controls and post-hoc ranking diagnostics",
        "",
        "Controls use the same frozen predictor and matched rationale lengths. Random is the per-example mean across fixed masks; no best random draw is selected.",
        "",
        "| 40% evidence | Test F1 | AUROC | Correct examples |",
        "|---|---:|---:|---:|",
    ]
    for strategy in ("learned", "random_mean_probability", "first", "last"):
        values = aggregate["controls_40_percent"][strategy]
        lines.append(
            f"| {strategy} | {fmt(values['machine_f1_mean'])} ± {fmt(values['machine_f1_sd'])} | "
            f"{fmt(values['auroc_mean'])} ± {fmt(values['auroc_sd'])} | "
            f"{values['correct_examples_mean']:.1f} ± {values['correct_examples_sd']:.1f} |"
        )
    lines.extend(["", "Retention budgets other than 40% and every deletion point are evaluation-only diagnostics of the frozen 40%-trained ranking; they are not separately trained rationale systems.", ""])
    lines.extend(["| Retained | Learned F1 | Random F1 | First F1 | Last F1 |", "|---:|---:|---:|---:|---:|"])
    for fraction in (0.10, 0.20, 0.30, 0.40, 0.50, 1.00):
        key = f"{fraction:.2f}"
        means = {
            strategy: statistics.mean(run["retention"][key][strategy]["machine_f1"] for run in run_summaries)
            for strategy in ("learned", "random_mean_probability", "first", "last")
        }
        lines.append(f"| {fraction:.0%} | {fmt(means['learned'])} | {fmt(means['random_mean_probability'])} | {fmt(means['first'])} | {fmt(means['last'])} |")
    lines.extend(["", "| Deleted | Learned-ranked deletion F1 | Random deletion F1 |", "|---:|---:|---:|"])
    for fraction in (0.10, 0.20, 0.30, 0.40, 0.50):
        key = f"{fraction:.2f}"
        learned = statistics.mean(run["deletion"][key]["learned"]["machine_f1"] for run in run_summaries)
        random_value = statistics.mean(run["deletion"][key]["random_mean_probability"]["machine_f1"] for run in run_summaries)
        lines.append(f"| {fraction:.0%} | {fmt(learned)} | {fmt(random_value)} |")
    lines.append("")
    return lines


def calibration_section(calibration: dict[str, Any]) -> list[str]:
    lines = [
        "## Calibration and validation-chosen operating points",
        "",
        "ECE/MCE use 10 equal-width machine-probability bins. Operating thresholds are selected only from validation human examples and applied once to test.",
        "",
        "| Model | Brier | NLL | ECE | MCE | Test recall @ ~1% FPR | Achieved FPR | Test recall @ ~5% FPR | Achieved FPR |",
        "|---|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for model, values in calibration.items():
        metric = values["test_calibration"]
        one, five = values["operating_points"]
        lines.append(
            f"| {model} | {fmt(metric['brier_score'])} | {fmt(metric['negative_log_likelihood'])} | "
            f"{fmt(metric['expected_calibration_error'])} | {fmt(metric['maximum_calibration_error'])} | "
            f"{fmt(one['test_machine_recall'])} (t={one['threshold']:.4f}) | {fmt(one['test_achieved_fpr'])} | "
            f"{fmt(five['test_machine_recall'])} (t={five['threshold']:.4f}) | {fmt(five['test_achieved_fpr'])} |"
        )
    lines.append("")
    return lines


def chunking_section(chunking: dict[str, Any]) -> list[str]:
    lines = [
        "## Exploratory document-chunking pilot",
        "",
        "Frozen 256-token checkpoints classify every non-overlapping chunk, including the final short chunk. This is exploratory because the models were trained on prefixes, not later chunks or document aggregation.",
        "",
        "| Model | Aggregation | F1 | AUROC | Corrected vs first | Broken vs first |",
        "|---|---|---:|---:|---:|---:|",
    ]
    for model, values in chunking["models"].items():
        for method in ("first_256", "mean", "maximum"):
            metric = values[method]
            lines.append(
                f"| {model} | {method} | {fmt(metric['machine_f1'])} | {fmt(metric['auroc'])} | "
                f"{metric.get('corrected_vs_first', 0)} | {metric.get('broken_vs_first', 0)} |"
            )
    lines.append("")
    return lines


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def write_diagnostic_csvs(run_summaries: list[dict[str, Any]], fixed_summaries: list[dict[str, Any]]) -> None:
    controls = []
    retention = []
    deletion = []
    controllers = []
    for run in run_summaries:
        for strategy in ("learned", "random_mean_probability", "first", "last"):
            values = run["controls_40_percent"][strategy]
            controls.append(
                {
                    "run": run["run"],
                    "strategy": strategy,
                    **{key: values[key] for key in ("machine_precision", "machine_recall", "machine_f1", "auroc", "mean_predicted_class_probability", "mean_true_class_probability", "correct_examples")},
                }
            )
        for fraction, strategies in run["retention"].items():
            for strategy in ("learned", "random_mean_probability", "first", "last"):
                values = strategies[strategy]
                retention.append(
                    {
                        "run": run["run"],
                        "retained_fraction": fraction,
                        "strategy": strategy,
                        "machine_f1": values["machine_f1"],
                        "auroc": values["auroc"],
                        "mean_predicted_class_probability": values["mean_predicted_class_probability"],
                        "mean_true_class_probability": values["mean_true_class_probability"],
                        "average_selected_tokens": strategies["average_selected_tokens"],
                    }
                )
        for fraction, strategies in run["deletion"].items():
            for strategy in ("learned", "random_mean_probability"):
                values = strategies[strategy]
                deletion.append(
                    {
                        "run": run["run"],
                        "deleted_fraction": fraction,
                        "strategy": strategy,
                        **{key: values[key] for key in ("machine_f1", "auroc", "mean_change_in_full_predicted_class_probability", "mean_change_in_true_class_probability", "label_flip_rate")},
                    }
                )
        controller = run["controller"]
        controllers.append(
            {
                "run": run["run"],
                "mechanism": "proportional_40_topk",
                "target_or_nominal_fraction": controller["nominal_target_rate"],
                "expected_rate": controller["analytical_expected_nonzero_rate"]["mean"],
                "deterministic_rate": controller["deterministic_topk_rate"]["mean"],
                "raw_gate_rate": controller["raw_deterministic_gate"]["average_selection_rate"],
                "zero_fallbacks": controller["zero_selection_fallback_count"],
                "test_f1": controller["test_f1"],
                "test_auroc": controller["test_auroc"],
            }
        )
    for run in fixed_summaries:
        controllers.append(
            {
                "run": run["run"],
                "mechanism": "fixed_102_topk",
                "target_or_nominal_fraction": run["nominal_full_window_fraction"],
                "expected_rate": run["analytical_expected_nonzero_rate_mean"],
                "deterministic_rate": run["actual_deterministic_selected_fraction_mean"],
                "raw_gate_rate": run["raw_deterministic_gate"]["average_selection_rate"],
                "zero_fallbacks": run["zero_selection_fallback_count"],
                "test_f1": run["topk_metrics"]["machine_f1"],
                "test_auroc": run["topk_metrics"]["auroc"],
            }
        )
    write_csv(OUTPUT_ROOT / "rationale_controls.csv", controls)
    write_csv(OUTPUT_ROOT / "retention_diagnostics.csv", retention)
    write_csv(OUTPUT_ROOT / "deletion_diagnostics.csv", deletion)
    write_csv(OUTPUT_ROOT / "controller_diagnostics.csv", controllers)


def main() -> None:
    context = read_json(require(OUTPUT_ROOT / "context_comparison.json"))
    if len(context) != 11:
        raise ValueError(f"Expected 11 complete context rows, found {len(context)}")
    subgroups = read_json(require(OUTPUT_ROOT / "subgroup_metrics.json"))
    paired = read_json(require(OUTPUT_ROOT / "paired_statistics.json"))
    stability = read_json(require(OUTPUT_ROOT / "rationale_stability.json"))
    calibration = read_json(require(OUTPUT_ROOT / "calibration.json"))
    controls = read_json(require(OUTPUT_ROOT / "hardkuma_diagnostics/aggregate.json"))
    run_summaries = [read_json(require(OUTPUT_ROOT / f"hardkuma_diagnostics/kuma_corrected_t40_len512_ratefix_s{seed}.json")) for seed in (42, 43, 44)]
    fixed_controller = read_json(require(OUTPUT_ROOT / "hardkuma_diagnostics/fixed102_controller_aggregate.json"))
    fixed_summaries = [read_json(require(OUTPUT_ROOT / f"hardkuma_diagnostics/kuma_corrected_fixed102_len512_ratefix_s{seed}_controller.json")) for seed in (42, 43, 44)]
    chunking = read_json(require(OUTPUT_ROOT / "chunking_pilot/summary.json"))
    len128 = read_json(require(OUTPUT_ROOT / "len128_run_manifest.json"))
    prediction_manifest = read_json(require(OUTPUT_ROOT / "prediction_export_manifest.json"))
    write_diagnostic_csvs(run_summaries, fixed_summaries)

    lines = [
        "# Final corrected RAID v3 rationale-analysis report",
        "",
        "## Scope and audit",
        "",
        "This report uses rate-fixed, validation-selected HardKuma checkpoints at 128/256/512 tokens and reuses unaffected full-context, Transformer, and TF-IDF predictions. No Transformer, TF-IDF, full-context, adversarial-attack, or held-out-generator model was rerun.",
        "",
        "The main rationale family is HardKuma BiLSTM with up to 512 visible tokens and deterministic proportional top-k selection at 40%. Seed-level results use all predefined seeds; single-checkpoint qualitative/paired analyses use validation F1 only, as recorded in `audit.md` and the prediction manifest.",
        "",
    ]
    lines.extend(context_section(context))
    lines.extend(
        [
            "## Domain, generator, and length findings",
            "",
            "Complete support, confusion matrices, human false-positive rates, generator-vs-human AUROC, and length buckets are in `outputs/archive/pre_surface_final_analysis/subgroup_metrics.json` and `.csv`.",
            "Generator recall cells contain 100 machine examples each (with generator-vs-human AUROC using all 600 human examples). The >512 length bucket has only 78 total examples and is explicitly treated as small-support evidence.",
            "",
            "| Model | Abstracts F1 | Books F1 | News F1 | Poetry F1 |",
            "|---|---:|---:|---:|---:|",
        ]
    )
    for model, values in subgroups.items():
        lines.append(
            f"| {model} | " + " | ".join(fmt(values["by_domain"][domain]["machine_f1"]) for domain in ("abstracts", "books", "news", "poetry")) + " |"
        )
    lines.append("")
    lines.extend(paired_section(paired))
    lines.extend(
        [
            "## Rationale stability across seeds",
            "",
            f"Label agreement is {stability['label_agreement_rate']:.2%}. Mean pairwise token-index Jaccard is {stability['jaccard']['mean']:.4f} (median {stability['jaccard']['median']:.4f}); mean probability SD is {stability['probability_standard_deviation']['mean']:.4f}. These are lexical/index-level stability measures and do not establish semantic equivalence.",
            "",
        ]
    )
    lines.extend(controls_section(controls, run_summaries))
    proportional_expected = statistics.mean(run["controller"]["analytical_expected_nonzero_rate"]["mean"] for run in run_summaries)
    proportional_topk = statistics.mean(run["controller"]["deterministic_topk_rate"]["mean"] for run in run_summaries)
    raw_rate = statistics.mean(run["controller"]["raw_deterministic_gate"]["average_selection_rate"] for run in run_summaries)
    raw_f1 = statistics.mean(run["controller"]["raw_deterministic_gate"]["machine_f1"] for run in run_summaries)
    raw_zero = sum(run["controller"]["raw_deterministic_gate"]["zero_selection_count"] for run in run_summaries)
    lines.extend(
        [
            "## HardKuma controller diagnostics",
            "",
            "The proportional runs report analytical non-zero probability, deterministic top-k rate, and raw ≥0.5 gate decisions separately in `outputs/archive/pre_surface_final_analysis/hardkuma_diagnostics`. These mechanisms are not interchangeable.",
            "",
            f"Across the three proportional-40% runs, mean analytical expected rate is {proportional_expected:.4f}, deterministic top-k rate is {proportional_topk:.4f}, and raw ≥0.5 gate rate is {raw_rate:.4f}. Raw-gate mean test F1 is {raw_f1:.4f}, with {raw_zero} zero-selection examples across the three seed evaluations and no fallback imposed in that diagnostic.",
            "",
            f"For fixed-102, the across-seed mean selected count is {fixed_controller['actual_selected_count_mean']:.2f}, mean per-document deterministic fraction is {fixed_controller['actual_selected_fraction_mean']:.4f}, and mean analytical expected rate is {fixed_controller['analytical_expected_rate_mean']:.4f}. The nominal full-window fraction is {fixed_controller['nominal_full_window_fraction']:.4f}.",
            "",
        ]
    )
    lines.extend(calibration_section(calibration))
    lines.extend(chunking_section(chunking))
    lines.extend(
        [
            "## Qualitative material and reproducibility",
            "",
            f"The unified export contains {prediction_manifest['rows']} test examples with complete text visibility, context predictions, rationale scores, and all three 512-token seeds. `qualitative_errors.md` provides numerically selected cases and intentionally blank manual-interpretation fields.",
            "",
            "Exact commands, environment versions, the export dictionary, bugs, future robustness plan, plots, and machine-readable tables are stored beside this report. The six new 128-token run records—including derived wall-clock bounds and exact checkpoint paths—are in `outputs/archive/pre_surface_final_analysis/len128_run_manifest.json`.",
            "",
            "## Interpretation",
            "",
            "Context and evidence-budget effects are separated by comparing 256→512 proportional-40%, 512 fixed-102, and matched full-context models. One plausible explanation is that longer prefixes expose additional useful cues, while proportional selection also grants a larger evidence budget; the fixed-102 comparison is consistent with both contributing. This is an interpretation, not a demonstrated linguistic mechanism. The per-seed means and paired validation-selected checkpoint comparisons answer different questions and are both retained.",
            "",
            "## Limitations",
            "",
            "- HardKuma analytical rate control and deterministic top-k inference are distinct; fixed-102 misses its nominal analytical target.",
            "- The final predictor depends on top-k ranking, and post-hoc budgets are not separately trained models.",
            "- Results are in-distribution with `attack = none`; no attack robustness or unseen-generator generalisation is established.",
            "- Rationale overlap is lexical/index-level, not a semantic stability measure.",
            "- Chunking is exploratory and applies prefix-trained models to later chunks.",
            "- Truncation and MPS/CPU floating-point differences can affect thresholded decisions; scientific runs are treated as independent seeded runs, not bitwise device reproductions.",
            "",
            "## Safe use",
            "",
            "Only rate-fixed 128/256/512 HardKuma outputs, unaffected full-context/TF-IDF results, and corrected Transformer results are safe to report with their stated scopes. Controller-bug-window HardKuma outputs, original sign-bugged rationale Transformer runs, and pre-correction padded-BiLSTM runs remain excluded. Post-hoc retention/deletion and chunking results must be labelled diagnostic/exploratory. Attack and held-out-generator claims require future experiments.",
            "",
        ]
    )
    report_path = DOC_ROOT / "technical_report.md"
    report_path.write_text("\n".join(lines), encoding="utf-8")
    summary = {
        "context_comparison": context,
        "paired_statistics": paired,
        "stability_summary": {key: stability[key] for key in ("support", "label_agreement_rate", "jaccard", "probability_standard_deviation")},
        "rationale_controls": controls,
        "fixed102_controller": fixed_controller,
        "calibration": calibration,
        "chunking_summary": chunking,
        "len128_runs": len128,
        "prediction_export_manifest": prediction_manifest,
        "scope": {"attacks_run": False, "held_out_generator_training_run": False, "new_transformer_sweep_run": False},
    }
    write_json(DOC_ROOT / "summary.json", summary)
    print(f"Wrote {report_path} and {DOC_ROOT / 'summary.json'}")


if __name__ == "__main__":
    main()
