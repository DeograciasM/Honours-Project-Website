from __future__ import annotations

import argparse
import statistics
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

import torch

REPO_ROOT = Path(__file__).resolve().parents[2]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from detectgpt.data.io import load_dataset_splits
from detectgpt.utils.device import DEVICE_CHOICES, resolve_device
from scripts.evaluate_rationale_strategies import load_model
from scripts.legacy.pre_surface_analysis.common import binary_metrics, probability, read_json, read_jsonl, write_json
from scripts.train_kuma_rationale import TokenDataset, make_loader


def independent_metrics(run_dir: Path, split: str) -> dict[str, Any]:
    rows = read_jsonl(run_dir / f"{split}_predictions.jsonl")
    return binary_metrics(
        [int(row["label_id"]) for row in rows],
        [int(row["predicted_label_id"]) for row in rows],
        [probability(row) for row in rows],
    )


def derived_times(run_dir: Path, runtime: float) -> dict[str, Any]:
    # Trainers record monotonic elapsed seconds but legacy-compatible configs
    # do not contain wall-clock timestamps. The metrics-file mtime is the best
    # non-destructive end-time record; label it explicitly as derived.
    end = datetime.fromtimestamp((run_dir / "metrics.json").stat().st_mtime, tz=timezone.utc)
    start = end - timedelta(seconds=runtime)
    return {
        "started_at_utc_derived": start.isoformat(),
        "ended_at_utc_derived": end.isoformat(),
        "timestamp_derivation": "metrics.json mtime minus/plus recorded training_time_seconds",
    }


def hardkuma_expected_rates(run_dir: Path, device: torch.device, batch_size: int) -> list[float]:
    model, vocab, config = load_model(run_dir, device)
    rows = load_dataset_splits(Path(config["data_dir"]), ("test",))["test"]
    loader = make_loader(TokenDataset(rows, vocab, 128), batch_size, False, int(config["seed"]), vocab.pad_id)
    rates = []
    with torch.no_grad():
        for batch in loader:
            input_ids = batch["input_ids"].to(device)
            mask = batch["mask"].to(device)
            embeddings = model.embed_tokens(input_ids)
            a, b = model.gate_parameters(embeddings, mask)
            expected = model.expected_selection(a, b, mask)
            for local in range(expected.shape[0]):
                valid_count = int(mask[local].sum().item())
                rates.append(float(expected[local, :valid_count].mean().item()))
    return rates


def build(device: torch.device, batch_size: int) -> dict[str, Any]:
    output: dict[str, Any] = {"device_used_for_posthoc_expected_rates": str(device), "runs": []}
    for family in ("hardkuma", "full_context"):
        for seed in (42, 43, 44):
            run_dir = (
                REPO_ROOT / f"outputs/rationales/kuma_corrected_t40_len128_ratefix_s{seed}"
                if family == "hardkuma"
                else REPO_ROOT / f"outputs/full_context_bilstm/len128_s{seed}"
            )
            metrics = read_json(run_dir / "metrics.json")
            config = read_json(run_dir / "config.json")
            runtime = float(metrics["training_time_seconds"])
            row: dict[str, Any] = {
                "family": family,
                "seed": seed,
                "run_dir": str(run_dir.relative_to(REPO_ROOT)),
                "checkpoint_path": str((run_dir / "model.pt").relative_to(REPO_ROOT)),
                "device": config["device"],
                "runtime_seconds": runtime,
                "best_epoch": int(metrics["best_epoch"]),
                "best_validation_f1": float(metrics["best_val_f1"]),
                "validation": independent_metrics(run_dir, "validation"),
                "test": independent_metrics(run_dir, "test"),
                **derived_times(run_dir, runtime),
            }
            if family == "hardkuma":
                expected_rates = hardkuma_expected_rates(run_dir, device, batch_size)
                prediction_rows = read_jsonl(run_dir / "test_predictions.jsonl")
                deterministic_rates = [float(value["selected_fraction"]) for value in prediction_rows]
                selected_counts = [len(value["selected_token_indices"]) for value in prediction_rows]
                row.update(
                    {
                        "test_analytical_expected_nonzero_rate_mean": statistics.mean(expected_rates),
                        "test_analytical_expected_nonzero_rate_sd": statistics.stdev(expected_rates),
                        "test_deterministic_selection_rate_mean": statistics.mean(deterministic_rates),
                        "expected_minus_deterministic_rate": statistics.mean(expected_rates) - statistics.mean(deterministic_rates),
                        "test_deterministic_selected_tokens_mean": statistics.mean(selected_counts),
                        "test_deterministic_selected_tokens_min": min(selected_counts),
                        "test_deterministic_selected_tokens_max": max(selected_counts),
                        "zero_selection_fallback_count": sum(bool(value["used_empty_selection_fallback"]) for value in prediction_rows),
                    }
                )
            output["runs"].append(row)
    return output


def main() -> None:
    parser = argparse.ArgumentParser(description="Build a complete non-destructive manifest for the new 128-token runs.")
    parser.add_argument("--device", default="auto", choices=DEVICE_CHOICES)
    parser.add_argument("--batch-size", default=32, type=int)
    args = parser.parse_args()
    device = resolve_device(args.device)
    output = build(device, args.batch_size)
    path = REPO_ROOT / "outputs/archive/pre_surface_final_analysis/len128_run_manifest.json"
    write_json(path, output)
    print(f"Saved {len(output['runs'])} run records to {path}")


if __name__ == "__main__":
    main()
