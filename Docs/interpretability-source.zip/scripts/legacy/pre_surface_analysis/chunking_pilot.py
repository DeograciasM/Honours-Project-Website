from __future__ import annotations

import argparse
import json
import statistics
import sys
from collections import defaultdict
from pathlib import Path
from typing import Any

import torch

REPO_ROOT = Path(__file__).resolve().parents[2]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from detectgpt.baselines.bilstm import FullContextBiLSTM
from detectgpt.data.io import load_dataset_splits
from detectgpt.rationales.vocab import Vocabulary, tokenize
from detectgpt.utils.device import DEVICE_CHOICES, resolve_device
from scripts.evaluate_rationale_strategies import load_model as load_kuma_model
from scripts.legacy.pre_surface_analysis.common import binary_metrics, length_bucket, predictions_by_id, probability, read_json, write_json, write_jsonl
from scripts.train_full_context_bilstm import evaluate as evaluate_full_context
from scripts.train_kuma_rationale import TokenDataset, evaluate_model, make_loader


OUTPUT_ROOT = REPO_ROOT / "outputs/archive/pre_surface_final_analysis/chunking_pilot"


def validation_best_run(template: str) -> tuple[int, Path]:
    candidates = []
    for seed in (42, 43, 44):
        run_dir = REPO_ROOT / template.format(seed=seed)
        metrics_path = run_dir / "metrics.json"
        if not metrics_path.exists():
            raise FileNotFoundError(metrics_path)
        validation_f1 = float(read_json(metrics_path)["validation"]["overall"]["machine_f1"])
        candidates.append((validation_f1, seed, run_dir))
    _, seed, run_dir = max(candidates)
    return seed, run_dir


def load_full_context(run_dir: Path, device: torch.device) -> tuple[FullContextBiLSTM, Vocabulary, dict[str, Any]]:
    config = read_json(run_dir / "config.json")
    vocab_payload = read_json(run_dir / "vocab.json")
    token_to_id = vocab_payload.get("token_to_id", vocab_payload)
    vocab = Vocabulary({str(token): int(index) for token, index in token_to_id.items()})
    model_config = config["model"]
    checkpoint = torch.load(run_dir / "model.pt", map_location=device, weights_only=False)
    embedding_weight = checkpoint["model_state_dict"]["embedding.weight"]
    model = FullContextBiLSTM(
        vocab_size=len(vocab),
        embed_dim=int(embedding_weight.shape[1]),
        hidden_dim=int(model_config["hidden_dim"]),
        dropout=float(model_config["dropout"]),
        padding_idx=vocab.pad_id,
    ).to(device)
    model.load_state_dict(checkpoint["model_state_dict"])
    model.eval()
    return model, vocab, config


def make_chunk_rows(rows: list[dict[str, Any]], chunk_size: int = 256) -> tuple[list[dict[str, Any]], dict[str, list[dict[str, int]]]]:
    chunks = []
    boundaries: dict[str, list[dict[str, int]]] = defaultdict(list)
    for row in rows:
        tokens = tokenize(row["text"])
        if not tokens:
            tokens = ["<unk>"]
        for chunk_index, start in enumerate(range(0, len(tokens), chunk_size)):
            end = min(start + chunk_size, len(tokens))
            chunk_id = f"{row['id']}::chunk-{chunk_index}"
            chunks.append(
                {
                    **row,
                    "id": chunk_id,
                    "parent_id": row["id"],
                    "chunk_index": chunk_index,
                    "chunk_start": start,
                    "chunk_end": end,
                    "text": " ".join(tokens[start:end]),
                }
            )
            boundaries[str(row["id"])].append({"chunk_index": chunk_index, "start": start, "end": end})
    return chunks, boundaries


def evaluate_chunks(
    device: torch.device,
    batch_size: int,
    limit_test: int | None = None,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    data_dir = REPO_ROOT / "data/processed/raid_core_en_v3"
    documents = load_dataset_splits(data_dir, ("test",))["test"]
    if limit_test is not None:
        documents = documents[:limit_test]
    chunks, boundaries = make_chunk_rows(documents)

    kuma_seed, kuma_dir = validation_best_run(
        "outputs/rationales/kuma_corrected_t40_ratefix_s{seed}"
    )
    kuma, kuma_vocab, _ = load_kuma_model(kuma_dir, device)
    kuma_loader = make_loader(TokenDataset(chunks, kuma_vocab, 256), batch_size, False, kuma_seed, kuma_vocab.pad_id)
    _, _, kuma_rows = evaluate_model(kuma, kuma_loader, device, 0.5, "topk", 0.40)
    kuma_by_id = {str(row["id"]): row for row in kuma_rows}

    full_seed, full_dir = validation_best_run(
        "outputs/full_context_bilstm/s{seed}"
    )
    full, full_vocab, _ = load_full_context(full_dir, device)
    full_loader = make_loader(TokenDataset(chunks, full_vocab, 256), batch_size, False, full_seed, full_vocab.pad_id)
    _, full_rows = evaluate_full_context(full, full_loader, device)
    full_by_id = {str(row["id"]): row for row in full_rows}
    original_predictions = {
        "hardkuma_256_t40": predictions_by_id(kuma_dir / "test_predictions.jsonl"),
        "full_context_bilstm_256": predictions_by_id(full_dir / "test_predictions.jsonl"),
    }

    output = []
    for document in documents:
        document_id = str(document["id"])
        chunk_specs = boundaries[document_id]
        model_outputs: dict[str, Any] = {}
        for model_name, mapping in (("hardkuma_256_t40", kuma_by_id), ("full_context_bilstm_256", full_by_id)):
            chunk_predictions = []
            probabilities = []
            for spec in chunk_specs:
                chunk_id = f"{document_id}::chunk-{spec['chunk_index']}"
                prediction = mapping[chunk_id]
                probabilities.append(float(prediction["probability_machine"]))
                item: dict[str, Any] = {
                    **spec,
                    "probability_machine": float(prediction["probability_machine"]),
                    "predicted_label_id": int(prediction["predicted_label_id"]),
                }
                if model_name.startswith("hardkuma"):
                    local_indices = [int(value) for value in prediction["selected_token_indices"]]
                    item.update(
                        {
                            "local_rationale_tokens": prediction["selected_tokens"],
                            "local_rationale_indices": local_indices,
                            "document_rationale_indices": [spec["start"] + value for value in local_indices],
                        }
                    )
                chunk_predictions.append(item)
            mean_probability = statistics.mean(probabilities)
            max_probability = max(probabilities)
            original = original_predictions[model_name][document_id]
            model_outputs[model_name] = {
                "chunks": chunk_predictions,
                "first_chunk_recomputed_probability": probabilities[0],
                "first_chunk_recomputed_prediction": int(probabilities[0] >= 0.5),
                "first_256_probability": probability(original),
                "first_256_prediction": int(original["predicted_label_id"]),
                "first_chunk_probability_delta_from_saved": probabilities[0] - probability(original),
                "mean_aggregated_probability": mean_probability,
                "mean_aggregated_prediction": int(mean_probability >= 0.5),
                "max_aggregated_probability": max_probability,
                "max_aggregated_prediction": int(max_probability >= 0.5),
            }
        output.append(
            {
                "id": document_id,
                "source_id": document["source_id"],
                "label_id": int(document["label_id"]),
                "domain": document["domain"],
                "generator": document["generator"],
                "original_token_count": len(tokenize(document["text"])),
                "length_bucket": length_bucket(len(tokenize(document["text"]))),
                "number_of_chunks": len(chunk_specs),
                "chunk_boundaries": chunk_specs,
                "models": model_outputs,
            }
        )
    manifest = {
        "device": str(device),
        "chunk_size": 256,
        "overlap": 0,
        "final_short_chunk_retained": True,
        "checkpoints": {
            "hardkuma_256_t40": str(kuma_dir / "model.pt"),
            "full_context_bilstm_256": str(full_dir / "model.pt"),
        },
        "warning": "Exploratory only: checkpoints were trained on document prefixes, not later chunks or document-level aggregation.",
        "first_chunk_recomputation_max_absolute_probability_delta": {
            model_name: max(abs(row["models"][model_name]["first_chunk_probability_delta_from_saved"]) for row in output)
            for model_name in ("hardkuma_256_t40", "full_context_bilstm_256")
        },
    }
    return output, manifest


def summarize(rows: list[dict[str, Any]], manifest: dict[str, Any]) -> dict[str, Any]:
    output: dict[str, Any] = {"manifest": manifest, "models": {}}
    truth = [int(row["label_id"]) for row in rows]
    for model_name in ("hardkuma_256_t40", "full_context_bilstm_256"):
        result = {}
        for method, probability_key, prediction_key in (
            ("first_256", "first_256_probability", "first_256_prediction"),
            ("mean", "mean_aggregated_probability", "mean_aggregated_prediction"),
            ("maximum", "max_aggregated_probability", "max_aggregated_prediction"),
        ):
            probabilities = [float(row["models"][model_name][probability_key]) for row in rows]
            predictions = [int(row["models"][model_name][prediction_key]) for row in rows]
            result[method] = binary_metrics(truth, predictions, probabilities)
        first_correct = [int(row["models"][model_name]["first_256_prediction"]) == int(row["label_id"]) for row in rows]
        for method in ("mean", "maximum"):
            prediction_key = "mean_aggregated_prediction" if method == "mean" else "max_aggregated_prediction"
            method_correct = [int(row["models"][model_name][prediction_key]) == int(row["label_id"]) for row in rows]
            result[method]["corrected_vs_first"] = sum((not first) and current for first, current in zip(first_correct, method_correct, strict=True))
            result[method]["broken_vs_first"] = sum(first and (not current) for first, current in zip(first_correct, method_correct, strict=True))
        result["by_length"] = {}
        for bucket in ("1-128", "129-256", "257-512", ">512"):
            indices = [index for index, row in enumerate(rows) if row["length_bucket"] == bucket]
            result["by_length"][bucket] = {}
            for method, probability_key, prediction_key in (
                ("first_256", "first_256_probability", "first_256_prediction"),
                ("mean", "mean_aggregated_probability", "mean_aggregated_prediction"),
                ("maximum", "max_aggregated_probability", "max_aggregated_prediction"),
            ):
                result["by_length"][bucket][method] = binary_metrics(
                    [truth[index] for index in indices],
                    [int(rows[index]["models"][model_name][prediction_key]) for index in indices],
                    [float(rows[index]["models"][model_name][probability_key]) for index in indices],
                )
        output["models"][model_name] = result
    return output


def main() -> None:
    parser = argparse.ArgumentParser(description="Frozen 256-token non-overlapping document-chunking pilot.")
    parser.add_argument("--device", default="auto", choices=DEVICE_CHOICES)
    parser.add_argument("--batch-size", default=32, type=int)
    args = parser.parse_args()
    device = resolve_device(args.device)
    rows, manifest = evaluate_chunks(device, args.batch_size)
    write_jsonl(OUTPUT_ROOT / "per_example.jsonl", rows)
    write_json(OUTPUT_ROOT / "summary.json", summarize(rows, manifest))
    print(f"Saved exploratory chunking pilot for {len(rows)} documents to {OUTPUT_ROOT}")


if __name__ == "__main__":
    main()
