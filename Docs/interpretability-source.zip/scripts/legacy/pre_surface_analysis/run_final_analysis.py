from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import platform
import statistics
import subprocess
import sys
from collections import defaultdict
from datetime import datetime, timezone
from itertools import combinations
from pathlib import Path
from typing import Any, Iterable

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score, roc_auc_score

REPO = Path(__file__).resolve().parents[2]
if str(REPO) not in sys.path:
    sys.path.insert(0, str(REPO))
sys.path.insert(0, str(REPO / "src"))

from detectgpt.rationales.vocab import tokenize
from detectgpt.data.io import load_dataset_splits
from detectgpt.rationales.transformer_experiment import TokenDataset as TransformerTokenDataset
from detectgpt.rationales.transformer_experiment import load_checkpoint as load_transformer_checkpoint
from detectgpt.rationales.transformer_experiment import make_loader as make_transformer_loader
from scripts.legacy.pre_surface_analysis.common import exact_mcnemar, paired_bootstrap_f1

SEEDS = (42, 43, 44)
BOOTSTRAP_SEED = 20260809
OUT = REPO / "outputs/archive/pre_surface_final_analysis"

# This is deliberately an allow-list. A run cannot enter a paper table merely by
# resembling a valid filename; audit_run also verifies its saved configuration.
FINAL_FAMILIES = [
    ("tfidf_logreg", "TF-IDF + logistic regression", "outputs/baselines/tfidf_raid_core_en_v3", None, "tfidf", 0, "none", None),
    ("bilstm_rationale_128_40", "HardKuma BiLSTM rationale", "outputs/rationales/kuma_corrected_t40_len128_ratefix_s{seed}", SEEDS, "bilstm", 128, "proportional", 0.40),
    ("bilstm_rationale_256_30", "HardKuma BiLSTM rationale", "outputs/rationales/kuma_corrected_t30_ratefix_s{seed}", SEEDS, "bilstm", 256, "proportional", 0.30),
    ("bilstm_rationale_256_40", "HardKuma BiLSTM rationale", "outputs/rationales/kuma_corrected_t40_ratefix_s{seed}", SEEDS, "bilstm", 256, "proportional", 0.40),
    ("bilstm_rationale_256_50", "HardKuma BiLSTM rationale", "outputs/rationales/kuma_corrected_t50_ratefix_s{seed}", SEEDS, "bilstm", 256, "proportional", 0.50),
    ("bilstm_rationale_512_40", "HardKuma BiLSTM rationale", "outputs/rationales/kuma_corrected_t40_len512_ratefix_s{seed}", SEEDS, "bilstm", 512, "proportional", 0.40),
    ("bilstm_rationale_512_fixed102", "HardKuma BiLSTM rationale", "outputs/rationales/kuma_corrected_fixed102_len512_budgetfix_s{seed}", SEEDS, "bilstm", 512, "fixed", 102),
    ("bilstm_full_128", "Full-context BiLSTM", "outputs/full_context_bilstm/len128_s{seed}", SEEDS, "bilstm", 128, "full", None),
    ("bilstm_full_256", "Full-context BiLSTM", "outputs/full_context_bilstm/s{seed}", SEEDS, "bilstm", 256, "full", None),
    ("bilstm_full_512", "Full-context BiLSTM", "outputs/full_context_bilstm/len512_s{seed}", SEEDS, "bilstm", 512, "full", None),
    ("transformer_rationale_256_30", "Transformer rationale", "outputs/transformer_rationales/transformer_rationale_t30_corrected_s{seed}", SEEDS, "transformer", 256, "proportional", 0.30),
    ("transformer_full_256", "Full-context Transformer", "outputs/transformer_full_context/transformer_full_context_s{seed}", SEEDS, "transformer", 256, "full", None),
]


def read_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line]


def write_csv(path: Path, rows: list[dict[str, Any]], fields: list[str] | None = None) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fields = fields or list(rows[0])
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def write_jsonl(path: Path, rows: Iterable[dict[str, Any]]) -> None:
    with path.open("w", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n")


def prob(row: dict[str, Any]) -> float:
    return float(row.get("probability_machine", row.get("machine_probability")))


def metrics(rows: list[dict[str, Any]]) -> dict[str, float]:
    y = [int(r["label_id"]) for r in rows]
    p = [int(r.get("predicted_label_id", prob(r) >= .5)) for r in rows]
    s = [prob(r) for r in rows]
    return {
        "accuracy": float(accuracy_score(y, p)),
        "precision": float(precision_score(y, p, zero_division=0)),
        "recall": float(recall_score(y, p, zero_division=0)),
        "f1": float(f1_score(y, p, zero_division=0)),
        "auroc": float(roc_auc_score(y, s)) if len(set(y)) == 2 else math.nan,
    }


def ids_checked(path: Path) -> list[dict[str, Any]]:
    rows = read_jsonl(path)
    ids = [str(r["id"]) for r in rows]
    if len(rows) != 1200 or len(set(ids)) != 1200:
        raise ValueError(f"Expected 1,200 unique frozen-test IDs in {path}, got {len(rows)}/{len(set(ids))}")
    return rows


def all_final_runs() -> list[dict[str, Any]]:
    result = []
    for key, label, template, seeds, encoder, context, budget_type, budget in FINAL_FAMILIES:
        for seed in seeds or (42,):
            path = REPO / template.format(seed=seed)
            result.append({"key": key, "label": label, "path": path, "seed": seed, "encoder": encoder,
                           "context": context, "budget_type": budget_type, "budget": budget})
    return result


def validate_final_run(run: dict[str, Any]) -> tuple[dict[str, Any], dict[str, Any], list[dict[str, Any]]]:
    path = run["path"]
    for name in ("config.json", "metrics.json", "test_predictions.jsonl", "validation_predictions.jsonl"):
        if not (path / name).exists():
            raise FileNotFoundError(f"Final-table artifact is not traceable: {path/name}")
    config, saved = read_json(path / "config.json"), read_json(path / "metrics.json")
    test = ids_checked(path / "test_predictions.jsonl")
    validation = ids_checked(path / "validation_predictions.jsonl")
    if int(config.get("seed", 42)) != run["seed"]:
        raise ValueError(f"Seed metadata mismatch in {path}")
    if "raid_core_en_v3" not in str(config.get("data_dir", "")):
        raise ValueError(f"Wrong/fuzzy dataset provenance in {path}")
    if run["context"] and int(config.get("max_tokens", config.get("model", {}).get("max_tokens", 0))) != run["context"]:
        raise ValueError(f"Context metadata mismatch in {path}")
    if run["budget_type"] == "proportional":
        if not config.get("rate_control_enabled", True) or not math.isclose(float(config["target_selection"]), float(run["budget"])):
            raise ValueError(f"Selection-controller metadata mismatch in {path}")
        if "transformer" not in run["key"] and config.get("coherence_control_enabled") is not False:
            raise ValueError(f"Expected corrected --no-coherence-control semantics in {path}")
    if run["budget_type"] == "fixed":
        if config.get("selection_budget") != 102 or config.get("selection_constraint_mode") != "fixed_count_ratio":
            raise ValueError(f"Fixed-102 artifact is not the approved budget-fix run: {path}")
        targets = config.get("fixed_budget_effective_targets", {})
        train_target = float(targets.get("train", {}).get("mean_target_tokens", -1))
        test_target = float(targets.get("test", {}).get("mean_target_tokens", -2))
        observed = statistics.mean(len(r["selected_token_indices"]) for r in test)
        if max(abs(train_target - test_target), abs(observed - test_target)) > 0.25:
            raise ValueError(f"Training/evaluation fixed-token targets do not match in {path}")
    recalculated = metrics(test)
    val_recalculated = metrics(validation)
    saved_test = saved["test"]["overall"]
    if abs(recalculated["f1"] - float(saved_test["machine_f1"])) > 1e-10:
        raise ValueError(f"Saved/recalculated test F1 mismatch in {path}")
    if abs(val_recalculated["f1"] - float(config.get("best_val_f1", saved["validation"]["overall"]["machine_f1"]))) > 1e-10:
        raise ValueError(f"Validation-selected checkpoint metadata mismatch in {path}")
    return config, saved, test


def inventory() -> tuple[list[dict[str, Any]], dict[str, tuple[dict[str, Any], dict[str, Any], list[dict[str, Any]]]]]:
    final_by_path = {str(r["path"].resolve()): r for r in all_final_runs()}
    audited: dict[str, tuple[dict[str, Any], dict[str, Any], list[dict[str, Any]]]] = {}
    rows = []
    roots = [REPO / "outputs/baselines", REPO / "outputs/rationales", REPO / "outputs/full_context_bilstm",
             REPO / "outputs/transformer_rationales", REPO / "outputs/transformer_full_context"]
    paths = sorted({p.parent for root in roots if root.exists() for p in root.glob("*/config.json")})
    for path in paths:
        config = read_json(path / "config.json")
        chosen = final_by_path.get(str(path.resolve()))
        status, reason = "NOT USED", "Outside the pre-specified final comparison matrix."
        if chosen:
            audited[str(path)] = validate_final_run(chosen)
            status, reason = "VALID", "Metadata satisfies the corrected final-family allow-list and provenance checks."
        else:
            name = path.name.lower()
            model_type = str(config.get("model", {}).get("type", config.get("baseline", "")))
            if any(tag in name for tag in ("v10", "v11", "v12")) or ("kuma_" in name and "corrected" not in name):
                status, reason = "INVALID", "Historical HardKuma run predating the padding-dependent BiLSTM correction."
            elif "transformer_rationale_t30_s" in name and "corrected" not in name:
                status, reason = "INVALID", "Original rationale Transformer run predating the controller-sign fix."
            elif "fixed102" in name and "budgetfix" not in name:
                status, reason = "INVALID", "Original fixed-102 formulation did not match the capped per-document training target to deterministic evaluation."
            elif "kuma_corrected" in name and "ratefix" not in name and "budgetfix" not in name:
                status, reason = "INVALID", "Run from the old selection-controller/--no-coherence-control bug window."
            elif "smoke" in name or config.get("limits", {}).get("train") is not None:
                status, reason = "NOT USED", "Smoke/limited run, not a full frozen-split experiment."
        metrics_path = path / "metrics.json"
        saved = read_json(metrics_path) if metrics_path.exists() else {}
        overall = saved.get("test", {}).get("overall", {})
        rationale = saved.get("test", {}).get("rationales", saved.get("test", {}).get("rationale", {}))
        test_path = path / "test_predictions.jsonl"
        pred_rows = read_jsonl(test_path) if test_path.exists() else []
        selected_counts = [len(r.get("selected_token_indices", [])) for r in pred_rows if "selected_token_indices" in r]
        selected_fracs = [float(r["selected_fraction"]) for r in pred_rows if "selected_fraction" in r]
        rows.append({
            "artifact_path": str(path.relative_to(REPO)), "model_family": model_type or chosen and chosen["label"],
            "rationale_or_full_context": "rationale" if selected_counts or "rationale" in model_type else ("full-context" if "full" in model_type else "baseline"),
            "context_length": config.get("max_tokens", config.get("model", {}).get("max_tokens")),
            "rationale_budget_or_fixed_target": config.get("selection_budget", config.get("target_selection")),
            "encoder": chosen["encoder"] if chosen else ("transformer" if "transformer" in model_type else "bilstm" if "kuma" in model_type or "bilstm" in model_type else "tfidf"),
            "seed": config.get("seed"), "git_commit": config.get("git_commit"),
            "checkpoint_selection_epoch": config.get("best_epoch", saved.get("best_epoch")),
            "validation_f1": config.get("best_val_f1", saved.get("validation", {}).get("overall", {}).get("machine_f1")),
            "test_accuracy": overall.get("accuracy"), "precision": overall.get("machine_precision"),
            "recall": overall.get("machine_recall"), "f1": overall.get("machine_f1"), "auroc": overall.get("auroc"),
            "average_selected_tokens": statistics.mean(selected_counts) if selected_counts else rationale.get("average_selected_tokens"),
            "average_selected_fraction": statistics.mean(selected_fracs) if selected_fracs else rationale.get("average_selected_fraction"),
            "controller_diagnostics": json.dumps({k: config.get(k) for k in ("rate_control_enabled", "constraint_satisfied", "controller_mode", "coherence_control_enabled", "selection_constraint_mode", "fixed_budget_effective_targets") if k in config}, sort_keys=True),
            "status": status, "reason": reason,
        })
    return rows, audited


def aggregate(audited: dict[str, tuple[dict[str, Any], dict[str, Any], list[dict[str, Any]]]]) -> tuple[list[dict[str, Any]], dict[str, list[dict[str, Any]]]]:
    output, predictions = [], defaultdict(list)
    for key, label, template, seeds, encoder, context, budget_type, budget in FINAL_FAMILIES:
        run_metrics = []
        for seed in seeds or (42,):
            path = REPO / template.format(seed=seed)
            config, _, rows = audited[str(path)]
            m = metrics(rows)
            counts = [len(r.get("selected_token_indices", [])) for r in rows]
            fractions = [float(r.get("selected_fraction", 1.0)) for r in rows]
            m.update({"seed": seed, "val_f1": float(config.get("best_val_f1", metrics(read_jsonl(path / "validation_predictions.jsonl"))["f1"])),
                      "selected_tokens": statistics.mean(counts) if counts and max(counts) else math.nan,
                      "selected_fraction": statistics.mean(fractions) if counts and max(counts) else math.nan})
            run_metrics.append(m)
            predictions[key].append(rows)
        row = {"configuration": key, "model": label, "encoder": encoder, "rationale_or_full_context": budget_type,
               "context_tokens": context or "all", "budget": budget if budget is not None else "all", "n_seeds": len(run_metrics)}
        for field in ("val_f1", "accuracy", "precision", "recall", "f1", "auroc", "selected_tokens", "selected_fraction"):
            values = [float(m[field]) for m in run_metrics if not math.isnan(float(m[field]))]
            row[f"{field}_mean"] = statistics.mean(values) if values else math.nan
            row[f"{field}_sd"] = statistics.stdev(values) if len(values) > 1 else (0.0 if values else math.nan)
        output.append(row)
    return output, predictions


def markdown_and_tex(rows: list[dict[str, Any]]) -> None:
    lines = ["# Aggregate detection metrics", "", "Mean ± sample SD across seeds 42/43/44; TF-IDF is deterministic (one run).", "",
             "| Configuration | Context | Budget | Accuracy | Precision | Recall | F1 | AUROC | Selected tokens |",
             "|---|---:|---:|---:|---:|---:|---:|---:|---:|"]
    def pm(row: dict[str, Any], field: str) -> str:
        value = row[f"{field}_mean"]
        return "—" if math.isnan(value) else f"{value:.4f} ± {row[f'{field}_sd']:.4f}"
    for r in rows:
        lines.append(f"| {r['model']} ({r['configuration']}) | {r['context_tokens']} | {r['budget']} | {pm(r,'accuracy')} | {pm(r,'precision')} | {pm(r,'recall')} | {pm(r,'f1')} | {pm(r,'auroc')} | {pm(r,'selected_tokens')} |")
    (OUT / "aggregate_detection_metrics.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    tex = ["\\begin{tabular}{llrrrr}", "\\toprule", "Model & Context & Budget & Accuracy & F1 & AUROC \\\\", "\\midrule"]
    for r in rows:
        tex.append(f"{r['model'].replace('&', r'\&')} & {r['context_tokens']} & {r['budget']} & {pm(r,'accuracy').replace('±', r'$\pm$')} & {pm(r,'f1').replace('±', r'$\pm$')} & {pm(r,'auroc').replace('±', r'$\pm$')} \\\\")
    tex += ["\\bottomrule", "\\end{tabular}"]
    (OUT / "aggregate_detection_metrics.tex").write_text("\n".join(tex) + "\n", encoding="utf-8")


def comparisons(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    by = {r["configuration"]: r for r in rows}
    specs = [
        ("budget_30_vs_40_256", "bilstm_rationale_256_30", "bilstm_rationale_256_40"),
        ("budget_40_vs_50_256", "bilstm_rationale_256_40", "bilstm_rationale_256_50"),
        ("context_128_vs_256_40", "bilstm_rationale_128_40", "bilstm_rationale_256_40"),
        ("context_256_vs_512_40", "bilstm_rationale_256_40", "bilstm_rationale_512_40"),
        ("rationale_vs_full_256_bilstm", "bilstm_rationale_256_40", "bilstm_full_256"),
        ("rationale_vs_full_512_bilstm", "bilstm_rationale_512_40", "bilstm_full_512"),
        ("fixed102_512_vs_40pct_256", "bilstm_rationale_256_40", "bilstm_rationale_512_fixed102"),
        ("encoder_rationale_30pct_256", "bilstm_rationale_256_30", "transformer_rationale_256_30"),
    ]
    result = []
    for name, a, b in specs:
        ra, rb = by[a], by[b]
        result.append({"comparison": name, "configuration_a": a, "configuration_b": b,
                       "f1_a": ra["f1_mean"], "f1_b": rb["f1_mean"], "f1_difference_b_minus_a": rb["f1_mean"]-ra["f1_mean"],
                       "selected_tokens_a": ra["selected_tokens_mean"], "selected_tokens_b": rb["selected_tokens_mean"],
                       "selected_fraction_a": ra["selected_fraction_mean"], "selected_fraction_b": rb["selected_fraction_mean"],
                       "difference_from_full_context_a": (ra["f1_mean"]-by.get(f"bilstm_full_{ra['context_tokens']}", ra)["f1_mean"]) if ra["encoder"] == "bilstm" else math.nan,
                       "difference_from_full_context_b": (rb["f1_mean"]-by.get(f"bilstm_full_{rb['context_tokens']}", rb)["f1_mean"]) if rb["encoder"] == "bilstm" else math.nan})
    return result


def make_plots(aggregate_rows: list[dict[str, Any]], comparison_rows: list[dict[str, Any]]) -> None:
    plot_dir = OUT / "plots"; plot_dir.mkdir(exist_ok=True)
    by = {r["configuration"]: r for r in aggregate_rows}
    figures = [
        ("rationale_budget.pdf", [30,40,50], [by[f"bilstm_rationale_256_{x}"]["f1_mean"] for x in (30,40,50)], "Rationale budget (%)", "Test machine F1"),
        ("context_length.pdf", [128,256,512], [by[f"bilstm_rationale_{x}_40"]["f1_mean"] for x in (128,256,512)], "Visible context (tokens)", "Test machine F1"),
    ]
    for filename, x, y, xlabel, ylabel in figures:
        fig, ax = plt.subplots(figsize=(4.5,3.2)); ax.plot(x,y,marker="o"); ax.set(xlabel=xlabel,ylabel=ylabel); ax.grid(alpha=.25); fig.tight_layout(); fig.savefig(plot_dir/filename); plt.close(fig)
    keys = ["bilstm_rationale_256_40", "bilstm_full_256", "bilstm_rationale_512_fixed102", "bilstm_full_512"]
    fig, ax = plt.subplots(figsize=(6,3.4)); ax.bar(range(len(keys)), [by[k]["f1_mean"] for k in keys], yerr=[by[k]["f1_sd"] for k in keys], capsize=3)
    ax.set_xticks(range(len(keys)), ["R-256/40%","Full-256","R-512/102","Full-512"], rotation=15); ax.set_ylabel("Test machine F1"); fig.tight_layout(); fig.savefig(plot_dir/"matched_and_fixed_token.pdf"); plt.close(fig)


def rationale_controls(audited: dict[str, tuple[dict[str, Any], dict[str, Any], list[dict[str, Any]]]]) -> tuple[list[dict[str, Any]], list[str]]:
    rows, missing = [], []
    for run in all_final_runs():
        if run["budget_type"] not in ("proportional", "fixed"):
            continue
        control_path = run["path"] / "rationale_controls.json"
        if not control_path.exists():
            if run["encoder"] == "transformer":
                payload = transformer_controls(run)
            else:
                missing.append(str(run["path"].relative_to(REPO)))
                continue
        else:
            payload = read_json(control_path)
        for strategy in ("learned", "random", "first", "last"):
            overall, selection = payload[strategy]["overall"], payload[strategy]["selection"]
            rows.append({"configuration": run["key"], "seed": run["seed"], "strategy": strategy,
                         "accuracy": overall["accuracy"], "f1": overall["machine_f1"], "auroc": overall["auroc"],
                         "mean_selected_tokens": selection["average_selected_tokens"]})
    aggregate_rows = []
    for (config, strategy), values in sorted(_groups(rows, "configuration", "strategy").items()):
        aggregate_rows.append({"configuration": config, "strategy": strategy, "n_seeds": len(values), **{
            f"{field}_{suffix}": fn([float(v[field]) for v in values]) for field in ("accuracy","f1","auroc","mean_selected_tokens")
            for suffix, fn in (("mean", statistics.mean),("sd", lambda x: statistics.stdev(x) if len(x)>1 else 0.0))}})
    write_csv(OUT / "rationale_controls.csv", aggregate_rows)
    tex = ["\\begin{tabular}{llrrr}", "\\toprule", "Configuration & Control & Accuracy & F1 & AUROC \\\\", "\\midrule"]
    for r in aggregate_rows:
        tex.append(f"{r['configuration'].replace('_', r'\_')} & {r['strategy']} & {r['accuracy_mean']:.4f} $\\pm$ {r['accuracy_sd']:.4f} & {r['f1_mean']:.4f} $\\pm$ {r['f1_sd']:.4f} & {r['auroc_mean']:.4f} $\\pm$ {r['auroc_sd']:.4f} \\\\")
    tex += ["\\bottomrule", "\\end{tabular}"]
    (OUT / "rationale_controls.tex").write_text("\n".join(tex)+"\n", encoding="utf-8")
    return aggregate_rows, missing


def transformer_controls(run: dict[str, Any]) -> dict[str, Any]:
    """Evaluate frozen Transformer predictor with exactly count-matched masks."""
    run_dir = run["path"]
    cache = OUT / "transformer_controls" / f"{run_dir.name}.json"
    if cache.exists():
        return read_json(cache)
    device = torch.device("cpu")
    model, vocab, config = load_transformer_checkpoint(run_dir, device)
    source_rows = load_dataset_splits(Path(config["data_dir"]), ("test",))["test"]
    loader = make_transformer_loader(
        TransformerTokenDataset(source_rows, vocab, int(config["max_tokens"])),
        int(config["batch_size"]), False, int(config["seed"]), vocab.pad_id,
    )
    strategies = ("learned", "random", "first", "last")
    accum = {name: [] for name in strategies}
    generator = np.random.default_rng(10_000 + int(config["seed"]))
    model.eval()
    with torch.no_grad():
        for batch in loader:
            input_ids, mask = batch["input_ids"].to(device), batch["mask"].to(device)
            embeddings = model.embed_tokens(input_ids)
            a, b = model.gate_parameters(embeddings, mask)
            gates = model.deterministic_gates(a, b, mask)
            valid_counts = mask.sum(dim=1).tolist()
            learned_indices = []
            for gate_row, valid in zip(gates.tolist(), valid_counts, strict=True):
                count = min(valid, max(1, math.ceil(float(config["target_selection"]) * valid)))
                learned_indices.append(sorted(sorted(range(valid), key=lambda i: (-gate_row[i], i))[:count]))
            for strategy in strategies:
                hard = torch.zeros_like(gates)
                index_rows = []
                for learned, valid in zip(learned_indices, valid_counts, strict=True):
                    count = len(learned)
                    selected = learned if strategy == "learned" else (sorted(generator.choice(valid, count, replace=False).tolist()) if strategy == "random" else list(range(count)) if strategy == "first" else list(range(valid-count, valid)))
                    index_rows.append(selected)
                for i, selected in enumerate(index_rows): hard[i, selected] = 1.0
                probabilities = torch.softmax(model.predict_from_gates(embeddings, hard, mask), dim=1)[:, 1].tolist()
                for example, selected, probability in zip(batch["examples"], index_rows, probabilities, strict=True):
                    pred = int(probability >= .5)
                    accum[strategy].append({"id": example.row["id"], "label_id": int(example.row["label_id"]),
                                            "predicted_label_id": pred, "probability_machine": float(probability),
                                            "selected_token_count": len(selected)})
    payload = {}
    cache.parent.mkdir(parents=True, exist_ok=True)
    for strategy, values in accum.items():
        score = metrics(values)
        payload[strategy] = {"overall": {"accuracy": score["accuracy"], "machine_f1": score["f1"], "auroc": score["auroc"]},
                             "selection": {"average_selected_tokens": statistics.mean(v["selected_token_count"] for v in values)}}
        write_jsonl(OUT / "transformer_controls" / f"{run_dir.name}_{strategy}_predictions.jsonl", values)
    cache.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return payload


def _groups(rows: list[dict[str, Any]], *fields: str) -> dict[tuple[Any, ...], list[dict[str, Any]]]:
    result = defaultdict(list)
    for row in rows: result[tuple(row[f] for f in fields)].append(row)
    return result


def faithfulness() -> list[dict[str, Any]]:
    result = []
    for run in all_final_runs():
        if run["budget_type"] not in ("proportional", "fixed"): continue
        _, _, rows = validate_final_run(run)
        for metric_name in ("sufficiency_drop", "comprehensiveness_drop"):
            values = [float(r[metric_name]) for r in rows]
            result.append({"configuration": run["key"], "seed": run["seed"], "metric": metric_name,
                           "mean": statistics.mean(values), "median": statistics.median(values), "sd": statistics.stdev(values),
                           "q025": float(np.quantile(values,.025)), "q975": float(np.quantile(values,.975)), "n": len(values)})
    write_csv(OUT / "faithfulness.csv", result)
    method = """# Faithfulness method

The repository already implements the probability-drop definitions used in ERASER/DeYoung-style evaluation. For the class predicted from the learned rationale, let `p(c | x)` be its probability with every visible token, `p(c | r)` its probability with only selected positions, and `p(c | x \\ r)` its probability after removing those positions.

* Sufficiency drop: `p(c | x) - p(c | r)` (smaller is conventionally better).
* Comprehensiveness drop: `p(c | x) - p(c | x \\ r)` (larger is conventionally better).

The interventions use the same frozen checkpoint, vocabulary, visible prefix, predictor, and selected token positions. Values in `faithfulness.csv` are aggregated over the frozen test examples separately for each seed.

## Architectural limitation

The predictor is trained to classify from selected evidence, so `p(c | r)` is its native input and `p(c | x)` is an evaluation-only all-token intervention. Consequently, near-zero sufficiency is partly built into the architecture/training objective and is not independent proof that the selector is faithful. The complement input is also outside the predictor's usual training distribution, so comprehensiveness is a useful diagnostic but not causal proof or evidence of human interpretability. These metrics must be reported with the matched controls and not described as establishing faithfulness by themselves.
"""
    (OUT / "faithfulness_method.md").write_text(method, encoding="utf-8")
    return result


def stability() -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    per, summary = [], []
    for key, _, template, seeds, _, context, budget_type, budget in FINAL_FAMILIES:
        if seeds is None or budget_type not in ("proportional", "fixed"): continue
        maps = {seed: {str(r["id"]): r for r in ids_checked(REPO / template.format(seed=seed) / "test_predictions.jsonl")} for seed in SEEDS}
        if len({tuple(sorted(m)) for m in maps.values()}) != 1: raise ValueError(f"IDs differ for stability: {key}")
        pair_values = defaultdict(list); all_values=[]
        for example_id in sorted(maps[42]):
            token_lists = [tokenize(maps[s][example_id]["text"])[:context] for s in SEEDS]
            if not (token_lists[0] == token_lists[1] == token_lists[2]): raise ValueError(f"Tokenisation mismatch: {key}/{example_id}")
            for a,b in combinations(SEEDS,2):
                sa,sb=set(maps[a][example_id]["selected_token_indices"]),set(maps[b][example_id]["selected_token_indices"])
                j=len(sa&sb)/len(sa|sb) if sa|sb else 1.0
                per.append({"configuration":key,"example_id":example_id,"seed_a":a,"seed_b":b,"jaccard":j})
                pair_values[(a,b)].append(j); all_values.append(j)
        for pair, values in list(pair_values.items())+[("all_pairs",all_values)]:
            summary.append({"configuration":key,"seed_pair":f"{pair[0]}-{pair[1]}" if pair != "all_pairs" else pair,"n":len(values),
                            "mean":statistics.mean(values),"median":statistics.median(values),"sd":statistics.stdev(values),
                            "q05":float(np.quantile(values,.05)),"q25":float(np.quantile(values,.25)),"q75":float(np.quantile(values,.75)),"q95":float(np.quantile(values,.95))})
    write_csv(OUT/"rationale_stability.csv",per); write_csv(OUT/"rationale_stability_summary.csv",summary)
    return per,summary


def breakdowns(predictions: dict[str, list[list[dict[str, Any]]]]) -> None:
    frozen = {str(r["id"]): r for r in read_jsonl(REPO / "data/processed/raid_core_en_v3/test.jsonl")}
    main = ("tfidf_logreg","bilstm_rationale_256_40","bilstm_full_256","bilstm_rationale_512_fixed102","bilstm_full_512","transformer_rationale_256_30","transformer_full_256")
    domain_rows=[]; generator_rows=[]; length_rows=[]
    for key in main:
        for index, seed_rows in enumerate(predictions[key]):
            seed = 42 if key == "tfidf_logreg" else SEEDS[index]
            for domain, values in _groups(seed_rows,"domain").items(): domain_rows.append(_break(key,seed,"domain",domain[0],values))
            machines=[r for r in seed_rows if int(r["label_id"])==1]
            for gen, values in _groups(machines,"generator").items(): generator_rows.append(_break(key,seed,"generator",gen[0],values))
            buckets=defaultdict(list)
            for r in seed_rows:
                n=len(tokenize(str(r.get("text", frozen[str(r["id"])]["text"])))); bucket="1-128" if n<=128 else "129-256" if n<=256 else "257-512" if n<=512 else ">512"; buckets[bucket].append(r)
            for bucket,values in buckets.items(): length_rows.append(_break(key,seed,"length_bucket",bucket,values))
    write_csv(OUT/"per_domain.csv",domain_rows); write_csv(OUT/"per_generator.csv",generator_rows); write_csv(OUT/"per_length_bucket.csv",length_rows)


def _break(key: str, seed: int, field: str, group: str, rows: list[dict[str, Any]]) -> dict[str, Any]:
    m=metrics(rows)
    return {"configuration":key,"seed":seed,field:group,"n":len(rows),"human_n":sum(int(r["label_id"])==0 for r in rows),"machine_n":sum(int(r["label_id"])==1 for r in rows),"accuracy":m["accuracy"],"recall":m["recall"],"f1":m["f1"]}


def paired_tests(predictions: dict[str, list[list[dict[str, Any]]]]) -> list[dict[str, Any]]:
    pairs=[("main_rationale_vs_full","bilstm_rationale_256_40","bilstm_full_256"),("main_rationale_vs_tfidf","bilstm_rationale_256_40","tfidf_logreg"),("fixed102_512_vs_40pct_256","bilstm_rationale_256_40","bilstm_rationale_512_fixed102")]
    output=[]
    for name,a,b in pairs:
        for index, seed in enumerate(SEEDS):
            ar=predictions[a][index]; br=predictions[b][0 if b=="tfidf_logreg" else index]
            am={str(r["id"]):r for r in ar}; bm={str(r["id"]):r for r in br}
            if set(am)!=set(bm): raise ValueError(f"Paired IDs mismatch: {name}/seed{seed}")
            ids=sorted(am); y=[int(am[i]["label_id"]) for i in ids]; pa=[int(am[i]["predicted_label_id"]) for i in ids]; pb=[int(bm[i]["predicted_label_id"]) for i in ids]
            boot=paired_bootstrap_f1(y,pa,pb,resamples=10000,seed=BOOTSTRAP_SEED); mc=exact_mcnemar(y,pa,pb)
            output.append({"comparison":name,"model_a":a,"model_b":b,"seed":seed,"f1_difference_b_minus_a":boot["observed_difference"],"bootstrap_ci_lower":boot["confidence_interval_95"][0],"bootstrap_ci_upper":boot["confidence_interval_95"][1],"bootstrap_resamples":10000,"bootstrap_seed":BOOTSTRAP_SEED,"mcnemar_exact_p":mc["exact_two_sided_p_value"],"a_only_correct":mc["a_only_correct_b_newly_broken"],"b_only_correct":mc["b_only_correct_b_corrects_a"]})
    write_csv(OUT/"pairwise_statistical_tests.csv",output)
    lines=["# Paired statistical tests","","Each row compares predictions on the same 1,200 frozen test examples. The paired bootstrap estimates machine-F1(B) − machine-F1(A), with 10,000 resamples and seed 20260809; McNemar is exact and two-sided. Seeds are analysed separately and are not pooled as independent examples.","","| Comparison | Seed | ΔF1 (B−A) | 95% CI | McNemar p |","|---|---:|---:|---:|---:|"]
    for r in output: lines.append(f"| {r['comparison']} | {r['seed']} | {r['f1_difference_b_minus_a']:.4f} | [{r['bootstrap_ci_lower']:.4f}, {r['bootstrap_ci_upper']:.4f}] | {r['mcnemar_exact_p']:.4g} |")
    (OUT/"pairwise_statistical_tests.md").write_text("\n".join(lines)+"\n",encoding="utf-8")
    return output


def qualitative(predictions: dict[str, list[list[dict[str, Any]]]]) -> tuple[int,str]:
    key="bilstm_rationale_256_40"; runs=all_final_runs(); candidates=[r for r in runs if r["key"]==key]
    best=max(candidates,key=lambda r:validate_final_run(r)[0]["best_val_f1"]); seed=best["seed"]
    rows=predictions[key][SEEDS.index(seed)]; tokens_by_id={str(r["id"]):tokenize(r["text"])[:256] for r in rows}
    controls=read_json(best["path"]/"rationale_controls.json") if (best["path"]/"rationale_controls.json").exists() else {}
    output=[]
    for r in rows:
        true=int(r["label_id"]); pred=int(r["predicted_label_id"]); category="correct human" if true==pred==0 else "correct machine" if true==pred==1 else "false positive" if true==0 else "false negative"
        output.append({"id":r["id"],"source_id":r.get("source_id"),"domain":r.get("domain"),"generator":r.get("generator") if true==1 else None,"true_label":r["label"],"predicted_label":r["predicted_label"],"correct":true==pred,"category":category,"machine_probability":prob(r),"confidence":max(prob(r),1-prob(r)),"original_visible_text":r["text"],"tokenised_text":tokens_by_id[str(r["id"])],"selected_token_positions":r["selected_token_indices"],"selected_tokens":r["selected_tokens"],"selected_token_count":len(r["selected_token_indices"]),"selected_fraction":r["selected_fraction"],"rationale_control_outputs":"Aggregate checkpoint controls are in rationale_controls.csv; per-example control predictions were not persisted by the original evaluator."})
    write_jsonl(OUT/"qualitative_candidates.jsonl",output); flat=[{**r,"tokenised_text":json.dumps(r["tokenised_text"],ensure_ascii=False),"selected_token_positions":json.dumps(r["selected_token_positions"]),"selected_tokens":json.dumps(r["selected_tokens"],ensure_ascii=False)} for r in output]; write_csv(OUT/"qualitative_candidates.csv",flat)
    return seed,str(best["path"].relative_to(REPO))


def reproducibility(command: str, inputs: list[str]) -> None:
    packages={}
    for name in ("numpy","scipy","sklearn","matplotlib","torch","pandas"):
        try:
            module=__import__(name); packages[name]=getattr(module,"__version__","unknown")
        except ImportError: packages[name]="not installed"
    commit=subprocess.run(["git","rev-parse","HEAD"],cwd=REPO,text=True,capture_output=True,check=True).stdout.strip()
    payload={"timestamp_utc":datetime.now(timezone.utc).isoformat(),"git_commit":commit,"python_version":platform.python_version(),"platform":platform.platform(),"package_versions":packages,"command":command,"analysis_random_seeds":{"experiment_seeds":list(SEEDS),"paired_bootstrap":BOOTSTRAP_SEED},"input_artifact_paths":inputs}
    (OUT/"reproducibility.json").write_text(json.dumps(payload,indent=2,sort_keys=True)+"\n",encoding="utf-8")


def report(inventory_rows: list[dict[str, Any]], aggregate_rows: list[dict[str, Any]], comparison_rows: list[dict[str, Any]], controls: list[dict[str, Any]], control_missing: list[str], faith: list[dict[str, Any]], stability_summary: list[dict[str, Any]], stats: list[dict[str, Any]], qualitative_seed: int, qualitative_path: str) -> None:
    valid=[r for r in inventory_rows if r["status"]=="VALID"]; invalid=[r for r in inventory_rows if r["status"]=="INVALID"]
    by={r["configuration"]:r for r in aggregate_rows}
    lines=["# Final analysis report","",f"Generated {datetime.now(timezone.utc).isoformat()} from frozen RAID v3 artifacts. Observations and interpretation are separated below.","","## 1. Exact artifacts used","",* [f"- `{r['artifact_path']}` (seed {r['seed']}, commit `{r['git_commit']}`, validation-selected epoch {r['checkpoint_selection_epoch']})" for r in valid],"","## 2. Exact artifacts excluded and why","",* [f"- `{r['artifact_path']}` — {r['reason']}" for r in invalid],"","The complete machine-readable audit, including NOT USED runs, is `artifact_inventory.csv`.","","## 3. Overall detection results (observations)","", "See `aggregate_detection_metrics.md`. All multi-seed entries use seeds 42/43/44 without cherry-picking.",""]
    for k in ("tfidf_logreg","bilstm_rationale_256_40","bilstm_full_256","transformer_rationale_256_30","transformer_full_256","bilstm_rationale_512_fixed102"):
        r=by[k]; lines.append(f"- {k}: mean test F1 {r['f1_mean']:.4f} (SD {r['f1_sd']:.4f}).")
    lines += ["","## 4. Rationale-budget finding (observations)","",f"At 256 tokens, BiLSTM rationale mean F1 is {by['bilstm_rationale_256_30']['f1_mean']:.4f}, {by['bilstm_rationale_256_40']['f1_mean']:.4f}, and {by['bilstm_rationale_256_50']['f1_mean']:.4f} for 30%, 40%, and 50% budgets.","","## 5. Context-length finding (observations)","",f"At a 40% rule, mean F1 is {by['bilstm_rationale_128_40']['f1_mean']:.4f}, {by['bilstm_rationale_256_40']['f1_mean']:.4f}, and {by['bilstm_rationale_512_40']['f1_mean']:.4f} at 128/256/512 visible tokens. This comparison changes both visible and selected evidence, so it does not isolate context alone.","","## 6. Corrected fixed-token finding (observations)","",f"The corrected 512 fixed-102 runs select {by['bilstm_rationale_512_fixed102']['selected_tokens_mean']:.2f} tokens on average (fraction {by['bilstm_rationale_512_fixed102']['selected_fraction_mean']:.4f}) and obtain mean F1 {by['bilstm_rationale_512_fixed102']['f1_mean']:.4f}. Config metadata records capped mean training targets and deterministic test selections within 0.25 token for every seed. Comparing this with 256/40% is approximately count-matched, not exactly per-document matched; interpret cautiously.","","## 7. Encoder comparison (observations)","",f"At 256 tokens and 30%, rationale BiLSTM mean F1 is {by['bilstm_rationale_256_30']['f1_mean']:.4f} versus Transformer {by['transformer_rationale_256_30']['f1_mean']:.4f}. Matched full-context means are {by['bilstm_full_256']['f1_mean']:.4f} and {by['transformer_full_256']['f1_mean']:.4f}.","","## 8. Rationale controls","",f"Matched-count controls were aggregated for {len(set(r['configuration'] for r in controls))} rationale configurations. Transformer controls were recomputed from frozen checkpoints and saved under `transformer_controls/`. Missing controls: {', '.join(control_missing) if control_missing else 'none'}.","","## 9. Faithfulness","","The project definitions and architectural limitations are documented in `faithfulness_method.md`. Numbers are diagnostics, not proof of faithfulness or human interpretability.","","## 10. Cross-seed stability","",f"Token-position Jaccard was computed like-for-like. The summary contains {len(stability_summary)} configuration/pair rows; see `rationale_stability_summary.csv`.","","## 11. Domain, generator, and length observations","","Per-group files include group sample counts. Generator results contain machine examples only; human examples are not assigned to a generator. Small groups should not be overinterpreted.","","## 12. Statistical tests","",f"{len(stats)} seed-specific paired comparisons were completed. Seeds were never pooled as independent examples; see `pairwise_statistical_tests.md`.","","## 13. Anomalies or concerns","", "- Fixed-102 versus 256/40% is only approximately token-count matched in aggregate, not exactly matched for every document.","- The original BiLSTM control evaluator saved aggregate metrics but not per-example control probabilities; Transformer controls generated here do include per-example prediction files.","- Sufficiency is structurally advantaged by rationale-only predictor training; complement inputs are out of distribution.","","## 14. Results safe to use in the paper","","- Rows marked VALID in `artifact_inventory.csv` and their aggregate tables.","- Corrected budget-fix fixed-102 results, with the count-matching caveat above.","- Paired tests only in their seed-specific form.","- Controls only for configurations present in `rationale_controls.csv`.","","## 15. Analyses remaining incomplete","",*( [f"- Missing matched-count controls: {', '.join(control_missing)}."] if control_missing else ["- None required for the requested quantitative analyses."]),"- Per-example BiLSTM rationale-control probabilities cannot be added retrospectively without another frozen-checkpoint evaluation; the qualitative export therefore points to aggregate controls.","","## Interpretation (kept separate)","","The quantitative gaps describe predictive performance under restricted evidence. They do not establish that selected tokens are human-understandable, and high classification performance or probability-drop diagnostics do not by themselves prove rationale faithfulness. Human-study stimuli remain deliberately unselected.","",f"The qualitative candidate export uses seed {qualitative_seed}, selected solely by validation F1 within the main 256/40% family: `{qualitative_path}`."]
    (OUT/"analysis_report.md").write_text("\n".join(lines)+"\n",encoding="utf-8")


def main() -> None:
    global OUT
    parser=argparse.ArgumentParser(description="Reproduce final Honours-paper analysis from frozen artifacts only.")
    parser.add_argument("--output-dir",type=Path,default=OUT)
    args=parser.parse_args()
    OUT=args.output_dir.resolve(); OUT.mkdir(parents=True,exist_ok=True)
    inv,audited=inventory(); write_csv(OUT/"artifact_inventory.csv",inv)
    agg,preds=aggregate(audited); write_csv(OUT/"aggregate_detection_metrics.csv",agg); markdown_and_tex(agg)
    comps=comparisons(agg); write_csv(OUT/"context_budget_comparisons.csv",comps); make_plots(agg,comps)
    controls,missing=rationale_controls(audited); faith=faithfulness(); _,stab_summary=stability(); breakdowns(preds); stats=paired_tests(preds); qseed,qpath=qualitative(preds)
    inputs=[str(r["path"].relative_to(REPO)) for r in all_final_runs()]
    reproducibility("python scripts/legacy/pre_surface_analysis/run_final_analysis.py --output-dir outputs/archive/pre_surface_final_analysis",inputs)
    report(inv,agg,comps,controls,missing,faith,stab_summary,stats,qseed,qpath)
    print(json.dumps({"analyses_completed":["artifact audit","aggregate detection","context/budget/fixed-token comparisons and PDF plots","saved rationale controls","faithfulness","cross-seed stability","domain/generator/length breakdowns","paired tests","qualitative export","report/reproducibility"],"analyses_incomplete":{"transformer_controls":missing},"output_dir":str(OUT)},indent=2))


if __name__ == "__main__":
    main()
