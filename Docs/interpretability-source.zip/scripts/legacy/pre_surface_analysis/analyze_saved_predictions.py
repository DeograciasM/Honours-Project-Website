from __future__ import annotations

import argparse
import csv
import json
import statistics
import sys
from collections import defaultdict
from itertools import combinations
from pathlib import Path
from typing import Any

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from scipy.stats import spearmanr
from sklearn.metrics import roc_auc_score

REPO_ROOT = Path(__file__).resolve().parents[2]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from detectgpt.rationales.vocab import tokenize
from scripts.legacy.pre_surface_analysis.common import (
    apply_operating_point,
    binary_metrics,
    calibration_metrics,
    confidence_bucket,
    exact_mcnemar,
    length_bucket,
    paired_bootstrap_f1,
    predictions_by_id,
    probability,
    read_json,
    read_jsonl,
    threshold_at_validation_fpr,
    write_json,
)


OUTPUT_ROOT = REPO_ROOT / "outputs" / "final_analysis"
DOC_ROOT = REPO_ROOT / "docs" / "experiments" / "final_analysis"

STATIC_SELECTED_MODELS = {
    "tfidf": REPO_ROOT / "outputs/baselines/tfidf_raid_core_en_v3",
    "full_context_bilstm_512": REPO_ROOT / "outputs/full_context_bilstm/len512_s44",
    "full_context_bilstm_256": REPO_ROOT / "outputs/full_context_bilstm/s42",
}

HARDKUMA_SELECTED_TEMPLATES = {
    "hardkuma_512_t40": "outputs/rationales/kuma_corrected_t40_len512_ratefix_s{seed}",
    "hardkuma_256_t40": "outputs/rationales/kuma_corrected_t40_ratefix_s{seed}",
    "hardkuma_512_fixed102": "outputs/rationales/kuma_corrected_fixed102_len512_ratefix_s{seed}",
}


def validation_best_run(template: str) -> Path:
    candidates = []
    for seed in (42, 43, 44):
        run_dir = REPO_ROOT / template.format(seed=seed)
        metrics_path = run_dir / "metrics.json"
        if not metrics_path.exists():
            raise FileNotFoundError(
                f"Required rate-fixed HardKuma result is not complete: {metrics_path}"
            )
        validation_f1 = float(read_json(metrics_path)["validation"]["overall"]["machine_f1"])
        candidates.append((validation_f1, seed, run_dir))
    return max(candidates)[2]


def selected_models() -> dict[str, Path]:
    return {
        **STATIC_SELECTED_MODELS,
        **{
            name: validation_best_run(template)
            for name, template in HARDKUMA_SELECTED_TEMPLATES.items()
        },
    }

CONTEXT_RUNS = [
    ("HardKuma BiLSTM", 128, "proportional", "40%", "outputs/rationales/kuma_corrected_t40_len128_ratefix_s{seed}"),
    ("HardKuma BiLSTM", 256, "proportional", "30%", "outputs/rationales/kuma_corrected_t30_ratefix_s{seed}"),
    ("HardKuma BiLSTM", 256, "proportional", "40%", "outputs/rationales/kuma_corrected_t40_ratefix_s{seed}"),
    ("HardKuma BiLSTM", 256, "proportional", "50%", "outputs/rationales/kuma_corrected_t50_ratefix_s{seed}"),
    ("HardKuma BiLSTM", 512, "proportional", "40%", "outputs/rationales/kuma_corrected_t40_len512_ratefix_s{seed}"),
    ("HardKuma BiLSTM", 512, "fixed", "102 tokens", "outputs/rationales/kuma_corrected_fixed102_len512_ratefix_s{seed}"),
    ("Rationale Transformer", 256, "proportional", "30%", "outputs/transformer_rationales/transformer_rationale_t30_corrected_s{seed}"),
    ("Full-context BiLSTM", 128, "none", "all", "outputs/full_context_bilstm/len128_s{seed}"),
    ("Full-context BiLSTM", 256, "none", "all", "outputs/full_context_bilstm/s{seed}"),
    ("Full-context BiLSTM", 512, "none", "all", "outputs/full_context_bilstm/len512_s{seed}"),
    ("Full-context Transformer", 256, "none", "all", "outputs/transformer_full_context/transformer_full_context_s{seed}"),
]


def mean_sd(values: list[float]) -> tuple[float, float]:
    return statistics.mean(values), statistics.stdev(values) if len(values) > 1 else 0.0


def build_context_table() -> list[dict[str, Any]]:
    output: list[dict[str, Any]] = []
    missing: list[str] = []
    for model, context, budget_type, budget, template in CONTEXT_RUNS:
        runs = []
        for seed in (42, 43, 44):
            run_dir = REPO_ROOT / template.format(seed=seed)
            if not (run_dir / "metrics.json").exists():
                missing.append(str(run_dir / "metrics.json"))
                continue
            runs.append(read_json(run_dir / "metrics.json"))
        if len(runs) != 3:
            continue
        run_dirs = [REPO_ROOT / template.format(seed=seed) for seed in (42, 43, 44)]
        validation_rows = [read_jsonl(run_dir / "validation_predictions.jsonl") for run_dir in run_dirs]
        test_rows = [read_jsonl(run_dir / "test_predictions.jsonl") for run_dir in run_dirs]
        independently_recomputed = {
            "validation_f1": [
                binary_metrics(
                    [int(row["label_id"]) for row in values],
                    [int(row["predicted_label_id"]) for row in values],
                    [probability(row) for row in values],
                )["machine_f1"]
                for values in validation_rows
            ],
            "test_precision": [],
            "test_recall": [],
            "test_f1": [],
            "test_auroc": [],
        }
        for values in test_rows:
            metrics = binary_metrics(
                [int(row["label_id"]) for row in values],
                [int(row["predicted_label_id"]) for row in values],
                [probability(row) for row in values],
            )
            independently_recomputed["test_precision"].append(metrics["machine_precision"])
            independently_recomputed["test_recall"].append(metrics["machine_recall"])
            independently_recomputed["test_f1"].append(metrics["machine_f1"])
            independently_recomputed["test_auroc"].append(metrics["auroc"])
        fields = {
            **independently_recomputed,
            "runtime_seconds": [float(run["training_time_seconds"]) for run in runs],
        }
        row: dict[str, Any] = {
            "model": model,
            "visible_context_tokens": context,
            "rationale_budget_type": budget_type,
            "selected_token_budget": budget,
            "seeds": 3,
        }
        for name, values in fields.items():
            mean, sd = mean_sd(values)
            row[f"{name}_mean"] = mean
            row[f"{name}_sd"] = sd
        if budget_type != "none":
            selected = [float(run["test"]["rationales"]["average_selected_tokens"]) for run in runs]
            row["actual_selected_tokens_mean"] = statistics.mean(selected)
        else:
            row["actual_selected_tokens_mean"] = float(context)
        output.append(row)
    write_json(OUTPUT_ROOT / "missing_context_runs.json", missing)
    return output


def save_context_outputs(rows: list[dict[str, Any]]) -> None:
    write_json(OUTPUT_ROOT / "context_comparison.json", rows)
    if not rows:
        return
    csv_path = OUTPUT_ROOT / "context_comparison.csv"
    csv_path.parent.mkdir(parents=True, exist_ok=True)
    with csv_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)

    plot_dir = DOC_ROOT / "plots"
    plot_dir.mkdir(parents=True, exist_ok=True)
    for metric, title in (("validation_f1", "Validation F1"), ("test_f1", "Test F1")):
        fig, axis = plt.subplots(figsize=(8, 5))
        for model in sorted({row["model"] for row in rows}):
            subset = [row for row in rows if row["model"] == model and row["rationale_budget_type"] in ("none", "proportional")]
            if not subset:
                continue
            subset.sort(key=lambda row: row["visible_context_tokens"])
            axis.errorbar(
                [row["visible_context_tokens"] for row in subset],
                [row[f"{metric}_mean"] for row in subset],
                yerr=[row[f"{metric}_sd"] for row in subset],
                marker="o",
                capsize=3,
                label=model,
            )
        axis.set(xlabel="Maximum visible tokens", ylabel=title, title=f"{title} by context length")
        axis.legend(fontsize=8)
        fig.tight_layout()
        fig.savefig(plot_dir / f"{metric}_by_context.png", dpi=180)
        plt.close(fig)

    rationale = [row for row in rows if row["rationale_budget_type"] != "none"]
    fig, axis = plt.subplots(figsize=(8, 5))
    for row in rationale:
        axis.scatter(row["actual_selected_tokens_mean"], row["test_f1_mean"], s=45)
        axis.annotate(
            f"{row['model']} {row['visible_context_tokens']}/{row['selected_token_budget']}",
            (row["actual_selected_tokens_mean"], row["test_f1_mean"]),
            fontsize=7,
        )
    axis.set(xlabel="Mean selected-token count", ylabel="Test F1", title="Rationale F1 and actual retained evidence")
    fig.tight_layout()
    fig.savefig(plot_dir / "rationale_f1_by_selected_tokens.png", dpi=180)
    plt.close(fig)

    fig, axis = plt.subplots(figsize=(8, 5))
    for model in sorted({row["model"] for row in rows}):
        subset = sorted((row for row in rows if row["model"] == model), key=lambda row: row["visible_context_tokens"])
        if subset:
            axis.plot([row["visible_context_tokens"] for row in subset], [row["test_f1_sd"] for row in subset], marker="o", label=model)
    axis.set(xlabel="Maximum visible tokens", ylabel="Test F1 standard deviation", title="Seed variability")
    axis.legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(plot_dir / "seed_variability_by_context.png", dpi=180)
    plt.close(fig)

    gaps = []
    for context in (128, 256, 512):
        rationale_match = [row for row in rows if row["model"] == "HardKuma BiLSTM" and row["visible_context_tokens"] == context and row["selected_token_budget"] == "40%"]
        full_match = [row for row in rows if row["model"] == "Full-context BiLSTM" and row["visible_context_tokens"] == context]
        if rationale_match and full_match:
            gaps.append((context, full_match[0]["test_f1_mean"] - rationale_match[0]["test_f1_mean"]))
    if gaps:
        fig, axis = plt.subplots(figsize=(6, 4))
        axis.bar([str(value[0]) for value in gaps], [value[1] for value in gaps])
        axis.set(xlabel="Maximum visible tokens", ylabel="Full-context F1 minus rationale F1", title="Full-context performance gap")
        fig.tight_layout()
        fig.savefig(plot_dir / "full_context_rationale_gap.png", dpi=180)
        plt.close(fig)


def subgroup_metrics(rows: list[dict[str, Any]], test_metadata: dict[str, dict[str, Any]]) -> dict[str, Any]:
    enriched = []
    for row in rows:
        merged = {**test_metadata[str(row["id"])], **row}
        merged["original_token_count"] = len(tokenize(merged["text"]))
        merged["length_bucket"] = length_bucket(merged["original_token_count"])
        enriched.append(merged)

    def calculate(group: list[dict[str, Any]]) -> dict[str, Any]:
        result = binary_metrics(
            [int(row["label_id"]) for row in group],
            [int(row["predicted_label_id"]) for row in group],
            [probability(row) for row in group],
        )
        result["mean_confidence"] = statistics.mean(max(probability(row), 1.0 - probability(row)) for row in group) if group else None
        return result

    by_domain = {name: calculate([row for row in enriched if row["domain"] == name]) for name in ("abstracts", "books", "news", "poetry")}
    by_length = {name: calculate([row for row in enriched if row["length_bucket"] == name]) for name in ("1-128", "129-256", "257-512", ">512")}
    by_generator = {}
    human = [row for row in enriched if int(row["label_id"]) == 0]
    for generator in ("gpt2", "mistral", "mistral-chat", "llama-chat", "chatgpt", "gpt4"):
        machine = [row for row in enriched if row["generator"] == generator]
        combined = human + machine
        by_generator[generator] = {
            "machine_support": len(machine),
            "machine_recall": sum(int(row["predicted_label_id"]) == 1 for row in machine) / len(machine),
            "mean_machine_probability": statistics.mean(probability(row) for row in machine),
            "false_negatives": sum(int(row["predicted_label_id"]) == 0 for row in machine),
            "auroc_vs_all_human": float(roc_auc_score([int(row["label_id"]) for row in combined], [probability(row) for row in combined])),
        }
    return {"by_domain": by_domain, "by_generator": by_generator, "by_length": by_length}


def build_subgroups() -> dict[str, Any]:
    metadata = {str(row["id"]): row for row in read_jsonl(REPO_ROOT / "data/processed/raid_core_en_v3/test.jsonl")}
    models = selected_models()
    output = {}
    for name in ("tfidf", "hardkuma_512_t40", "full_context_bilstm_512"):
        output[name] = subgroup_metrics(read_jsonl(models[name] / "test_predictions.jsonl"), metadata)
    write_json(OUTPUT_ROOT / "subgroup_metrics.json", output)

    plot_dir = DOC_ROOT / "plots"
    domains = ("abstracts", "books", "news", "poetry")
    fig, axis = plt.subplots(figsize=(8, 5))
    width = 0.25
    x = np.arange(len(domains))
    for index, (name, values) in enumerate(output.items()):
        axis.bar(x + (index - 1) * width, [values["by_domain"][domain]["machine_f1"] for domain in domains], width, label=name)
    axis.set_xticks(x, domains)
    axis.set(ylabel="Machine F1", title="Test performance by domain")
    axis.legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(plot_dir / "domain_f1.png", dpi=180)
    plt.close(fig)

    generators = ("gpt2", "mistral", "mistral-chat", "llama-chat", "chatgpt", "gpt4")
    fig, axis = plt.subplots(figsize=(10, 5))
    x = np.arange(len(generators))
    for index, (name, values) in enumerate(output.items()):
        axis.bar(x + (index - 1) * width, [values["by_generator"][generator]["machine_recall"] for generator in generators], width, label=name)
    axis.set_xticks(x, generators, rotation=25)
    axis.set(ylabel="Machine recall", title="Test recall by generator")
    axis.legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(plot_dir / "generator_recall.png", dpi=180)
    plt.close(fig)
    return output


def transition_breakdown(rows_a: list[dict[str, Any]], rows_b: list[dict[str, Any]]) -> dict[str, Any]:
    pairs = list(zip(rows_a, rows_b, strict=True))
    def summary(items: list[tuple[dict[str, Any], dict[str, Any]]]) -> dict[str, int]:
        correct_a = [int(a["predicted_label_id"]) == int(a["label_id"]) for a, _ in items]
        correct_b = [int(b["predicted_label_id"]) == int(b["label_id"]) for _, b in items]
        return {
            "support": len(items),
            "both_correct": sum(a and b for a, b in zip(correct_a, correct_b, strict=True)),
            "b_corrects_a": sum((not a) and b for a, b in zip(correct_a, correct_b, strict=True)),
            "b_newly_breaks_a": sum(a and (not b) for a, b in zip(correct_a, correct_b, strict=True)),
            "both_incorrect": sum((not a) and (not b) for a, b in zip(correct_a, correct_b, strict=True)),
        }
    output = {"overall": summary(pairs), "by_domain": {}, "by_generator": {}, "by_length": {}}
    for domain in ("abstracts", "books", "news", "poetry"):
        output["by_domain"][domain] = summary([pair for pair in pairs if pair[0]["domain"] == domain])
    for generator in ("human", "gpt2", "mistral", "mistral-chat", "llama-chat", "chatgpt", "gpt4"):
        output["by_generator"][generator] = summary([pair for pair in pairs if pair[0]["generator"] == generator])
    for bucket in ("1-128", "129-256", "257-512", ">512"):
        output["by_length"][bucket] = summary([pair for pair in pairs if length_bucket(len(tokenize(pair[0]["text"]))) == bucket])
    return output


def paired_statistics() -> dict[str, Any]:
    comparisons = [
        ("hardkuma_256_t40", "hardkuma_512_t40"),
        ("hardkuma_512_fixed102", "hardkuma_512_t40"),
        ("hardkuma_512_t40", "full_context_bilstm_512"),
        ("full_context_bilstm_256", "full_context_bilstm_512"),
        ("tfidf", "hardkuma_512_t40"),
    ]
    output = {}
    models = selected_models()
    metadata = {str(row["id"]): row for row in read_jsonl(REPO_ROOT / "data/processed/raid_core_en_v3/test.jsonl")}
    for name_a, name_b in comparisons:
        by_a = predictions_by_id(models[name_a] / "test_predictions.jsonl")
        by_b = predictions_by_id(models[name_b] / "test_predictions.jsonl")
        ids = sorted(by_a)
        if set(ids) != set(by_b):
            raise ValueError(f"IDs do not align for {name_a}/{name_b}")
        rows_a = [{**metadata[value], **by_a[value]} for value in ids]
        rows_b = [{**metadata[value], **by_b[value]} for value in ids]
        truth = [int(row["label_id"]) for row in rows_a]
        pred_a = [int(row["predicted_label_id"]) for row in rows_a]
        pred_b = [int(row["predicted_label_id"]) for row in rows_b]
        output[f"{name_a}__vs__{name_b}"] = {
            "model_a": name_a,
            "model_b": name_b,
            "paired_bootstrap": paired_bootstrap_f1(truth, pred_a, pred_b),
            "mcnemar": exact_mcnemar(truth, pred_a, pred_b),
            "error_transitions": transition_breakdown(rows_a, rows_b),
        }
    write_json(OUTPUT_ROOT / "paired_statistics.json", output)
    return output


def describe(values: list[float]) -> dict[str, float]:
    array = np.asarray(values, dtype=float)
    return {
        "mean": float(array.mean()),
        "median": float(np.median(array)),
        "standard_deviation": float(array.std(ddof=1)),
        "q1": float(np.quantile(array, 0.25)),
        "q3": float(np.quantile(array, 0.75)),
    }


def stability_analysis() -> dict[str, Any]:
    mappings = {
        seed: predictions_by_id(REPO_ROOT / f"outputs/rationales/kuma_corrected_t40_len512_ratefix_s{seed}/test_predictions.jsonl")
        for seed in (42, 43, 44)
    }
    rows = []
    for example_id in sorted(mappings[42]):
        examples = [mappings[seed][example_id] for seed in (42, 43, 44)]
        index_sets = [set(row["selected_token_indices"]) for row in examples]
        jaccards, intersections, overlap_first, overlap_second = [], [], [], []
        rank_correlations = []
        for (left_index, left), (right_index, right) in combinations(enumerate(index_sets), 2):
            intersection = left & right
            union = left | right
            jaccards.append(len(intersection) / len(union) if union else 1.0)
            intersections.append(len(intersection))
            overlap_first.append(len(intersection) / len(left) if left else 1.0)
            overlap_second.append(len(intersection) / len(right) if right else 1.0)
            left_scores = examples[left_index]["token_gate_values"]
            right_scores = examples[right_index]["token_gate_values"]
            common_length = min(len(left_scores), len(right_scores))
            correlation = spearmanr(left_scores[:common_length], right_scores[:common_length]).statistic
            rank_correlations.append(float(correlation) if np.isfinite(correlation) else 0.0)
        probabilities = [probability(row) for row in examples]
        row = {
            "id": example_id,
            "label_id": int(examples[0]["label_id"]),
            "domain": examples[0]["domain"],
            "generator": examples[0]["generator"],
            "length_bucket": length_bucket(len(tokenize(examples[0]["text"]))),
            "correct_all_seeds": all(int(item["predicted_label_id"]) == int(item["label_id"]) for item in examples),
            "label_agreement": len({int(item["predicted_label_id"]) for item in examples}) == 1,
            "mean_pairwise_jaccard": statistics.mean(jaccards),
            "mean_pairwise_intersection_size": statistics.mean(intersections),
            "mean_pairwise_overlap_relative_to_rationale": statistics.mean(overlap_first + overlap_second),
            "pairwise_jaccards": jaccards,
            "pairwise_intersection_sizes": intersections,
            "pairwise_overlap_relative_to_first": overlap_first,
            "pairwise_overlap_relative_to_second": overlap_second,
            "three_way_intersection": len(set.intersection(*index_sets)),
            "three_way_union": len(set.union(*index_sets)),
            "probability_standard_deviation": statistics.stdev(probabilities),
            "mean_gate_rank_spearman": statistics.mean(rank_correlations),
            "confidence_bucket": confidence_bucket(statistics.mean(probabilities)),
        }
        rows.append(row)
    output: dict[str, Any] = {
        "scope": "lexical/token-index stability; not semantic equivalence",
        "support": len(rows),
        "label_agreement_rate": statistics.mean(row["label_agreement"] for row in rows),
        "jaccard": describe([row["mean_pairwise_jaccard"] for row in rows]),
        "pairwise_intersection_size": describe([row["mean_pairwise_intersection_size"] for row in rows]),
        "pairwise_overlap_relative_to_rationale": describe([row["mean_pairwise_overlap_relative_to_rationale"] for row in rows]),
        "three_way_intersection_size": describe([row["three_way_intersection"] for row in rows]),
        "three_way_union_size": describe([row["three_way_union"] for row in rows]),
        "probability_standard_deviation": describe([row["probability_standard_deviation"] for row in rows]),
        "gate_rank_spearman": describe([row["mean_gate_rank_spearman"] for row in rows]),
        "breakdowns": {},
    }
    breakdowns = {
        "correctness": lambda row: "all_correct" if row["correct_all_seeds"] else "at_least_one_incorrect",
        "label": lambda row: "machine" if row["label_id"] else "human",
        "domain": lambda row: row["domain"],
        "generator": lambda row: row["generator"],
        "length": lambda row: row["length_bucket"],
        "confidence": lambda row: row["confidence_bucket"],
    }
    for family, grouper in breakdowns.items():
        grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
        for row in rows:
            grouped[str(grouper(row))].append(row)
        output["breakdowns"][family] = {
            name: {
                "support": len(group),
                "label_agreement_rate": statistics.mean(item["label_agreement"] for item in group),
                "jaccard": describe([item["mean_pairwise_jaccard"] for item in group]),
                "probability_standard_deviation": describe([item["probability_standard_deviation"] for item in group]),
            }
            for name, group in grouped.items()
        }
    output["example_sets"] = {
        "high_label_low_overlap": [row["id"] for row in sorted((row for row in rows if row["label_agreement"]), key=lambda row: row["mean_pairwise_jaccard"])[:20]],
        "high_label_high_overlap": [row["id"] for row in sorted((row for row in rows if row["label_agreement"]), key=lambda row: row["mean_pairwise_jaccard"], reverse=True)[:20]],
        "label_disagreement": [row["id"] for row in rows if not row["label_agreement"]],
        "high_probability_variance": [row["id"] for row in sorted(rows, key=lambda row: row["probability_standard_deviation"], reverse=True)[:20]],
    }
    write_json(OUTPUT_ROOT / "rationale_stability.json", output)
    write_json(OUTPUT_ROOT / "rationale_stability_per_example.json", rows)
    fig, axes = plt.subplots(1, 2, figsize=(10, 4))
    axes[0].hist([row["mean_pairwise_jaccard"] for row in rows], bins=20)
    axes[0].set(xlabel="Mean pairwise Jaccard", ylabel="Examples", title="Lexical rationale overlap")
    axes[1].hist([row["probability_standard_deviation"] for row in rows], bins=20)
    axes[1].set(xlabel="Probability SD across seeds", ylabel="Examples", title="Prediction variability")
    fig.tight_layout()
    fig.savefig(DOC_ROOT / "plots/rationale_stability.png", dpi=180)
    plt.close(fig)
    return output


def calibration_analysis() -> dict[str, Any]:
    output = {}
    models = selected_models()
    test_probabilities: dict[str, list[float]] = {}
    for name in ("tfidf", "hardkuma_512_t40", "full_context_bilstm_512"):
        validation = read_jsonl(models[name] / "validation_predictions.jsonl")
        test = read_jsonl(models[name] / "test_predictions.jsonl")
        truth = [int(row["label_id"]) for row in test]
        probabilities = [probability(row) for row in test]
        test_probabilities[name] = probabilities
        output[name] = {
            "test_calibration": calibration_metrics(truth, probabilities, bins=10),
            "operating_points": [
                apply_operating_point(test, threshold_at_validation_fpr(validation, target))
                for target in (0.01, 0.05)
            ],
        }
    write_json(OUTPUT_ROOT / "calibration.json", output)
    fig, axis = plt.subplots(figsize=(6, 6))
    axis.plot([0, 1], [0, 1], linestyle="--", color="black", linewidth=1)
    for name, values in output.items():
        bins = [row for row in values["test_calibration"]["reliability"] if row["support"]]
        axis.plot([row["mean_probability"] for row in bins], [row["observed_machine_rate"] for row in bins], marker="o", label=name)
    axis.set(xlabel="Mean predicted machine probability", ylabel="Observed machine fraction", title="Test reliability (10 equal-width bins)")
    axis.legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(DOC_ROOT / "plots/calibration_reliability.png", dpi=180)
    plt.close(fig)
    fig, axis = plt.subplots(figsize=(7, 5))
    bins = np.linspace(0.5, 1.0, 21)
    for name, probabilities in test_probabilities.items():
        confidence = [max(value, 1.0 - value) for value in probabilities]
        axis.hist(confidence, bins=bins, histtype="step", linewidth=1.5, label=name)
    axis.set(xlabel="Predicted-class confidence", ylabel="Examples", title="Test confidence distributions")
    axis.legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(DOC_ROOT / "plots/confidence_histogram.png", dpi=180)
    plt.close(fig)
    return output


def write_csv_rows(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        fieldnames = list(dict.fromkeys(key for row in rows for key in row))
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def save_flat_analysis_tables(
    subgroups: dict[str, Any],
    paired: dict[str, Any],
    stability: dict[str, Any],
    calibration: dict[str, Any],
) -> None:
    subgroup_rows = []
    for model, families in subgroups.items():
        for family in ("by_domain", "by_generator", "by_length"):
            for group, metrics in families[family].items():
                subgroup_rows.append(
                    {
                        "model": model,
                        "group_family": family,
                        "group": group,
                        **{key: value for key, value in metrics.items() if not isinstance(value, (list, dict))},
                    }
                )
    write_csv_rows(OUTPUT_ROOT / "subgroup_metrics.csv", subgroup_rows)

    paired_rows = []
    for comparison, values in paired.items():
        bootstrap = values["paired_bootstrap"]
        mcnemar = values["mcnemar"]
        paired_rows.append(
            {
                "comparison": comparison,
                "model_a": values["model_a"],
                "model_b": values["model_b"],
                "f1_difference_b_minus_a": bootstrap["observed_difference"],
                "ci95_lower": bootstrap["confidence_interval_95"][0],
                "ci95_upper": bootstrap["confidence_interval_95"][1],
                "bootstrap_resamples": bootstrap["resamples"],
                "mcnemar_exact_p": mcnemar["exact_two_sided_p_value"],
                "both_correct": mcnemar["both_correct"],
                "b_corrects_a": mcnemar["b_only_correct_b_corrects_a"],
                "b_breaks_a": mcnemar["a_only_correct_b_newly_broken"],
                "both_incorrect": mcnemar["both_incorrect"],
            }
        )
    write_csv_rows(OUTPUT_ROOT / "paired_statistics.csv", paired_rows)

    stability_rows = []
    for family, groups in stability["breakdowns"].items():
        for group, metrics in groups.items():
            stability_rows.append(
                {
                    "group_family": family,
                    "group": group,
                    "support": metrics["support"],
                    "label_agreement_rate": metrics["label_agreement_rate"],
                    "jaccard_mean": metrics["jaccard"]["mean"],
                    "jaccard_median": metrics["jaccard"]["median"],
                    "probability_sd_mean": metrics["probability_standard_deviation"]["mean"],
                }
            )
    write_csv_rows(OUTPUT_ROOT / "rationale_stability_breakdowns.csv", stability_rows)

    calibration_rows = []
    for model, values in calibration.items():
        metrics = values["test_calibration"]
        for operating in values["operating_points"]:
            calibration_rows.append(
                {
                    "model": model,
                    "brier_score": metrics["brier_score"],
                    "negative_log_likelihood": metrics["negative_log_likelihood"],
                    "ece": metrics["expected_calibration_error"],
                    "mce": metrics["maximum_calibration_error"],
                    **operating,
                }
            )
    write_csv_rows(OUTPUT_ROOT / "calibration_operating_points.csv", calibration_rows)


def main() -> None:
    parser = argparse.ArgumentParser(description="Derive final analyses from saved, validation-selected predictions.")
    parser.add_argument("--allow-missing-128", action="store_true", help="Generate partial context outputs before 128-token runs finish.")
    args = parser.parse_args()
    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)
    (DOC_ROOT / "plots").mkdir(parents=True, exist_ok=True)
    context = build_context_table()
    if not args.allow_missing_128 and len(context) != len(CONTEXT_RUNS):
        raise FileNotFoundError("Context table is incomplete; run after all 128-token jobs finish or pass --allow-missing-128")
    save_context_outputs(context)
    subgroups = build_subgroups()
    paired = paired_statistics()
    stability = stability_analysis()
    calibration = calibration_analysis()
    save_flat_analysis_tables(subgroups, paired, stability, calibration)
    write_json(
        OUTPUT_ROOT / "saved_prediction_analysis_summary.json",
        {
            "context_rows": len(context),
            "subgroup_models": list(subgroups),
            "paired_comparisons": list(paired),
            "stability_support": stability["support"],
            "calibration_models": list(calibration),
        },
    )
    print(f"Saved analyses to {OUTPUT_ROOT} and plots to {DOC_ROOT / 'plots'}")


if __name__ == "__main__":
    main()
