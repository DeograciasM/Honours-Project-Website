from __future__ import annotations

import argparse
import math
import random
import statistics
import sys
from collections import defaultdict
from pathlib import Path
from typing import Any

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch

REPO_ROOT = Path(__file__).resolve().parents[2]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from detectgpt.data.io import load_dataset_splits
from detectgpt.rationales.vocab import tokenize
from detectgpt.utils.device import DEVICE_CHOICES, resolve_device
from scripts.evaluate_rationale_strategies import load_model
from scripts.legacy.pre_surface_analysis.common import binary_metrics, predictions_by_id, probability, read_json, read_jsonl, write_json, write_jsonl
from scripts.train_kuma_rationale import TokenDataset, make_loader


OUTPUT_ROOT = REPO_ROOT / "outputs/archive/pre_surface_final_analysis/hardkuma_diagnostics"
DOC_ROOT = REPO_ROOT / "docs/archive/pre_surface_final_analysis/plots"
RETENTION_FRACTIONS = (0.10, 0.20, 0.30, 0.40, 0.50, 1.00)
DELETION_FRACTIONS = (0.10, 0.20, 0.30, 0.40, 0.50)
CONTROL_RANDOM_SEEDS = (3101, 3102, 3103, 3104, 3105)
CURVE_RANDOM_SEEDS = (4101, 4102, 4103)


def deterministic_indices(
    strategy: str,
    gate_values: list[float],
    valid_count: int,
    count: int,
    *,
    example_id: str,
    random_seed: int | None = None,
) -> list[int]:
    count = min(valid_count, max(1, count))
    if strategy == "learned":
        return sorted(sorted(range(valid_count), key=lambda index: (-gate_values[index], index))[:count])
    if strategy == "first":
        return list(range(count))
    if strategy == "last":
        return list(range(valid_count - count, valid_count))
    if strategy == "random":
        if random_seed is None:
            raise ValueError("random strategy requires a seed")
        rng = random.Random(f"{random_seed}:{example_id}")
        return sorted(rng.sample(range(valid_count), count))
    raise ValueError(strategy)


def probability_metrics(records: list[dict[str, Any]], key: str) -> dict[str, Any]:
    truth = [int(record["label_id"]) for record in records]
    probabilities = [float(record[key]) for record in records]
    predictions = [int(value >= 0.5) for value in probabilities]
    result = binary_metrics(truth, predictions, probabilities)
    result.update(
        {
            "mean_predicted_class_probability": statistics.mean(max(value, 1.0 - value) for value in probabilities),
            "mean_true_class_probability": statistics.mean(value if label else 1.0 - value for label, value in zip(truth, probabilities, strict=True)),
            "correct_examples": sum(label == prediction for label, prediction in zip(truth, predictions, strict=True)),
        }
    )
    return result


def evaluate_run(
    run_dir: Path,
    device: torch.device,
    batch_size: int,
    limit_test: int | None = None,
) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    model, vocab, config = load_model(run_dir, device)
    rows = load_dataset_splits(Path(config["data_dir"]), ("test",))["test"]
    if limit_test is not None:
        rows = rows[:limit_test]
    loader = make_loader(TokenDataset(rows, vocab, max_tokens=512), batch_size, False, int(config["seed"]), vocab.pad_id)
    records: dict[str, dict[str, Any]] = {
        str(row["id"]): {
            "id": str(row["id"]),
            "label_id": int(row["label_id"]),
            "domain": row["domain"],
            "generator": row["generator"],
            "original_token_count": len(tokenize(row["text"])),
        }
        for row in rows
    }

    with torch.no_grad():
        for batch in loader:
            input_ids = batch["input_ids"].to(device)
            mask = batch["mask"].to(device)
            embeddings = model.embed_tokens(input_ids)
            a, b = model.gate_parameters(embeddings, mask)
            deterministic = model.deterministic_gates(a, b, mask)
            expected = model.expected_selection(a, b, mask)
            gate_rows = deterministic.cpu().tolist()
            expected_rows = expected.cpu().tolist()
            mask_rows = mask.cpu().tolist()
            examples = batch["examples"]

            for local, example in enumerate(examples):
                example_id = str(example.row["id"])
                valid_count = int(sum(mask_rows[local]))
                raw_selected = [index for index, value in enumerate(gate_rows[local][:valid_count]) if value >= 0.5]
                records[example_id].update(
                    {
                        "visible_token_count": valid_count,
                        "expected_nonzero_rate": sum(expected_rows[local][:valid_count]) / valid_count,
                        "deterministic_gate_mean": sum(gate_rows[local][:valid_count]) / valid_count,
                        "raw_threshold_selected_count": len(raw_selected),
                        "raw_threshold_selection_rate": len(raw_selected) / valid_count,
                        "raw_threshold_zero_selection": len(raw_selected) == 0,
                    }
                )

            mask_specs: list[tuple[str, list[list[int]]]] = []
            for fraction in RETENTION_FRACTIONS:
                requested = [math.ceil(fraction * int(sum(mask_row))) for mask_row in mask_rows]
                for strategy in ("learned", "first", "last"):
                    indices = [
                        deterministic_indices(strategy, gate_rows[i], int(sum(mask_rows[i])), requested[i], example_id=str(examples[i].row["id"]))
                        for i in range(len(examples))
                    ]
                    mask_specs.append((f"retain_{fraction:.2f}_{strategy}", indices))
                for random_seed in CURVE_RANDOM_SEEDS:
                    indices = [
                        deterministic_indices("random", gate_rows[i], int(sum(mask_rows[i])), requested[i], example_id=str(examples[i].row["id"]), random_seed=random_seed)
                        for i in range(len(examples))
                    ]
                    mask_specs.append((f"retain_{fraction:.2f}_random_{random_seed}", indices))

            requested_40 = [math.ceil(0.40 * int(sum(mask_row))) for mask_row in mask_rows]
            for random_seed in CONTROL_RANDOM_SEEDS:
                indices = [
                    deterministic_indices("random", gate_rows[i], int(sum(mask_rows[i])), requested_40[i], example_id=str(examples[i].row["id"]), random_seed=random_seed)
                    for i in range(len(examples))
                ]
                mask_specs.append((f"control_random_{random_seed}", indices))

            full_indices = [list(range(int(sum(mask_row)))) for mask_row in mask_rows]
            mask_specs.append(("full_visible", full_indices))
            raw_indices = [
                [index for index, value in enumerate(gate_rows[i][: int(sum(mask_rows[i]))]) if value >= 0.5]
                for i in range(len(examples))
            ]
            mask_specs.append(("raw_threshold", raw_indices))

            for fraction in DELETION_FRACTIONS:
                requested = [math.ceil(fraction * int(sum(mask_row))) for mask_row in mask_rows]
                for strategy in ("learned",):
                    retained = []
                    for i in range(len(examples)):
                        valid_count = int(sum(mask_rows[i]))
                        removed = set(deterministic_indices(strategy, gate_rows[i], valid_count, requested[i], example_id=str(examples[i].row["id"])))
                        retained.append([index for index in range(valid_count) if index not in removed])
                    mask_specs.append((f"delete_{fraction:.2f}_{strategy}", retained))
                for random_seed in CURVE_RANDOM_SEEDS:
                    retained = []
                    for i in range(len(examples)):
                        valid_count = int(sum(mask_rows[i]))
                        removed = set(deterministic_indices("random", gate_rows[i], valid_count, requested[i], example_id=str(examples[i].row["id"]), random_seed=random_seed))
                        retained.append([index for index in range(valid_count) if index not in removed])
                    mask_specs.append((f"delete_{fraction:.2f}_random_{random_seed}", retained))

            for name, selected_by_example in mask_specs:
                hard_mask = torch.zeros_like(deterministic)
                for local, selected in enumerate(selected_by_example):
                    if selected:
                        hard_mask[local, selected] = 1.0
                probabilities = torch.softmax(model.predict_from_gates(embeddings, hard_mask, mask), dim=1)[:, 1].cpu().tolist()
                for local, (example, selected, value) in enumerate(zip(examples, selected_by_example, probabilities, strict=True)):
                    example_id = str(example.row["id"])
                    records[example_id][f"probability_{name}"] = float(value)
                    records[example_id][f"count_{name}"] = len(selected)
                    if name in {
                        "retain_0.40_learned",
                        "retain_0.40_first",
                        "retain_0.40_last",
                    } or name.startswith("control_random_"):
                        records[example_id][f"indices_{name}"] = selected
                        records[example_id][f"predicted_label_{name}"] = int(value >= 0.5)

    per_example = [records[str(row["id"])] for row in rows]
    controls: dict[str, Any] = {}
    for strategy in ("learned", "first", "last"):
        key = f"probability_retain_0.40_{strategy}"
        controls[strategy] = probability_metrics(per_example, key)
    random_replicates = {
        str(seed): probability_metrics(per_example, f"probability_control_random_{seed}")
        for seed in CONTROL_RANDOM_SEEDS
    }
    for record in per_example:
        record["probability_control_random_mean"] = statistics.mean(record[f"probability_control_random_{seed}"] for seed in CONTROL_RANDOM_SEEDS)
    controls["random_mean_probability"] = probability_metrics(per_example, "probability_control_random_mean")
    controls["random_replicates"] = random_replicates

    retention = {}
    for fraction in RETENTION_FRACTIONS:
        fraction_key = f"{fraction:.2f}"
        retention[fraction_key] = {}
        for strategy in ("learned", "first", "last"):
            retention[fraction_key][strategy] = probability_metrics(per_example, f"probability_retain_{fraction:.2f}_{strategy}")
        for record in per_example:
            record[f"probability_retain_{fraction:.2f}_random_mean"] = statistics.mean(
                record[f"probability_retain_{fraction:.2f}_random_{seed}"] for seed in CURVE_RANDOM_SEEDS
            )
        retention[fraction_key]["random_mean_probability"] = probability_metrics(per_example, f"probability_retain_{fraction:.2f}_random_mean")
        retention[fraction_key]["average_selected_tokens"] = statistics.mean(record[f"count_retain_{fraction:.2f}_learned"] for record in per_example)
        retention[fraction_key]["zero_fallbacks"] = 0

    deletion = {}
    full_predictions = [int(record["probability_full_visible"] >= 0.5) for record in per_example]
    for fraction in DELETION_FRACTIONS:
        fraction_key = f"{fraction:.2f}"
        deletion[fraction_key] = {}
        for strategy in ("learned",):
            key = f"probability_delete_{fraction:.2f}_{strategy}"
            metrics = probability_metrics(per_example, key)
            values = [record[key] for record in per_example]
            metrics.update(
                {
                    "mean_change_in_full_predicted_class_probability": statistics.mean(
                        (value if full_pred else 1 - value) - (record["probability_full_visible"] if full_pred else 1 - record["probability_full_visible"])
                        for record, value, full_pred in zip(per_example, values, full_predictions, strict=True)
                    ),
                    "mean_change_in_true_class_probability": statistics.mean(
                        (value if record["label_id"] else 1 - value) - (record["probability_full_visible"] if record["label_id"] else 1 - record["probability_full_visible"])
                        for record, value in zip(per_example, values, strict=True)
                    ),
                    "label_flip_rate": statistics.mean(int(value >= 0.5) != full_pred for value, full_pred in zip(values, full_predictions, strict=True)),
                }
            )
            deletion[fraction_key][strategy] = metrics
        for record in per_example:
            record[f"probability_delete_{fraction:.2f}_random_mean"] = statistics.mean(
                record[f"probability_delete_{fraction:.2f}_random_{seed}"] for seed in CURVE_RANDOM_SEEDS
            )
        key = f"probability_delete_{fraction:.2f}_random_mean"
        random_metrics = probability_metrics(per_example, key)
        random_values = [record[key] for record in per_example]
        random_metrics.update(
            {
                "mean_change_in_full_predicted_class_probability": statistics.mean(
                    (value if full_pred else 1 - value) - (record["probability_full_visible"] if full_pred else 1 - record["probability_full_visible"])
                    for record, value, full_pred in zip(per_example, random_values, full_predictions, strict=True)
                ),
                "mean_change_in_true_class_probability": statistics.mean(
                    (value if record["label_id"] else 1 - value) - (record["probability_full_visible"] if record["label_id"] else 1 - record["probability_full_visible"])
                    for record, value in zip(per_example, random_values, strict=True)
                ),
                "label_flip_rate": statistics.mean(int(value >= 0.5) != full_pred for value, full_pred in zip(random_values, full_predictions, strict=True)),
            }
        )
        deletion[fraction_key]["random_mean_probability"] = random_metrics

    raw = probability_metrics(per_example, "probability_raw_threshold")
    raw.update(
        {
            "average_selected_tokens": statistics.mean(record["raw_threshold_selected_count"] for record in per_example),
            "average_selection_rate": statistics.mean(record["raw_threshold_selection_rate"] for record in per_example),
            "zero_selection_count": sum(record["raw_threshold_zero_selection"] for record in per_example),
            "fallback_used": False,
        }
    )
    controller = {
        "nominal_target_rate": 0.40,
        "analytical_expected_nonzero_rate": {
            "mean": statistics.mean(record["expected_nonzero_rate"] for record in per_example),
            "median": statistics.median(record["expected_nonzero_rate"] for record in per_example),
            "standard_deviation": statistics.stdev(record["expected_nonzero_rate"] for record in per_example),
        },
        "deterministic_topk_rate": {
            "mean": statistics.mean(record["count_retain_0.40_learned"] / record["visible_token_count"] for record in per_example),
            "median": statistics.median(record["count_retain_0.40_learned"] / record["visible_token_count"] for record in per_example),
        },
        "signed_expected_rate_error": statistics.mean(record["expected_nonzero_rate"] for record in per_example) - 0.40,
        "absolute_expected_rate_error": abs(statistics.mean(record["expected_nonzero_rate"] for record in per_example) - 0.40),
        "zero_selection_fallback_count": 0,
        "raw_deterministic_gate": raw,
        "validation_f1": float(read_json(run_dir / "metrics.json")["validation"]["overall"]["machine_f1"]),
        "test_f1": controls["learned"]["machine_f1"],
        "test_auroc": controls["learned"]["auroc"],
    }
    curve_auc = {
        "definition": "trapezoidal area of test F1, normalized by the evaluated fraction interval",
        "retention": {
            strategy: float(
                np.trapezoid(
                    [retention[f"{fraction:.2f}"][strategy]["machine_f1"] for fraction in RETENTION_FRACTIONS],
                    RETENTION_FRACTIONS,
                )
                / (RETENTION_FRACTIONS[-1] - RETENTION_FRACTIONS[0])
            )
            for strategy in ("learned", "random_mean_probability", "first", "last")
        },
        "deletion": {
            strategy: float(
                np.trapezoid(
                    [deletion[f"{fraction:.2f}"][strategy]["machine_f1"] for fraction in DELETION_FRACTIONS],
                    DELETION_FRACTIONS,
                )
                / (DELETION_FRACTIONS[-1] - DELETION_FRACTIONS[0])
            )
            for strategy in ("learned", "random_mean_probability")
        },
    }
    summary = {
        "run": run_dir.name,
        "checkpoint": str(run_dir / "model.pt"),
        "device": str(device),
        "random_control_seeds": CONTROL_RANDOM_SEEDS,
        "curve_random_seeds": CURVE_RANDOM_SEEDS,
        "controls_40_percent": controls,
        "retention": retention,
        "deletion": deletion,
        "controller": controller,
        "curve_auc": curve_auc,
        "posthoc_warning": "Only the 40% model was trained; all other retention/deletion budgets are evaluation-only ranking diagnostics.",
    }
    return summary, per_example


def evaluate_fixed_controller(
    run_dir: Path,
    device: torch.device,
    batch_size: int,
    limit_test: int | None = None,
) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    model, vocab, config = load_model(run_dir, device)
    rows = load_dataset_splits(Path(config["data_dir"]), ("test",))["test"]
    if limit_test is not None:
        rows = rows[:limit_test]
    loader = make_loader(TokenDataset(rows, vocab, max_tokens=512), batch_size, False, int(config["seed"]), vocab.pad_id)
    saved = predictions_by_id(run_dir / "test_predictions.jsonl")
    records = []
    with torch.no_grad():
        for batch in loader:
            input_ids = batch["input_ids"].to(device)
            mask = batch["mask"].to(device)
            embeddings = model.embed_tokens(input_ids)
            a, b = model.gate_parameters(embeddings, mask)
            deterministic = model.deterministic_gates(a, b, mask)
            expected = model.expected_selection(a, b, mask)
            raw_mask = (deterministic >= 0.5) & mask
            raw_probabilities = torch.softmax(model.predict_from_gates(embeddings, raw_mask.float(), mask), dim=1)[:, 1].cpu().tolist()
            for local, (example, raw_probability) in enumerate(zip(batch["examples"], raw_probabilities, strict=True)):
                example_id = str(example.row["id"])
                valid_count = int(mask[local].sum().item())
                saved_row = saved[example_id]
                raw_count = int(raw_mask[local].sum().item())
                records.append(
                    {
                        "id": example_id,
                        "label_id": int(example.row["label_id"]),
                        "visible_token_count": valid_count,
                        "expected_nonzero_rate": float(expected[local, :valid_count].mean().item()),
                        "deterministic_selected_count": len(saved_row["selected_token_indices"]),
                        "deterministic_selection_rate": float(saved_row["selected_fraction"]),
                        "probability_topk_fixed102": probability(saved_row),
                        "raw_threshold_selected_count": raw_count,
                        "raw_threshold_selection_rate": raw_count / valid_count,
                        "raw_threshold_zero_selection": raw_count == 0,
                        "probability_raw_threshold": float(raw_probability),
                    }
                )
    expected_mean = statistics.mean(record["expected_nonzero_rate"] for record in records)
    deterministic_mean = statistics.mean(record["deterministic_selection_rate"] for record in records)
    topk = probability_metrics(records, "probability_topk_fixed102")
    raw = probability_metrics(records, "probability_raw_threshold")
    raw.update(
        {
            "average_selected_tokens": statistics.mean(record["raw_threshold_selected_count"] for record in records),
            "average_selection_rate": statistics.mean(record["raw_threshold_selection_rate"] for record in records),
            "zero_selection_count": sum(record["raw_threshold_zero_selection"] for record in records),
            "fallback_used": False,
        }
    )
    summary = {
        "run": run_dir.name,
        "checkpoint": str(run_dir / "model.pt"),
        "mechanism": "deterministic fixed-count top-k over HardKuma gate ranking",
        "nominal_fixed_count": 102,
        "nominal_full_window_fraction": 102 / 512,
        "actual_deterministic_selected_count_mean": statistics.mean(record["deterministic_selected_count"] for record in records),
        "actual_deterministic_selected_fraction_mean": deterministic_mean,
        "analytical_expected_nonzero_rate_mean": expected_mean,
        "expected_minus_deterministic_rate": expected_mean - deterministic_mean,
        "zero_selection_fallback_count": 0,
        "topk_metrics": topk,
        "raw_deterministic_gate": raw,
        "validation_f1": float(read_json(run_dir / "metrics.json")["validation"]["overall"]["machine_f1"]),
        "warning": "19.92% is only 102/512. Shorter documents are capped, so their deterministic fraction is larger; analytical expected sparsity is a separate quantity.",
    }
    return summary, records


def aggregate_runs(summaries: list[dict[str, Any]]) -> dict[str, Any]:
    output: dict[str, Any] = {"runs": [summary["run"] for summary in summaries], "controls_40_percent": {}}
    for strategy in ("learned", "random_mean_probability", "first", "last"):
        output["controls_40_percent"][strategy] = {}
        for metric in ("machine_precision", "machine_recall", "machine_f1", "auroc", "mean_predicted_class_probability", "correct_examples"):
            values = [float(summary["controls_40_percent"][strategy][metric]) for summary in summaries]
            output["controls_40_percent"][strategy][f"{metric}_mean"] = statistics.mean(values)
            output["controls_40_percent"][strategy][f"{metric}_sd"] = statistics.stdev(values)
    learned = output["controls_40_percent"]["learned"]
    output["learned_minus_control_f1"] = {
        strategy: learned["machine_f1_mean"] - output["controls_40_percent"][strategy]["machine_f1_mean"]
        for strategy in ("random_mean_probability", "first", "last")
    }
    return output


def plot_curves(summaries: list[dict[str, Any]]) -> None:
    DOC_ROOT.mkdir(parents=True, exist_ok=True)
    fig, axis = plt.subplots(figsize=(7, 5))
    for strategy in ("learned", "random_mean_probability", "first", "last"):
        means = [statistics.mean(summary["retention"][f"{fraction:.2f}"][strategy]["machine_f1"] for summary in summaries) for fraction in RETENTION_FRACTIONS]
        axis.plot(RETENTION_FRACTIONS, means, marker="o", label=strategy)
    axis.set(xlabel="Retained fraction", ylabel="Mean test F1", title="Post-hoc retention curves")
    axis.legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(DOC_ROOT / "retention_curves.png", dpi=180)
    plt.close(fig)

    fig, axis = plt.subplots(figsize=(7, 5))
    for strategy in ("learned", "random_mean_probability"):
        means = [statistics.mean(summary["deletion"][f"{fraction:.2f}"][strategy]["machine_f1"] for summary in summaries) for fraction in DELETION_FRACTIONS]
        axis.plot(DELETION_FRACTIONS, means, marker="o", label=strategy)
    axis.set(xlabel="Deleted fraction", ylabel="Mean test F1", title="Post-hoc deletion curves")
    axis.legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(DOC_ROOT / "deletion_curves.png", dpi=180)
    plt.close(fig)


def plot_controller_distributions(records: list[dict[str, Any]]) -> None:
    DOC_ROOT.mkdir(parents=True, exist_ok=True)
    fig, axes = plt.subplots(1, 2, figsize=(10, 4))
    for seed in (42, 43, 44):
        subset = [record for record in records if record["seed"] == seed]
        axes[0].hist([record["expected_nonzero_rate"] for record in subset], bins=20, alpha=0.4, label=f"seed {seed}")
        axes[1].hist(
            [record["count_retain_0.40_learned"] / record["visible_token_count"] for record in subset],
            bins=20,
            alpha=0.4,
            label=f"seed {seed}",
        )
    axes[0].set(xlabel="Analytical expected non-zero rate", ylabel="Examples", title="Expected HardKuma rates")
    axes[1].set(xlabel="Deterministic top-k fraction", ylabel="Examples", title="Budgeted inference rates")
    for axis in axes:
        axis.legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(DOC_ROOT / "controller_rate_distributions.png", dpi=180)
    plt.close(fig)

def main() -> None:
    parser = argparse.ArgumentParser(description="Evaluate HardKuma controls, post-hoc curves, and controller diagnostics.")
    parser.add_argument("--device", default="auto", choices=DEVICE_CHOICES)
    parser.add_argument("--batch-size", default=32, type=int)
    args = parser.parse_args()
    device = resolve_device(args.device)
    summaries = []
    all_records = []
    for seed in (42, 43, 44):
        run_dir = REPO_ROOT / f"outputs/rationales/kuma_corrected_t40_len512_ratefix_s{seed}"
        summary, records = evaluate_run(run_dir, device, args.batch_size)
        write_json(OUTPUT_ROOT / f"{run_dir.name}.json", summary)
        write_jsonl(OUTPUT_ROOT / f"{run_dir.name}_per_example.jsonl", records)
        summaries.append(summary)
        all_records.extend({"seed": seed, **record} for record in records)
        print(f"completed diagnostics for {run_dir.name}")
    aggregate = aggregate_runs(summaries)
    write_json(OUTPUT_ROOT / "aggregate.json", aggregate)
    write_jsonl(OUTPUT_ROOT / "per_example_all_seeds.jsonl", all_records)
    selected_seed = max(
        zip((42, 43, 44), summaries, strict=True),
        key=lambda item: item[1]["validation_f1"],
    )[0]
    # Only the validation-selected rate-fixed checkpoint feeds the unified export.
    selected_records = [record for record in all_records if record["seed"] == selected_seed]
    write_jsonl(OUTPUT_ROOT / "per_example_controller.jsonl", selected_records)
    fixed_summaries = []
    for seed in (42, 43, 44):
        run_dir = REPO_ROOT / f"outputs/rationales/kuma_corrected_fixed102_len512_ratefix_s{seed}"
        fixed_summary, fixed_records = evaluate_fixed_controller(run_dir, device, args.batch_size)
        write_json(OUTPUT_ROOT / f"{run_dir.name}_controller.json", fixed_summary)
        write_jsonl(OUTPUT_ROOT / f"{run_dir.name}_controller_per_example.jsonl", fixed_records)
        fixed_summaries.append(fixed_summary)
        print(f"completed controller diagnostics for {run_dir.name}")
    write_json(
        OUTPUT_ROOT / "fixed102_controller_aggregate.json",
        {
            "runs": [summary["run"] for summary in fixed_summaries],
            "nominal_fixed_count": 102,
            "nominal_full_window_fraction": 102 / 512,
            "actual_selected_count_mean": statistics.mean(summary["actual_deterministic_selected_count_mean"] for summary in fixed_summaries),
            "actual_selected_fraction_mean": statistics.mean(summary["actual_deterministic_selected_fraction_mean"] for summary in fixed_summaries),
            "analytical_expected_rate_mean": statistics.mean(summary["analytical_expected_nonzero_rate_mean"] for summary in fixed_summaries),
            "zero_selection_fallback_count": sum(summary["zero_selection_fallback_count"] for summary in fixed_summaries),
            "mechanism_warning": fixed_summaries[0]["warning"],
        },
    )
    plot_curves(summaries)
    plot_controller_distributions(all_records)
    print(f"Saved diagnostics to {OUTPUT_ROOT}")


if __name__ == "__main__":
    main()
