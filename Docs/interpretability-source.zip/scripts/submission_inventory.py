#!/usr/bin/env python3
"""Audit the examiner submission allowlist without creating an archive."""
from __future__ import annotations

import argparse
import gc
import hashlib
import json
import sys
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
MODEL_ROOT = ROOT / "artifacts/models"
MODEL_MANIFEST = ROOT / "artifacts/model_manifest.json"
CHECKSUMS = ROOT / "artifacts/SUBMISSION_CHECKSUMS.sha256"

INCLUDED_FILES = {
    ".gitignore",
    "Makefile",
    "README.md",
    "pyproject.toml",
    "requirements.txt",
    "requirements-data.txt",
    "requirements-dev.txt",
    "requirements-test.txt",
    "configs/final/bilstm_full.toml",
    "configs/final/bilstm_hardkuma.toml",
    "configs/final/tfidf.toml",
    "configs/final/transformer_full.toml",
    "configs/final/transformer_rationale.toml",
    "data/manifests/raid_en_balanced.json",
    "data/processed/raid_en_balanced/stats.json",
    "human_study_analysis/.Rprofile",
    "human_study_analysis/R_REQUIREMENTS.txt",
    "human_study_analysis/renv.lock",
    "human_study_analysis/renv/activate.R",
    "human_study_analysis/renv/settings.json",
    "human_study_analysis/scripts/bootstrap_renv.R",
    "human_study_analysis/scripts/run_lean_analysis.R",
    "results/final/figures/budget_sweep.pdf",
    "results/final/figures/context_sweep.pdf",
    "results/final/manifests/freeze_manifest.json",
    "results/final/metrics/bilstm_rationale_controls.json",
    "results/final/metrics/cross_seed_stability.json",
    "results/final/metrics/final_results.csv",
    "results/final/metrics/stage1_aggregate.csv",
    "results/final/metrics/stage2_aggregate.csv",
    "results/final/metrics/statistical_comparisons.json",
    "results/final/metrics/transformer_full_summary.csv",
    "results/final/metrics/transformer_rationale_summary.csv",
    "results/final/tables/domain_breakdown.csv",
    "results/final/tables/generator_breakdown.csv",
    "results/final/tables/length_breakdown.csv",
    "results/human_study/aggregate/condition_counts.csv",
    "results/human_study/aggregate/descriptive_by_condition.csv",
    "results/human_study/aggregate/model_adjusted_probabilities.csv",
    "results/human_study/aggregate/model_planned_contrasts.csv",
    "results/human_study/aggregate/publication_table_human_study.csv",
    "scripts/analysis/generate_sweep_figures.py",
    "scripts/build_raid_en_balanced.py",
    "scripts/check_source_leakage.py",
    "scripts/evaluate_rationale_strategies.py",
    "scripts/evaluate_transformer.py",
    "scripts/prepare_final_evaluation.py",
    "scripts/run_final_evaluation.py",
    "scripts/train_full_context_bilstm.py",
    "scripts/train_kuma_rationale.py",
    "scripts/train_surface_tfidf.py",
    "scripts/train_transformer_full_context.py",
    "scripts/train_transformer_rationale.py",
    "scripts/validate_raid_en_balanced.py",
    "tests/conftest.py",
    "tests/test_auroc_reporting.py",
    "tests/test_device.py",
    "tests/test_transformer_model.py",
}
INCLUDED_PREFIXES = (
    "artifacts/models/",
    "src/detectgpt/",
    "tests/rationales/",
)
EXCLUDED_PREFIXES = (
    ".cleanup_quarantine/",
    ".git/",
    ".venv/",
    "Form Responses/",
    "data/embeddings/",
    "docs/archive/",
    "human_study_analysis/r_library/",
    "human_study_analysis/renv/library/",
    "human_study_analysis/reports/",
    "kaggle_downloads/",
    "kaggle_packages/",
    "outputs/",
)
EXCLUDED_EXACT = {
    "docs/submission_snapshot_2026_09_17.md",
    "human_study_analysis/processed/participants.csv",
    "human_study_analysis/processed/responses_long.csv",
    "human_study_analysis/raw_manifest.csv",
}
EXCLUDED_SUFFIXES = (".pyc", ".rds", ".jsonl")
EXCLUDED_PARTS = {".ipynb_checkpoints", ".mypy_cache", ".pytest_cache", ".ruff_cache", "__pycache__"}

EXPECTED_CHECKPOINTS = {
    "tfidf/model.joblib": "0fd38ac6fa2de49e06a231c933227f090d0ffff5783431cba77b210efc8b9817",
    "bilstm_full/seed42/model.pt": "cb722b6f979fce444be66af7ea4cbf3d1df6aa980901952a5c9d830597536141",
    "bilstm_full/seed43/model.pt": "5a857c51378c25dd4ba7ddd3527f45d58a136419ed570f8478cd8f5d6fc0b4fa",
    "bilstm_full/seed44/model.pt": "11a0b7995f3aabb679abf325af803cd2d98de3f7a295dd71ba3738f1bea03b13",
    "bilstm_hardkuma/seed42/model.pt": "2a17cc7c7a960c8dd35f31e1cd0669754dfceb0c3e395d98e2f8e0ef15caf1cb",
    "bilstm_hardkuma/seed43/model.pt": "4316b295ac17c7b736b826c7c648916f853aff4b2fbc19138627f70c13b69337",
    "bilstm_hardkuma/seed44/model.pt": "c5719cb44822e4bb6c4f001356040b9bd8465c9152bf8831d6a16fb71276a7cc",
    "transformer_full/seed42/model.pt": "bb2fcddf66f3a095d76919093d26729ad9e9cc012f8ff69a9b1d46ab51cca3bc",
    "transformer_full/seed43/model.pt": "26f1434e0d59824430995873f0b73bb86a52263be42c43aa0957ba14e5ad871a",
    "transformer_full/seed44/model.pt": "8ae8c36ff63bdc102e010f169b7a32daaa1ceb4278c4fae8e72d174564109e40",
    "transformer_hardkuma/seed42/model.pt": "5d2c5f9683b79f57dd4d6b0b3e91f31d79fbd25d4aebc590efee3dcd3a3c53cd",
    "transformer_hardkuma/seed43/model.pt": "b86470667c9ebdb36740bc44251366a398c9aac8aef6af8a7dd8f6c89bf7eaa7",
    "transformer_hardkuma/seed44/model.pt": "7c2e224aa90b2b699c039579a136682524adc349bb4da4cd1caab7cd61338d22",
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def relative(path: Path) -> str:
    return path.relative_to(ROOT).as_posix()


def is_included(path: Path) -> bool:
    rel = relative(path)
    relative_parts = path.relative_to(ROOT).parts
    parts = set(relative_parts)
    if not path.is_file() or path.is_symlink():
        return False
    if (
        path.name == ".DS_Store"
        or (path.suffix.lower() == ".md" and rel != "README.md")
        or (rel.startswith("artifacts/models/") and path.name == "metrics.json")
        or path.suffix in EXCLUDED_SUFFIXES
        or parts & EXCLUDED_PARTS
        or any(part.endswith(".egg-info") for part in relative_parts)
    ):
        return False
    if rel in EXCLUDED_EXACT or any(rel.startswith(prefix) for prefix in EXCLUDED_PREFIXES):
        return False
    return rel in INCLUDED_FILES or any(rel.startswith(prefix) for prefix in INCLUDED_PREFIXES)


def submission_files() -> list[Path]:
    return sorted((path for path in ROOT.rglob("*") if is_included(path)), key=relative)


def build_model_manifest() -> dict[str, Any]:
    records = []
    for model_rel, expected_hash in EXPECTED_CHECKPOINTS.items():
        model_path = MODEL_ROOT / model_rel
        if not model_path.is_file():
            raise FileNotFoundError(model_path)
        run_dir = model_path.parent
        files = [model_path]
        if model_rel.startswith("tfidf/"):
            files.append(run_dir / "config.json")
        else:
            files.extend(run_dir / name for name in ("config.json", "vocab.json"))
        if any(not path.is_file() for path in files):
            missing = [str(path) for path in files if not path.is_file()]
            raise FileNotFoundError(f"Missing supporting model files: {missing}")
        actual_hash = sha256(model_path)
        if actual_hash != expected_hash:
            raise RuntimeError(f"Frozen checkpoint hash mismatch: {model_path}")
        records.append(
            {
                "model": relative(model_path),
                "checkpoint_sha256": expected_hash,
                "files": [
                    {"path": relative(path), "size_bytes": path.stat().st_size, "sha256": sha256(path)}
                    for path in files
                ],
            }
        )
    return {
        "schema_version": 1,
        "purpose": "Examiner-submission model payload: selected frozen models plus load/evaluation metadata.",
        "scientific_selection_changed": False,
        "models": records,
    }


def verify_model_manifest() -> None:
    expected = build_model_manifest()
    recorded = json.loads(MODEL_MANIFEST.read_text(encoding="utf-8"))
    if recorded != expected:
        raise RuntimeError("artifacts/model_manifest.json does not match the selected model payload")


def verify_model_loading() -> None:
    import joblib
    import torch

    from detectgpt.rationales.transformer_experiment import load_checkpoint
    from scripts.evaluate_rationale_strategies import load_model as load_rationale_model
    from scripts.run_final_evaluation import load_full_context

    tfidf = joblib.load(MODEL_ROOT / "tfidf/model.joblib")
    if not callable(getattr(tfidf, "predict", None)) or not callable(getattr(tfidf, "predict_proba", None)):
        raise RuntimeError("TF-IDF artifact does not expose predict and predict_proba")
    del tfidf
    device = torch.device("cpu")
    for seed in (42, 43, 44):
        model, vocab, config = load_full_context(MODEL_ROOT / f"bilstm_full/seed{seed}", device)
        if int(config["seed"]) != seed or len(vocab) != 10_000:
            raise RuntimeError(f"Unexpected full-context BiLSTM metadata for seed {seed}")
        del model, vocab, config
        model, vocab, config = load_rationale_model(MODEL_ROOT / f"bilstm_hardkuma/seed{seed}", device)
        if int(config["seed"]) != seed or len(vocab) != 10_000:
            raise RuntimeError(f"Unexpected HardKuma BiLSTM metadata for seed {seed}")
        del model, vocab, config
        for family, expected_kind in (
            ("transformer_full", "full_context"),
            ("transformer_hardkuma", "rationale"),
        ):
            model, vocab, config = load_checkpoint(MODEL_ROOT / family / f"seed{seed}", device)
            if int(config["seed"]) != seed or config["model_kind"] != expected_kind or len(vocab) != 10_000:
                raise RuntimeError(f"Unexpected {family} metadata for seed {seed}")
            del model, vocab, config
        gc.collect()


def verify_policy(files: list[Path]) -> None:
    relative_files = {relative(path) for path in files}
    required = {
        "README.md",
        "Makefile",
        "pyproject.toml",
        "artifacts/models/tfidf/model.joblib",
        "results/final/metrics/final_results.csv",
        "results/human_study/aggregate/descriptive_by_condition.csv",
        "scripts/run_final_evaluation.py",
    }
    missing = sorted(required - relative_files)
    if missing:
        raise RuntimeError(f"Submission allowlist is missing required files: {missing}")
    forbidden_markers = (
        ".git/",
        ".cleanup_quarantine/",
        "Form Responses/",
        "data/embeddings/",
        "kaggle_downloads/",
        "kaggle_packages/",
        "outputs/",
        "docs/",
        "notebooks/",
        "scripts/legacy/",
    )
    forbidden = sorted(
        rel
        for rel in relative_files
        if rel.endswith((".jsonl", ".rds"))
        or (rel.endswith(".md") and rel != "README.md")
        or any(rel.startswith(marker) for marker in forbidden_markers)
        or rel in EXCLUDED_EXACT
        or rel in {"scripts/submission_inventory.py", "tests/test_submission_inventory.py"}
    )
    if forbidden:
        raise RuntimeError(f"Private/restricted/large files entered the allowlist: {forbidden}")
    selected_models = {relative(MODEL_ROOT / path) for path in EXPECTED_CHECKPOINTS}
    missing_models = sorted(selected_models - relative_files)
    if missing_models:
        raise RuntimeError(f"Selected checkpoints are missing: {missing_models}")


def human_size(size: int) -> str:
    value = float(size)
    units = ("B", "KiB", "MiB", "GiB")
    unit = units[0]
    for unit in units:
        if value < 1024 or unit == units[-1]:
            break
        value /= 1024
    return f"{size} B" if unit == "B" else f"{value:.2f} {unit}"


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--write-model-manifest", action="store_true")
    parser.add_argument("--write-checksums", action="store_true")
    parser.add_argument("--verify-models", action="store_true")
    parser.add_argument("--list", action="store_true", dest="list_files")
    args = parser.parse_args()

    if args.write_model_manifest:
        payload = build_model_manifest()
        MODEL_MANIFEST.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")

    verify_model_manifest()
    files = submission_files()
    verify_policy(files)
    if args.verify_models:
        verify_model_loading()
    if args.write_checksums:
        checksummed = [path for path in files if path != CHECKSUMS]
        CHECKSUMS.write_text(
            "".join(f"{sha256(path)}  {relative(path)}\n" for path in checksummed),
            encoding="utf-8",
        )
        files = submission_files()
        verify_policy(files)
    if args.list_files:
        print("\n".join(relative(path) for path in files))
    total = sum(path.stat().st_size for path in files)
    print(json.dumps({"status": "passed", "files": len(files), "size_bytes": total, "size": human_size(total)}, indent=2))


if __name__ == "__main__":
    main()
