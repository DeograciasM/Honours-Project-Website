from __future__ import annotations

import argparse
from pathlib import Path

from detectgpt.rationales.transformer_experiment import evaluate_saved_run, save_json


def main() -> None:
    parser = argparse.ArgumentParser(description="Evaluate a saved rationale or full-context Transformer checkpoint.")
    parser.add_argument("--run-dir", required=True, type=Path)
    parser.add_argument("--data-dir", default=None, type=Path)
    parser.add_argument("--save", action="store_true", help="Replace saved evaluation metrics and predictions.")
    args = parser.parse_args()
    result = evaluate_saved_run(args.run_dir, args.data_dir)
    for split in ("validation", "test"):
        overall = result["metrics"][split]["overall"]
        auroc = f"{overall['auroc']:.4f}" if overall["auroc"] is not None else "undefined"
        print(
            f"{split}: accuracy={overall['accuracy']:.4f} precision={overall['machine_precision']:.4f} "
            f"recall={overall['machine_recall']:.4f} f1={overall['machine_f1']:.4f} "
            f"auroc={auroc}"
        )
    if args.save:
        save_json(args.run_dir / "reevaluation_metrics.json", result["metrics"])


if __name__ == "__main__":
    main()
