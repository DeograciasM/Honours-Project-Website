#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import unicodedata
from collections import Counter
from pathlib import Path

from detectgpt.data.io import load_dataset_splits
from detectgpt.data.validation import validate_rows, validate_split_files
from detectgpt.rationales.vocab import build_vocabulary, tokenize_with_offsets


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", type=Path, required=True)
    parser.add_argument("--embeddings-path", type=Path, required=True)
    parser.add_argument("--out-dir", type=Path, required=True)
    parser.add_argument("--max-vocab", type=int, default=10000)
    parser.add_argument("--min-freq", type=int, default=2)
    args = parser.parse_args()
    splits = ("train", "validation")
    rows = load_dataset_splits(args.data_dir, splits)
    validate_split_files(args.data_dir, splits); validate_rows(rows)
    vocab = build_vocabulary((r["text"] for r in rows["train"]), args.max_vocab, args.min_freq)
    glove = set()
    with args.embeddings_path.open(encoding="utf-8") as handle:
        for line in handle:
            token = line.partition(" ")[0]
            if token: glove.add(token)
    counts: Counter[str] = Counter()
    punctuation = total = exact = fallback = oov = 0
    roundtrip_failures = []
    for split in splits:
        for row in rows[split]:
            text = str(row["text"])
            for span in tokenize_with_offsets(text):
                total += 1; counts[span.text] += 1
                if text[span.start:span.end] != span.text and len(roundtrip_failures) < 10:
                    roundtrip_failures.append({"id": row["id"], "token": span.text, "start": span.start, "end": span.end})
                if all(unicodedata.category(ch)[0] in {"P", "S"} for ch in span.text): punctuation += 1
                if span.text in glove: exact += 1
                elif span.text.lower() != span.text and span.text.lower() in glove: fallback += 1
                else: oov += 1
    retained = sum(count for token, count in counts.items() if token in vocab.token_to_id)
    diagnostics = {
        "splits_loaded": list(splits), "test_split_loaded": False,
        "documents": {key: len(value) for key, value in rows.items()},
        "total_surface_tokens": total, "unique_surface_tokens": len(counts), "vocabulary_size_including_specials": len(vocab),
        "vocabulary_token_coverage": retained / total if total else 0.0,
        "oov_rate": oov / total if total else 0.0,
        "punctuation_token_proportion": punctuation / total if total else 0.0,
        "case_sensitive_glove_hit_rate": exact / total if total else 0.0,
        "lowercase_fallback_glove_hit_rate": fallback / total if total else 0.0,
        "glove_total_hit_rate": (exact + fallback) / total if total else 0.0,
        "roundtrip_failures": roundtrip_failures,
    }
    args.out_dir.mkdir(parents=True, exist_ok=True)
    (args.out_dir / "diagnostics.json").write_text(json.dumps(diagnostics, indent=2) + "\n", encoding="utf-8")
    (args.out_dir / "vocabulary.json").write_text(json.dumps({"token_to_id": vocab.token_to_id}, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(diagnostics, indent=2))


if __name__ == "__main__": main()
