from __future__ import annotations

import argparse
import copy
import json
import math
import random
import shlex
import subprocess
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np
import torch
from torch import nn
from torch.utils.data import DataLoader, Dataset

from detectgpt.data.io import JsonRow, load_dataset_splits, write_jsonl
from detectgpt.data.validation import validate_rows, validate_split_files
from detectgpt.evaluation.metrics import evaluate_split
from detectgpt.rationales.kuma_model import KumaRationaleModel, load_pretrained_embeddings
from detectgpt.rationales.rate_controller import RateController
from detectgpt.rationales.reporting import write_run_summary
from detectgpt.rationales.vocab import Vocabulary, build_vocabulary, tokenize_with_offsets
from detectgpt.utils.device import DEVICE_CHOICES, resolve_device
from detectgpt.utils.seed import set_seed


def git_commit() -> str | None:
    """Return the current Git commit when available."""
    try:
        return subprocess.run(
            ["git", "rev-parse", "HEAD"], check=True, capture_output=True, text=True
        ).stdout.strip()
    except (OSError, subprocess.CalledProcessError):
        return None


@dataclass
class TokenExample:
    row: JsonRow
    tokens: list[str]
    token_ids: list[int]
    token_offsets: list[tuple[int, int]]
    label_id: int


class TokenDataset(Dataset[TokenExample]):
    def __init__(self, rows: list[JsonRow], vocab: Vocabulary, max_tokens: int) -> None:
        self.examples: list[TokenExample] = []
        for row in rows:
            spans = tokenize_with_offsets(str(row["text"]))[:max_tokens]
            tokens = [span.text for span in spans] or ["<unk>"]
            offsets = [(span.start, span.end) for span in spans] or [(0, 0)]
            token_ids = [vocab.token_to_id.get(token, vocab.unk_id) for token in tokens]
            self.examples.append(TokenExample(row=row, tokens=tokens, token_ids=token_ids, token_offsets=offsets, label_id=int(row["label_id"])))

    def __len__(self) -> int:
        return len(self.examples)

    def __getitem__(self, index: int) -> TokenExample:
        return self.examples[index]


def collate_examples(examples: list[TokenExample], pad_id: int) -> dict[str, Any]:
    batch_size = len(examples)
    max_len = max(len(example.token_ids) for example in examples)
    input_ids = torch.full((batch_size, max_len), pad_id, dtype=torch.long)
    mask = torch.zeros((batch_size, max_len), dtype=torch.bool)
    labels = torch.tensor([example.label_id for example in examples], dtype=torch.long)

    for batch_index, example in enumerate(examples):
        length = len(example.token_ids)
        input_ids[batch_index, :length] = torch.tensor(example.token_ids, dtype=torch.long)
        mask[batch_index, :length] = True

    return {"input_ids": input_ids, "mask": mask, "labels": labels, "examples": examples}


def make_loader(dataset: TokenDataset, batch_size: int, shuffle: bool, seed: int, pad_id: int) -> DataLoader:
    generator = torch.Generator()
    generator.manual_seed(seed)
    return DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=shuffle,
        collate_fn=lambda examples: collate_examples(examples, pad_id),
        generator=generator,
    )


def resolve_selection_constraint(
    target_selection: float | None,
    selection_budget: int | None,
) -> tuple[str, float | None]:
    """Resolve the scalar controlled by the selection RateController.

    Fractional selection controls the ordinary expected fraction. A fixed
    token budget instead controls the expected count divided by each
    document's attainable count, ``min(budget, real_length)``. Its target is
    therefore 1.0 regardless of padding or truncation width.
    """
    if selection_budget is not None and target_selection is not None:
        raise ValueError(
            "--selection-budget and --target-selection are mutually exclusive; "
            "fixed-count control derives its target from each real document length."
        )
    if selection_budget is not None:
        if selection_budget <= 0:
            raise ValueError("--selection-budget must be a positive integer.")
        return "fixed_count_ratio", 1.0
    if target_selection is not None:
        return "fraction", target_selection
    return "fixed_weight", None


def selection_constraint_statistics(
    expected_gates: torch.Tensor,
    mask: torch.Tensor,
    *,
    target_selection: float | None,
    selection_budget: int | None,
) -> dict[str, torch.Tensor]:
    """Return padding-safe analytical selection and target statistics."""
    real_mask = mask.float()
    lengths = real_mask.sum(dim=1).clamp_min(1.0)
    expected_counts = (expected_gates * real_mask).sum(dim=1)
    expected_rates = expected_counts / lengths

    if selection_budget is not None:
        target_counts = lengths.clamp_max(float(selection_budget))
        control_value = (expected_counts / target_counts.clamp_min(1.0)).mean()
    elif target_selection is not None:
        target_counts = lengths * float(target_selection)
        control_value = expected_rates.mean()
    else:
        target_counts = torch.zeros_like(lengths)
        control_value = expected_rates.mean()

    return {
        "expected_selection_rate": expected_rates.mean(),
        "expected_selected_tokens": expected_counts.mean(),
        "target_selection_rate": (target_counts / lengths).mean(),
        "target_selected_tokens": target_counts.mean(),
        "selection_control_value": control_value,
    }


def train_epoch(
    model: KumaRationaleModel,
    loader: DataLoader,
    optimizer: torch.optim.Optimizer,
    loss_fn: nn.Module,
    device: torch.device,
    lambda_sparsity: float,
    lambda_continuity: float,
    selection_controller: RateController | None = None,
    coherence_controller: RateController | None = None,
    max_grad_norm: float = 5.0,
    target_selection: float | None = None,
    selection_budget: int | None = None,
) -> dict[str, float]:
    model.train()
    total_loss = 0.0
    total_ce = 0.0
    total_selection = 0.0
    total_control_value = 0.0
    total_expected_tokens = 0.0
    total_target_rate = 0.0
    total_target_tokens = 0.0
    total_continuity = 0.0
    total_examples = 0
    last_lambda_sel = lambda_sparsity
    last_lambda_coh = lambda_continuity

    for batch in loader:
        input_ids = batch["input_ids"].to(device)
        mask = batch["mask"].to(device)
        labels = batch["labels"].to(device)

        optimizer.zero_grad()
        outputs = model(input_ids, mask)
        classification_loss = loss_fn(outputs["logits"], labels)
        selection_stats = selection_constraint_statistics(
            outputs["expected_gates"],
            mask,
            target_selection=target_selection,
            selection_budget=selection_budget,
        )
        expected_selection_rate = selection_stats["expected_selection_rate"]
        selection_control_value = selection_stats["selection_control_value"]

        transition_rate = outputs["transition_rate"]

        if selection_controller is not None:
            current_lambda_sel = selection_controller.lam
            selection_reward = selection_controller.penalty(selection_control_value)
            if coherence_controller is not None:
                current_lambda_coh = coherence_controller.lam
                coherence_reward = coherence_controller.penalty(transition_rate)
                loss = classification_loss - selection_reward - coherence_reward
            else:
                current_lambda_coh = lambda_continuity
                loss = classification_loss - selection_reward + lambda_continuity * transition_rate
        else:
            # Fixed-lambda fallback path, unchanged from before rate control existed.
            current_lambda_sel = lambda_sparsity
            current_lambda_coh = lambda_continuity
            loss = classification_loss + lambda_sparsity * expected_selection_rate + lambda_continuity * transition_rate
        loss.backward()
        if max_grad_norm is not None and max_grad_norm > 0:
            nn.utils.clip_grad_norm_(model.parameters(), max_grad_norm)
        optimizer.step()

        if selection_controller is not None:
            selection_controller.update(float(selection_control_value.item()))
        if coherence_controller is not None:
            coherence_controller.update(float(transition_rate.item()))

        last_lambda_sel = current_lambda_sel
        last_lambda_coh = current_lambda_coh
        batch_size = labels.size(0)
        total_loss += float(loss.item()) * batch_size
        total_ce += float(classification_loss.item()) * batch_size
        total_selection += float(expected_selection_rate.item()) * batch_size
        total_control_value += float(selection_control_value.item()) * batch_size
        total_expected_tokens += float(selection_stats["expected_selected_tokens"].item()) * batch_size
        total_target_rate += float(selection_stats["target_selection_rate"].item()) * batch_size
        total_target_tokens += float(selection_stats["target_selected_tokens"].item()) * batch_size
        total_continuity += float(transition_rate.item()) * batch_size
        total_examples += batch_size

    denominator = max(1, total_examples)
    return {
        "loss": total_loss / denominator,
        "classification_loss": total_ce / denominator,
        "expected_selection_rate": total_selection / denominator,
        "selection_control_value": total_control_value / denominator,
        "expected_selected_tokens": total_expected_tokens / denominator,
        "target_selection_rate": total_target_rate / denominator,
        "target_selected_tokens": total_target_tokens / denominator,
        "transition_rate": total_continuity / denominator,
        "continuity_loss": total_continuity / denominator,
        "lambda_sel": last_lambda_sel,
        "lambda_coh": last_lambda_coh,
        "lambda": last_lambda_sel,
    }


def select_threshold_tokens(gates: list[float], valid_count: int, gate_threshold: float) -> tuple[list[int], bool]:
    valid_gates = gates[:valid_count]
    selected = [index for index, gate in enumerate(valid_gates) if gate >= gate_threshold]
    if selected:
        return selected, False
    if valid_count == 0:
        return [], True
    return [int(np.argmax(valid_gates))], True


def select_topk_tokens(gates: list[float], valid_count: int, target_fraction: float) -> tuple[list[int], bool]:
    """Select the ceil(target_fraction * valid_count) highest-gate tokens (Paranjape et al. 2020, sec 3.2).

    Deterministic and always non-empty for valid_count > 0, so the argmax
    fallback (second return value) should never fire in this mode.
    """
    if valid_count == 0:
        return [], True
    valid_gates = gates[:valid_count]
    k = min(valid_count, max(1, math.ceil(target_fraction * valid_count)))
    order = sorted(range(valid_count), key=lambda index: valid_gates[index], reverse=True)
    return sorted(order[:k]), False


def select_topk_budget(gates: list[float], valid_count: int, budget: int) -> tuple[list[int], bool]:
    """Select exactly ``budget`` tokens, capped only for shorter documents."""
    if budget <= 0:
        raise ValueError("--selection-budget must be a positive integer.")
    if valid_count == 0:
        return [], True
    valid_gates = gates[:valid_count]
    k = min(valid_count, budget)
    order = sorted(range(valid_count), key=lambda index: valid_gates[index], reverse=True)
    return sorted(order[:k]), False


def select_tokens(
    inference_mode: str,
    gates: list[float],
    valid_count: int,
    gate_threshold: float,
    target_fraction: float | None,
    selection_budget: int | None = None,
) -> tuple[list[int], bool]:
    if inference_mode == "topk":
        if selection_budget is not None:
            return select_topk_budget(gates, valid_count, selection_budget)
        if target_fraction is None:
            raise ValueError("--inference-mode topk requires --target-selection to be set.")
        return select_topk_tokens(gates, valid_count, target_fraction)
    if inference_mode == "threshold":
        return select_threshold_tokens(gates, valid_count, gate_threshold)
    raise ValueError(f"Unknown inference_mode: {inference_mode!r}")


def evaluate_model(
    model: KumaRationaleModel,
    loader: DataLoader,
    device: torch.device,
    gate_threshold: float,
    inference_mode: str = "threshold",
    target_fraction: float | None = None,
    selection_budget: int | None = None,
) -> tuple[list[int], list[JsonRow], list[JsonRow]]:
    model.eval()
    preds: list[int] = []
    metric_rows: list[JsonRow] = []
    prediction_rows: list[JsonRow] = []

    with torch.no_grad():
        for batch in loader:
            input_ids = batch["input_ids"].to(device)
            mask = batch["mask"].to(device)
            embeddings = model.embed_tokens(input_ids)
            a, b = model.gate_parameters(embeddings, mask)
            gate_tensor = model.deterministic_gates(a, b, mask)
            gates = gate_tensor.cpu().numpy()
            masks = batch["mask"].cpu().numpy()
            hard_mask = torch.zeros_like(gate_tensor, dtype=torch.bool)

            selected_by_example: list[list[int]] = []
            fallback_by_example: list[bool] = []
            for batch_index, (example_gates, example_mask) in enumerate(zip(gates.tolist(), masks.tolist(), strict=True)):
                valid_count = int(sum(example_mask))
                selected, used_fallback = select_tokens(
                    inference_mode, example_gates, valid_count, gate_threshold, target_fraction, selection_budget
                )
                selected_by_example.append(selected)
                fallback_by_example.append(used_fallback)
                if selected:
                    hard_mask[batch_index, selected] = True

            rationale_logits = model.predict_from_gates(embeddings, hard_mask.float(), mask)
            full_logits = model.predict_from_gates(embeddings, mask.float(), mask)
            without_mask = mask & ~hard_mask
            without_logits = model.predict_from_gates(embeddings, without_mask.float(), mask)

            rationale_probs = torch.softmax(rationale_logits, dim=1)
            full_probs = torch.softmax(full_logits, dim=1)
            without_probs = torch.softmax(without_logits, dim=1)
            machine_probs = rationale_probs[:, 1].cpu().numpy()
            batch_preds = (machine_probs >= 0.5).astype(int).tolist()

            for local_index, (example, pred, machine_prob, example_gates, example_mask, selected, used_fallback) in enumerate(
                zip(
                    batch["examples"],
                    batch_preds,
                    machine_probs.tolist(),
                    gates.tolist(),
                    masks.tolist(),
                    selected_by_example,
                    fallback_by_example,
                    strict=True,
                )
            ):
                valid_count = int(sum(example_mask))
                selected_tokens = [example.tokens[index] for index in selected]
                selected_offsets = [list(example.token_offsets[index]) for index in selected]
                selected_fraction = len(selected) / max(1, valid_count)
                pred_class = int(pred)
                full_class_prob = float(full_probs[local_index, pred_class].item())
                rationale_class_prob = float(rationale_probs[local_index, pred_class].item())
                without_class_prob = float(without_probs[local_index, pred_class].item())
                row = {
                    "id": example.row["id"],
                    "text": example.row["text"],
                    "label_id": int(example.row["label_id"]),
                    "label": example.row["label"],
                    "predicted_label_id": pred_class,
                    "predicted_label": "machine" if pred_class == 1 else "human",
                    "probability_machine": float(machine_prob),
                    "selected_token_indices": selected,
                    "selected_tokens": selected_tokens,
                    "token_offsets": [list(offset) for offset in example.token_offsets],
                    "selected_token_offsets": selected_offsets,
                    "token_gate_values": [float(gate) for gate in example_gates[:valid_count]],
                    "selected_fraction": float(selected_fraction),
                    "prediction_mode": "hardkuma_topk_tokens" if inference_mode == "topk" else "hardkuma_threshold_tokens",
                    "used_empty_selection_fallback": bool(used_fallback),
                    "full_text_probability_for_predicted_class": full_class_prob,
                    "rationale_only_probability_for_predicted_class": rationale_class_prob,
                    "without_rationale_probability_for_predicted_class": without_class_prob,
                    "sufficiency_drop": float(full_class_prob - rationale_class_prob),
                    "comprehensiveness_drop": float(full_class_prob - without_class_prob),
                    "domain": example.row.get("domain"),
                    "generator": example.row.get("generator"),
                    "source_id": example.row.get("source_id"),
                    "split": example.row.get("split"),
                }
                if "model" in example.row:
                    row["model"] = example.row["model"]

                preds.append(pred_class)
                metric_rows.append(example.row)
                prediction_rows.append(row)

    return preds, metric_rows, prediction_rows


def rationale_metrics(prediction_rows: list[JsonRow]) -> dict[str, Any]:
    selected_counts = [len(row["selected_token_indices"]) for row in prediction_rows]
    selected_fractions = [float(row["selected_fraction"]) for row in prediction_rows]
    sufficiency_drops = [float(row["sufficiency_drop"]) for row in prediction_rows]
    comprehensiveness_drops = [float(row["comprehensiveness_drop"]) for row in prediction_rows]
    gate_values = [
        float(gate)
        for row in prediction_rows
        for gate in row["token_gate_values"]
    ]
    fallback_count = int(sum(bool(row["used_empty_selection_fallback"]) for row in prediction_rows))
    gate_array = np.array(gate_values, dtype=float) if gate_values else np.array([], dtype=float)
    return {
        "average_selected_fraction": float(np.mean(selected_fractions)) if selected_fractions else 0.0,
        "average_selected_tokens": float(np.mean(selected_counts)) if selected_counts else 0.0,
        "minimum_selected_tokens": min(selected_counts) if selected_counts else 0,
        "maximum_selected_tokens": max(selected_counts) if selected_counts else 0,
        "average_selected_sentences": float(np.mean(selected_counts)) if selected_counts else 0.0,
        "mean_sufficiency_drop": float(np.mean(sufficiency_drops)) if sufficiency_drops else 0.0,
        "mean_comprehensiveness_drop": float(np.mean(comprehensiveness_drops)) if comprehensiveness_drops else 0.0,
        "median_sufficiency_drop": float(np.median(sufficiency_drops)) if sufficiency_drops else 0.0,
        "median_comprehensiveness_drop": float(np.median(comprehensiveness_drops)) if comprehensiveness_drops else 0.0,
        "empty_selection_fallback_count": fallback_count,
        "average_gate_value": float(gate_array.mean()) if gate_values else 0.0,
        "gate_distribution": {
            "min": float(gate_array.min()) if gate_values else 0.0,
            "p10": float(np.percentile(gate_array, 10)) if gate_values else 0.0,
            "median": float(np.percentile(gate_array, 50)) if gate_values else 0.0,
            "p90": float(np.percentile(gate_array, 90)) if gate_values else 0.0,
            "max": float(gate_array.max()) if gate_values else 0.0,
        },
    }


def save_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def save_checkpoint(path: Path, model: KumaRationaleModel, config: dict[str, Any], vocab: Vocabulary) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    torch.save(
        {
            "model_state_dict": {key: value.cpu() for key, value in model.state_dict().items()},
            "model_config": config["model"],
            "training_config": config,
            "vocabulary": {
                "token_to_id": vocab.to_dict(),
                "pad_token": "<pad>",
                "unk_token": "<unk>",
                "pad_id": vocab.pad_id,
                "unk_id": vocab.unk_id,
                "vocab_size": len(vocab),
            },
        },
        path,
    )


def build_config(
    args: argparse.Namespace,
    run_name: str,
    out_dir: Path,
    resolved_controller: dict[str, Any] | None = None,
    resolved_inference_mode: str = "threshold",
    embedding_stats: dict[str, Any] | None = None,
    actual_embed_dim: int | None = None,
    fixed_budget_targets: dict[str, dict[str, float]] | None = None,
) -> dict[str, Any]:
    constraint_mode, controller_target = resolve_selection_constraint(
        args.target_selection, getattr(args, "selection_budget", None)
    )
    rate_control_enabled = controller_target is not None
    return {
        "run_name": run_name,
        "data_dir": str(args.data_dir),
        "output_dir": str(out_dir),
        "device_requested": getattr(args, "device", "auto"),
        "epochs": args.epochs,
        "batch_size": args.batch_size,
        "lr": args.lr,
        "max_grad_norm": args.max_grad_norm,
        "lambda_sparsity": args.lambda_sparsity,
        "lambda_continuity": args.lambda_continuity,
        "coherence_mode": args.coherence_mode,
        "target_selection": args.target_selection,
        "rate_control_enabled": rate_control_enabled,
        "selection_constraint_mode": constraint_mode,
        "selection_controller_target": controller_target,
        "fixed_budget_effective_targets": fixed_budget_targets,
        "target_coherence": args.target_coherence,
        "coherence_control_enabled": rate_control_enabled and args.coherence_control,
        "git_commit": git_commit(),
        "launch_command": shlex.join([sys.executable, *sys.argv]),
        "launch_working_directory": str(Path.cwd()),
        "dataset_version": args.data_dir.name,
        "controller_alpha": args.controller_alpha,
        "controller_mode": args.controller_mode,
        "penalty_mu": (resolved_controller or {}).get("penalty_mu", args.penalty_mu),
        "lagrange_lr": (resolved_controller or {}).get("lagrange_lr"),
        "lambda_init": (resolved_controller or {}).get("lambda_init"),
        "lambda_max": (resolved_controller or {}).get("lambda_max"),
        "lambda_min": (resolved_controller or {}).get("min_lambda"),
        "max_vocab": args.max_vocab,
        "min_freq": args.min_freq,
        "max_tokens": args.max_tokens,
        "gate_threshold": args.gate_threshold,
        "selection_fraction": None,
        "selection_budget": getattr(args, "selection_budget", None),
        "inference_mode": resolved_inference_mode,
        "prediction_mode": (
            "hardkuma_fixed_budget_tokens"
            if resolved_inference_mode == "topk" and getattr(args, "selection_budget", None) is not None
            else "hardkuma_topk_tokens" if resolved_inference_mode == "topk" else "hardkuma_threshold_tokens"
        ),
        "embeddings_path": str(args.embeddings_path) if args.embeddings_path else None,
        "freeze_embeddings": args.freeze_embeddings if args.embeddings_path else None,
        "embedding_oov_rate": (embedding_stats or {}).get("oov_rate") if embedding_stats else None,
        "seed": args.seed,
        "model": {
            "type": "kuma_rationale",
            "embed_dim": actual_embed_dim if actual_embed_dim is not None else args.embed_dim,
            "hidden_dim": args.hidden_dim,
            "dropout": args.dropout,
            "coherence_mode": args.coherence_mode,
            "gate": {
                "distribution": "stretched_hard_kumaraswamy",
                "left": -0.1,
                "right": 1.1,
                "a_min": 0.01,
                "a_max": args.a_max,
                "b_min": args.b_min,
                "b_max": 10.0,
            },
        },
        "limits": {
            "train": args.limit_train,
            "validation": args.limit_val,
            "test": args.limit_test,
        },
    }


def maybe_limit(rows: list[JsonRow], limit: int | None) -> list[JsonRow]:
    return rows[:limit] if limit is not None else rows


def fixed_budget_target_statistics(
    datasets: dict[str, TokenDataset],
    selection_budget: int | None,
) -> dict[str, dict[str, float]] | None:
    if selection_budget is None:
        return None
    result: dict[str, dict[str, float]] = {}
    for split, dataset in datasets.items():
        lengths = [len(example.token_ids) for example in dataset.examples]
        target_counts = [min(selection_budget, length) for length in lengths]
        result[split] = {
            "mean_real_tokens": float(np.mean(lengths)),
            "mean_target_tokens": float(np.mean(target_counts)),
            "mean_target_fraction": float(
                np.mean([count / length for count, length in zip(target_counts, lengths, strict=True)])
            ),
            "minimum_target_tokens": float(min(target_counts)),
            "maximum_target_tokens": float(max(target_counts)),
        }
    return result


def run(args: argparse.Namespace) -> dict[str, Any]:
    started = time.monotonic()
    set_seed(args.seed)
    torch.manual_seed(args.seed)
    random.seed(args.seed)
    validation_only = getattr(args, "validation_only", False)

    run_name = args.run_name or "kuma_rationale"
    out_dir = args.output_dir or Path("outputs") / "rationales" / run_name
    if out_dir.exists() and any(out_dir.iterdir()):
        raise FileExistsError(f"Refusing to overwrite non-empty output directory: {out_dir}")

    requested_splits = ("train", "validation") if validation_only else ("train", "validation", "test")
    rows_by_split = load_dataset_splits(args.data_dir, requested_splits)
    validate_split_files(args.data_dir, requested_splits)
    validate_rows(rows_by_split)
    rows_by_split = {
        "train": maybe_limit(rows_by_split["train"], args.limit_train),
        "validation": maybe_limit(rows_by_split["validation"], args.limit_val),
        **({} if validation_only else {"test": maybe_limit(rows_by_split["test"], args.limit_test)}),
    }

    vocab = build_vocabulary((str(row["text"]) for row in rows_by_split["train"]), args.max_vocab, args.min_freq)
    datasets = {
        split: TokenDataset(rows, vocab, max_tokens=args.max_tokens)
        for split, rows in rows_by_split.items()
    }
    fixed_budget_targets = fixed_budget_target_statistics(
        datasets, getattr(args, "selection_budget", None)
    )
    loaders = {
        "train": make_loader(datasets["train"], args.batch_size, True, args.seed, vocab.pad_id),
        "validation": make_loader(datasets["validation"], args.batch_size, False, args.seed, vocab.pad_id),
        **({} if validation_only else {"test": make_loader(datasets["test"], args.batch_size, False, args.seed, vocab.pad_id)}),
    }

    selection_constraint_mode, selection_controller_target = resolve_selection_constraint(
        args.target_selection, getattr(args, "selection_budget", None)
    )
    rate_control_requested = selection_controller_target is not None

    resolved_inference_mode = args.inference_mode
    if resolved_inference_mode is None:
        resolved_inference_mode = "topk" if rate_control_requested else "threshold"
    if resolved_inference_mode == "topk" and not rate_control_requested:
        raise ValueError("--inference-mode topk requires --target-selection or --selection-budget.")
    if getattr(args, "selection_budget", None) is not None:
        if args.selection_budget <= 0:
            raise ValueError("--selection-budget must be a positive integer.")
        if resolved_inference_mode != "topk":
            raise ValueError("--selection-budget requires --inference-mode topk.")

    pretrained_matrix: torch.Tensor | None = None
    embedding_stats: dict[str, Any] | None = None
    if args.embeddings_path is not None:
        pretrained_matrix, embedding_stats = load_pretrained_embeddings(args.embeddings_path, vocab)
        if embedding_stats["embed_dim"] != args.embed_dim:
            print(
                f"Note: --embed-dim {args.embed_dim} ignored; using pretrained "
                f"embedding dim {embedding_stats['embed_dim']} from {args.embeddings_path}"
            )
        print(
            f"Loaded pretrained embeddings from {args.embeddings_path}: "
            f"dim={embedding_stats['embed_dim']} "
            f"oov_rate={embedding_stats['oov_rate']:.4f} "
            f"({embedding_stats['vocab_hits']}/{embedding_stats['vocab_considered']} vocab tokens matched) "
            f"freeze={args.freeze_embeddings}"
        )

    device = resolve_device(getattr(args, "device", "auto"))
    model = KumaRationaleModel(
        vocab_size=len(vocab),
        embed_dim=args.embed_dim,
        hidden_dim=args.hidden_dim,
        dropout=args.dropout,
        a_max=args.a_max,
        b_min=args.b_min,
        coherence_mode=args.coherence_mode,
        pretrained_embeddings=pretrained_matrix,
        freeze_embeddings=args.freeze_embeddings,
        padding_idx=vocab.pad_id,
    ).to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr)
    loss_fn = nn.CrossEntropyLoss()

    if args.controller_mode == "bastings":
        lagrange_lr = args.lagrange_lr if args.lagrange_lr is not None else 0.05
        lambda_init = args.lambda_init if args.lambda_init is not None else 1e-5
        lambda_max = args.lambda_max if args.lambda_max is not None else 5.0
        min_lambda = 1e-12
        penalty_mu = 0.0
    else:
        lagrange_lr = args.lagrange_lr if args.lagrange_lr is not None else 0.02
        lambda_init = args.lambda_init if args.lambda_init is not None else 0.02
        lambda_max = args.lambda_max if args.lambda_max is not None else 1.0
        min_lambda = 1e-4
        penalty_mu = args.penalty_mu

    resolved_controller = {
        "lagrange_lr": lagrange_lr,
        "lambda_init": lambda_init,
        "lambda_max": lambda_max,
        "min_lambda": min_lambda,
        "penalty_mu": penalty_mu,
        "selection_constraint_mode": selection_constraint_mode,
        "selection_controller_target": selection_controller_target,
    }

    selection_controller = (
        RateController(
            target=selection_controller_target,
            lr=lagrange_lr,
            init_lambda=lambda_init,
            max_lambda=lambda_max,
            min_lambda=min_lambda,
            warmup_steps=args.warmup_steps,
            alpha=args.controller_alpha,
            mode=args.controller_mode,
            penalty_mu=penalty_mu,
        )
        if rate_control_requested
        else None
    )

    coherence_controller = (
        RateController(
            target=args.target_coherence,
            lr=lagrange_lr,
            init_lambda=lambda_init,
            max_lambda=lambda_max,
            min_lambda=min_lambda,
            warmup_steps=args.warmup_steps,
            alpha=args.controller_alpha,
            mode=args.controller_mode,
            penalty_mu=penalty_mu,
        )
        if rate_control_requested and args.coherence_control
        else None
    )

    rate_controlled = selection_controller is not None

    best_val_f1: float | None = None
    best_epoch: int | None = None
    best_val_fraction: float | None = None
    best_selection_control_value: float | None = None
    best_state_dict: dict[str, Any] | None = None
    constraint_satisfied: bool | None = None

    # Fallback candidate for the rate-controlled path when no epoch satisfies
    # its constraint: the epoch with the lowest constraint value seen.
    lowest_constraint_epoch: int | None = None
    lowest_constraint_value: float | None = None
    lowest_constraint_val_fraction: float | None = None
    lowest_constraint_val_f1: float | None = None
    lowest_constraint_state_dict: dict[str, Any] | None = None

    train_history = []
    for epoch in range(1, args.epochs + 1):
        epoch_metrics = train_epoch(
            model,
            loaders["train"],
            optimizer,
            loss_fn,
            device,
            args.lambda_sparsity,
            args.lambda_continuity,
            selection_controller,
            coherence_controller,
            args.max_grad_norm,
            args.target_selection,
            getattr(args, "selection_budget", None),
        )
        train_history.append(epoch_metrics)
        print(
            f"epoch={epoch} "
            f"lambda_sel={epoch_metrics['lambda_sel']:.4f} "
            f"lambda_coh={epoch_metrics['lambda_coh']:.4f} "
            f"mean_expected_selection={epoch_metrics['expected_selection_rate']:.4f} "
            f"selection_control_value={epoch_metrics['selection_control_value']:.4f} "
            f"mean_expected_tokens={epoch_metrics['expected_selected_tokens']:.2f} "
            f"mean_target_tokens={epoch_metrics['target_selected_tokens']:.2f} "
            f"transition_rate={epoch_metrics['transition_rate']:.4f} "
            f"classification_loss={epoch_metrics['classification_loss']:.4f} "
            f"train_loss={epoch_metrics['loss']:.4f} "
        )

        # Single evaluate_model call per epoch; both val_f1 and val_fraction are
        # derived from its already-computed prediction_rows, not a second pass.
        val_preds, val_metric_rows, val_prediction_rows = evaluate_model(
            model, loaders["validation"], device, args.gate_threshold, resolved_inference_mode,
            args.target_selection, getattr(args, "selection_budget", None)
        )
        val_f1 = evaluate_split(val_metric_rows, val_preds)["overall"]["machine_f1"]
        val_fraction = rationale_metrics(val_prediction_rows)["average_selected_fraction"]

        if rate_controlled:
            if getattr(args, "selection_budget", None) is not None:
                constraint_value = epoch_metrics["selection_control_value"]
                constraint_limit = float(selection_controller_target) * 1.25
            else:
                constraint_value = val_fraction
                constraint_limit = float(args.target_selection) * 1.25
            eligible = constraint_value <= constraint_limit
            print(
                f"epoch={epoch} val_f1={val_f1:.4f} val_frac={val_fraction:.4f} "
                f"selection_control_value={epoch_metrics['selection_control_value']:.4f} "
                f"eligible={'yes' if eligible else 'no'}"
            )

            if lowest_constraint_value is None or constraint_value < lowest_constraint_value:
                lowest_constraint_value = constraint_value
                lowest_constraint_epoch = epoch
                lowest_constraint_val_fraction = val_fraction
                lowest_constraint_val_f1 = val_f1
                lowest_constraint_state_dict = copy.deepcopy(model.state_dict())

            if eligible and (best_val_f1 is None or val_f1 > best_val_f1):
                best_val_f1 = val_f1
                best_epoch = epoch
                best_val_fraction = val_fraction
                best_selection_control_value = epoch_metrics["selection_control_value"]
                best_state_dict = copy.deepcopy(model.state_dict())
        else:
            print(f"epoch={epoch} val_f1={val_f1:.4f}")
            if best_val_f1 is None or val_f1 > best_val_f1:
                best_val_f1 = val_f1
                best_epoch = epoch
                best_val_fraction = val_fraction
                best_state_dict = copy.deepcopy(model.state_dict())

    if rate_controlled:
        if best_state_dict is None:
            print(
                f"WARNING: no epoch satisfied selection constraint <= {constraint_limit:.4f}; "
                f"falling back to epoch={lowest_constraint_epoch} "
                f"(lowest constraint value={lowest_constraint_value:.4f})"
            )
            best_epoch = lowest_constraint_epoch
            best_val_f1 = lowest_constraint_val_f1
            best_val_fraction = lowest_constraint_val_fraction
            best_selection_control_value = lowest_constraint_value
            best_state_dict = lowest_constraint_state_dict
            constraint_satisfied = False
        else:
            constraint_satisfied = True

        print(
            f"best epoch={best_epoch} val_f1={best_val_f1:.4f} val_frac={best_val_fraction:.4f} "
            f"selection_control_value={best_selection_control_value:.4f} "
            f"constraint_satisfied={constraint_satisfied}"
        )
    else:
        print(f"best epoch={best_epoch} val_f1={best_val_f1:.4f}")

    if best_state_dict is not None:
        model.load_state_dict(best_state_dict)

    metrics: dict[str, Any] = {
        "run_name": run_name,
        "data_dir": str(args.data_dir),
        "train_losses": [epoch_metrics["loss"] for epoch_metrics in train_history],
        "train_history": train_history,
        "expected_selection_rate": train_history[-1]["expected_selection_rate"] if train_history else 0.0,
        "selection_control_value": train_history[-1]["selection_control_value"] if train_history else 0.0,
        "selection_controller_target": selection_controller_target,
        "selection_constraint_mode": selection_constraint_mode,
        "best_epoch": best_epoch,
        "best_val_f1": best_val_f1,
        "best_val_fraction": best_val_fraction,
        "best_selection_control_value": best_selection_control_value,
        "constraint_satisfied": constraint_satisfied,
        "vocab_size": len(vocab),
        "device": str(device),
        "inference_mode": resolved_inference_mode,
        "embedding_stats": embedding_stats,
        "parameter_count": sum(parameter.numel() for parameter in model.parameters()),
    }
    predictions_by_split: dict[str, list[JsonRow]] = {}
    evaluation_splits = ("validation",) if validation_only else ("validation", "test")
    for split in evaluation_splits:
        preds, metric_rows, prediction_rows = evaluate_model(
            model, loaders[split], device, args.gate_threshold, resolved_inference_mode,
            args.target_selection, getattr(args, "selection_budget", None)
        )
        split_metrics = evaluate_split(
            metric_rows,
            preds,
            [float(row["probability_machine"]) for row in prediction_rows],
        )
        split_metrics["rationales"] = rationale_metrics(prediction_rows)

        # Report both inference modes for comparison, regardless of which one
        # is primary. topk has no defined target when rate control is off.
        alt_mode = "threshold" if resolved_inference_mode == "topk" else "topk"
        if alt_mode == "topk" and args.target_selection is None:
            alt_rationale_metrics = None
        else:
            _, _, alt_prediction_rows = evaluate_model(
                model, loaders[split], device, args.gate_threshold, alt_mode, args.target_selection,
                getattr(args, "selection_budget", None) if alt_mode == "topk" else None
            )
            alt_rationale_metrics = rationale_metrics(alt_prediction_rows)

        split_metrics["inference_modes"] = {
            resolved_inference_mode: split_metrics["rationales"],
            alt_mode: alt_rationale_metrics,
        }
        metrics[split] = split_metrics
        predictions_by_split[split] = prediction_rows

    actual_embed_dim = embedding_stats["embed_dim"] if embedding_stats else args.embed_dim
    config = build_config(
        args,
        run_name,
        out_dir,
        resolved_controller,
        resolved_inference_mode,
        embedding_stats,
        actual_embed_dim,
        fixed_budget_targets,
    )
    config["vocab_size"] = len(vocab)
    config["splits"] = {split: len(rows) for split, rows in rows_by_split.items()}
    config["best_epoch"] = best_epoch
    config["best_val_f1"] = best_val_f1
    config["best_val_fraction"] = best_val_fraction
    config["best_selection_control_value"] = best_selection_control_value
    config["constraint_satisfied"] = constraint_satisfied
    config["parameter_count"] = metrics["parameter_count"]
    config["training_time_seconds"] = time.monotonic() - started
    config["device"] = str(device)
    metrics["training_time_seconds"] = config["training_time_seconds"]

    out_dir.mkdir(parents=True, exist_ok=True)
    save_json(out_dir / "config.json", config)
    save_json(out_dir / "metrics.json", metrics)
    save_json(out_dir / "vocab.json", {"token_to_id": vocab.to_dict()})
    save_checkpoint(out_dir / "model.pt", model, config, vocab)
    write_jsonl(out_dir / "validation_predictions.jsonl", predictions_by_split["validation"])
    if not validation_only:
        write_jsonl(out_dir / "test_predictions.jsonl", predictions_by_split["test"])
    write_run_summary(out_dir / "run_summary.md", run_name, config, metrics)

    for split in evaluation_splits:
        overall = metrics[split]["overall"]
        rationale = metrics[split]["rationales"]
        print(
            f"{run_name} {split}: "
            f"accuracy={overall['accuracy']:.4f}, "
            f"precision={overall['machine_precision']:.4f}, "
            f"recall={overall['machine_recall']:.4f}, "
            f"f1={overall['machine_f1']:.4f}, "
            f"avg_selected_fraction={rationale['average_selected_fraction']:.4f}, "
            f"fallbacks={rationale['empty_selection_fallback_count']}"
        )
    print(f"Saved outputs to {out_dir}")
    return metrics


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Train a HardKuma token-level rationale model.")
    parser.add_argument("--data-dir", required=True, type=Path, help="Dataset directory with train/validation/test JSONL files.")
    parser.add_argument("--output-dir", default=None, type=Path, help="Output directory. Defaults to outputs/rationales/<run-name>.")
    parser.add_argument("--run-name", default=None, help="Run name used for default output directory.")
    parser.add_argument("--device", default="auto", choices=DEVICE_CHOICES, help="Training device. auto prefers CUDA, then Apple MPS, then CPU.")
    parser.add_argument("--epochs", default=5, type=int, help="Number of training epochs.")
    parser.add_argument("--batch-size", default=32, type=int, help="Mini-batch size.")
    parser.add_argument("--lr", default=4e-4, type=float, help="Adam learning rate. Was 1e-3; lowered to 4e-4 to match Bastings-style stability (pass --lr 1e-3 to reproduce old runs).")
    parser.add_argument("--max-grad-norm", default=5.0, type=float, help="Global-norm gradient clipping threshold (Bastings 2019 uses 5.0). Set to 0 to disable.")
    parser.add_argument("--lambda-sparsity", default=0.01, type=float, help="Fixed weight for expected token selection rate. Used only as a fallback when --target-selection is not set, so existing fixed-lambda runs stay reproducible.")
    parser.add_argument("--target-selection", default=None, type=float, help="Target expected token selection fraction for Lagrangian rate control (dual ascent via RateController). When set, this replaces the fixed --lambda-sparsity penalty; --lambda-sparsity is ignored. Fixed-count experiments should use --selection-budget instead.")
    parser.add_argument("--target-coherence", default=0.02, type=float, help="Target expected zero/nonzero transition rate for an independent RateController. Enabled with selection rate/count control; otherwise --lambda-continuity retains the fixed-weight path.")
    parser.add_argument("--coherence-control", action=argparse.BooleanOptionalAction, default=True, help="Enable the independent coherence controller when selection rate/count control is active. Use --no-coherence-control for corrected pre-v12 selection-only experiments.")
    parser.add_argument("--warmup-steps", default=300, type=int, help="Training steps before RateController starts penalizing selection rate. Only used when --target-selection is set.")
    parser.add_argument("--controller-alpha", default=0.5, type=float, help="EMA smoothing factor for RateController's dual-ascent update (c_ma = alpha*c_ma + (1-alpha)*selection_value). Only used when --target-selection is set.")
    parser.add_argument("--controller-mode", default="current", choices=["current", "bastings"], help="'current': warmup + panic escape hatch (optionally + augmented-Lagrangian quadratic term via --penalty-mu). 'bastings': no warmup, no panic, linear penalty, pressure from step 0. Only used when --target-selection is set.")
    parser.add_argument("--penalty-mu", default=0.0, type=float, help="Augmented-Lagrangian quadratic penalty weight: adds 0.5*mu*violation**2 to the sparsity penalty, active from step 0, and disables the panic branch. Ignored (forced to 0) in --controller-mode bastings.")
    parser.add_argument("--lagrange-lr", default=None, type=float, help="RateController dual-ascent step size. Default depends on --controller-mode: 0.02 for current, 0.05 for bastings.")
    parser.add_argument("--lambda-init", default=None, type=float, help="RateController initial lambda. Default depends on --controller-mode: 0.02 for current, 1e-5 for bastings.")
    parser.add_argument("--lambda-max", default=None, type=float, help="RateController maximum lambda. Default depends on --controller-mode: 1.0 for current, 5.0 for bastings.")
    parser.add_argument("--lambda-continuity", default=0.001, type=float, help="Weight for adjacent gate differences.")
    parser.add_argument("--coherence-mode", default="transitions", choices=["magnitude", "transitions"], help="Continuity loss formulation: 'magnitude' penalises sampled adjacent-gate differences; 'transitions' penalises analytic P(z=0) zero/nonzero transition probability between adjacent real tokens.")
    parser.add_argument("--max-vocab", default=10000, type=int, help="Maximum vocabulary size, including special tokens.")
    parser.add_argument("--min-freq", default=2, type=int, help="Minimum token frequency.")
    parser.add_argument("--max-tokens", default=256, type=int, help="Maximum tokens per document.")
    parser.add_argument("--embed-dim", default=128, type=int, help="Token embedding dimension. Ignored (overridden by file dim) when --embeddings-path is set.")
    parser.add_argument("--embeddings-path", default=None, type=Path, help="Path to a GloVe-format pretrained embeddings text file. When set, embeddings are initialised from this file (OOV tokens from N(0, 0.1)) instead of learned from scratch, and the embedding dim follows the file.")
    parser.add_argument("--freeze-embeddings", action=argparse.BooleanOptionalAction, default=True, help="Freeze pretrained embeddings (no gradient updates). Only meaningful when --embeddings-path is set. Default True.")
    parser.add_argument("--inference-mode", default=None, choices=["threshold", "topk"], help="Token selection rule at eval time. 'threshold': select gates >= --gate-threshold (argmax fallback if empty). 'topk': deterministically select the top ceil(target * n_real_tokens) gated tokens (Paranjape et al. 2020), never empty. Default: 'topk' when --target-selection is set, else 'threshold'.")
    parser.add_argument("--selection-budget", default=None, type=int, help="Fixed token count per document, capped by real-token length. Enables length-aware analytical count control during training and deterministic fixed-count top-k inference; --target-selection is not required.")
    parser.add_argument("--hidden-dim", default=128, type=int, help="BiLSTM hidden size per direction.")
    parser.add_argument("--dropout", default=0.2, type=float, help="Dropout probability.")
    parser.add_argument("--gate-threshold", default=0.5, type=float, help="Gate value threshold used to save hard rationales.")
    parser.add_argument("--a-max", default=2.0, type=float, help="Upper bound for the HardKuma shape parameter a (bounded sigmoid parameterisation). Lower bound is fixed at 0.01.")
    parser.add_argument("--b-min", default=0.1, type=float, help="Lower bound for the HardKuma shape parameter b (bounded sigmoid parameterisation). Upper bound is fixed at 10.0.")
    parser.add_argument("--seed", default=42, type=int, help="Random seed.")
    parser.add_argument("--limit-train", default=None, type=int, help="Optional training row limit for smoke tests.")
    parser.add_argument("--limit-val", default=None, type=int, help="Optional validation row limit for smoke tests.")
    parser.add_argument("--limit-test", default=None, type=int, help="Optional test row limit for smoke tests.")
    parser.add_argument("--validation-only", action="store_true", help="Never load or evaluate the test split.")
    return parser.parse_args()


def main() -> None:
    run(parse_args())


if __name__ == "__main__":
    main()
