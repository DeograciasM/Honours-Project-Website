#!/usr/bin/env python3
"""Train/validation-only diagnostic for punctuation signal in original RAID text."""
from __future__ import annotations

import csv
import json
import re
from pathlib import Path

import numpy as np
from scipy.sparse import csr_matrix, hstack
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score, roc_auc_score
from sklearn.preprocessing import StandardScaler

from detectgpt.baselines.tfidf import DEFAULT_TFIDF_CONFIG, build_tfidf_pipeline

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data/processed/raid_en_balanced"
OUT = ROOT / "outputs/punctuation_diagnostic"
SPLITS = ("train", "validation")  # Deliberately excludes test.
FEATURES = (
    "em_dash", "en_dash", "hyphen", "comma", "period", "semicolon", "colon",
    "exclamation", "question_mark", "single_quote", "double_quote",
    "left_parenthesis", "right_parenthesis", "ellipsis_or_repeated_periods",
)


def read_split(split: str) -> list[dict]:
    if split not in SPLITS:
        raise ValueError(f"Diagnostic permits only {SPLITS}, not {split!r}")
    path = DATA / f"{split}.jsonl"
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def punctuation_counts(text: str) -> dict[str, int]:
    repeated = list(re.finditer(r"\.{2,}|…", text))
    repeated_period_chars = sum(match.group(0).count(".") for match in repeated)
    return {
        "em_dash": text.count("—"), "en_dash": text.count("–"), "hyphen": text.count("-"),
        "comma": text.count(","), "period": text.count(".") - repeated_period_chars,
        "semicolon": text.count(";"), "colon": text.count(":"), "exclamation": text.count("!"),
        "question_mark": text.count("?"),
        "single_quote": sum(text.count(char) for char in ("'", "‘", "’")),
        "double_quote": sum(text.count(char) for char in ('"', "“", "”")),
        "left_parenthesis": text.count("("), "right_parenthesis": text.count(")"),
        "ellipsis_or_repeated_periods": len(repeated),
    }


def feature_matrix(rows: list[dict]) -> tuple[np.ndarray, list[dict[str, float]]]:
    records, values = [], []
    for row in rows:
        counts = punctuation_counts(str(row["text"]))
        denominator = max(len(str(row["text"])), 1)
        frequencies = {name: counts[name] * 1000.0 / denominator for name in FEATURES}
        records.append(frequencies); values.append([frequencies[name] for name in FEATURES])
    return np.asarray(values, dtype=np.float64), records


def classifier() -> LogisticRegression:
    return LogisticRegression(**DEFAULT_TFIDF_CONFIG["classifier"])


def metrics(name: str, labels: np.ndarray, predictions: np.ndarray, probabilities: np.ndarray) -> dict:
    return {"configuration": name, "split": "validation", "f1": f1_score(labels, predictions),
            "precision": precision_score(labels, predictions), "recall": recall_score(labels, predictions),
            "accuracy": accuracy_score(labels, predictions), "auroc": roc_auc_score(labels, probabilities)}


def write_csv(path: Path, rows: list[dict]) -> None:
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0])); writer.writeheader(); writer.writerows(rows)


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    train, validation = read_split("train"), read_split("validation")
    train_text = [str(row["text"]) for row in train]; validation_text = [str(row["text"]) for row in validation]
    y_train = np.asarray([int(row["label_id"]) for row in train]); y_validation = np.asarray([int(row["label_id"]) for row in validation])
    train_punct, train_records = feature_matrix(train); validation_punct, validation_records = feature_matrix(validation)
    scaler = StandardScaler().fit(train_punct)
    train_punct_z, validation_punct_z = scaler.transform(train_punct), scaler.transform(validation_punct)

    # A: invoke the exact existing word-level TF-IDF builder and classifier.
    baseline = build_tfidf_pipeline(DEFAULT_TFIDF_CONFIG)
    baseline.fit(train_text, y_train)
    vectorizer = baseline.named_steps["tfidf"]
    x_train_tfidf = vectorizer.transform(train_text); x_validation_tfidf = vectorizer.transform(validation_text)
    pred_a = baseline.named_steps["classifier"].predict(x_validation_tfidf)
    prob_a = baseline.named_steps["classifier"].predict_proba(x_validation_tfidf)[:, 1]

    # B: standardized punctuation frequencies only.
    punct_model = classifier().fit(train_punct_z, y_train)
    pred_b = punct_model.predict(validation_punct_z); prob_b = punct_model.predict_proba(validation_punct_z)[:, 1]

    # C: same fitted TF-IDF representation plus standardized punctuation columns.
    combined = classifier().fit(hstack((x_train_tfidf, csr_matrix(train_punct_z)), format="csr"), y_train)
    x_validation_combined = hstack((x_validation_tfidf, csr_matrix(validation_punct_z)), format="csr")
    pred_c = combined.predict(x_validation_combined); prob_c = combined.predict_proba(x_validation_combined)[:, 1]

    metric_rows = [metrics("A_current_tfidf", y_validation, pred_a, prob_a),
                   metrics("B_punctuation_only", y_validation, pred_b, prob_b),
                   metrics("C_current_tfidf_plus_punctuation", y_validation, pred_c, prob_c)]
    write_csv(OUT / "validation_metrics.csv", metric_rows)

    frequency_rows = []
    for split, rows, records in (("train", train, train_records), ("validation", validation, validation_records)):
        for label_id, label in ((0, "human"), (1, "machine")):
            indices = [i for i, row in enumerate(rows) if int(row["label_id"]) == label_id]
            for feature in FEATURES:
                vals = [records[i][feature] for i in indices]
                frequency_rows.append({"split": split, "true_class": label, "feature": feature,
                    "normalization": "occurrences_per_1000_characters", "n_documents": len(indices),
                    "mean_frequency": float(np.mean(vals)), "standard_deviation": float(np.std(vals, ddof=1))})
    write_csv(OUT / "punctuation_frequencies.csv", frequency_rows)

    coefficients = punct_model.coef_[0]
    coefficient_rows = [{"feature": feature, "standardized_logistic_coefficient": float(coefficient),
                         "association_direction": "machine" if coefficient > 0 else "human" if coefficient < 0 else "neutral",
                         "training_mean_per_1000_characters": float(scaler.mean_[i]),
                         "training_standard_deviation_per_1000_characters": float(scaler.scale_[i])}
                        for i, (feature, coefficient) in enumerate(zip(FEATURES, coefficients, strict=True))]
    write_csv(OUT / "punctuation_coefficients.csv", coefficient_rows)

    by_name = {row["configuration"]: row for row in metric_rows}; delta = {key: by_name["C_current_tfidf_plus_punctuation"][key] - by_name["A_current_tfidf"][key]
                                                                  for key in ("f1", "precision", "recall", "accuracy", "auroc")}
    positive = sorted(coefficient_rows, key=lambda row: row["standardized_logistic_coefficient"], reverse=True)[:5]
    negative = sorted(coefficient_rows, key=lambda row: row["standardized_logistic_coefficient"])[:5]
    fmt = lambda value: f"{value:.4f}"
    lines = ["# Punctuation diagnostic", "", "## Scope and configuration", "",
             "This cheap model-development diagnostic uses only the original RAID `train` and `validation` text. The test split was neither loaded nor evaluated. No frozen output or existing baseline was modified.", "",
             "Configuration A exactly reuses the current lowercased word unigram/bigram TF-IDF settings (`max_features=100000`, `min_df=2`) and balanced liblinear logistic regression (`max_iter=1000`, seed 42). B uses punctuation frequencies per 1,000 Unicode characters, standardized using training means and standard deviations. C concatenates those standardized columns to the identical fitted TF-IDF representation and changes nothing else.", "",
             "## Validation performance", "", "| Configuration | F1 | Precision | Recall | Accuracy | AUROC |", "|---|---:|---:|---:|---:|---:|"]
    for row in metric_rows:
        lines.append(f"| {row['configuration']} | {fmt(row['f1'])} | {fmt(row['precision'])} | {fmt(row['recall'])} | {fmt(row['accuracy'])} | {fmt(row['auroc'])} |")
    lines += ["", "## A versus C validation difference", "", "C − A: " + ", ".join(f"{key} {delta[key]:+.4f}" for key in delta) + ".", "",
              "## Largest punctuation associations", "", "Coefficients come from B. A positive coefficient is associated with machine text; a negative coefficient is associated with human text. Each coefficient corresponds to a one-training-standard-deviation increase.", "",
              "| Machine-associated feature | Coefficient | Human-associated feature | Coefficient |", "|---|---:|---|---:|"]
    for p, n in zip(positive, negative, strict=True):
        lines.append(f"| {p['feature']} | {p['standardized_logistic_coefficient']:+.4f} | {n['feature']} | {n['standardized_logistic_coefficient']:+.4f} |")
    useful = delta["f1"] > 0 and delta["auroc"] > 0
    conclusion = ("The validation-only results provide practical evidence that punctuation adds signal omitted by the existing TF-IDF representation: both F1 and AUROC improve in C relative to A. This is enough to justify considering a punctuation-preserving rationale-model experiment, subject to the usual cost and design review."
                  if useful else
                  "Punctuation frequencies contain useful class-predictive signal on validation relative to an uninformative classifier (B AUROC is above 0.5), but adding them to the current TF-IDF representation reduces every reported validation metric. Thus this diagnostic finds punctuation signal, but no evidence that it supplies useful signal omitted by the existing TF-IDF baseline; by itself, it does not justify a punctuation-preserving rationale-model experiment.")
    lines += ["", "## Practical answer", "", conclusion, "", "This is descriptive train/validation evidence only. No causal or statistical-significance claim is made. Full class-frequency details and every punctuation coefficient are in the accompanying CSV files.", ""]
    (OUT / "punctuation_diagnostic_report.md").write_text("\n".join(lines), encoding="utf-8")

    # Reproduction gate for configuration A against the existing saved validation metrics.
    saved = json.loads((ROOT / "outputs/baselines/tfidf_raid_core_en_v3/metrics.json").read_text())
    expected = saved["validation"]["overall"]
    assert abs(metric_rows[0]["f1"] - expected["machine_f1"]) < 1e-12
    assert abs(metric_rows[0]["accuracy"] - expected["accuracy"]) < 1e-12
    assert abs(metric_rows[0]["auroc"] - saved["validation"]["auroc"]["overall"]) < 1e-12
    print(json.dumps({"validation_metrics": metric_rows, "c_minus_a": delta}, indent=2))


if __name__ == "__main__": main()
