from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path
from typing import Any

from sklearn.pipeline import Pipeline

from detectgpt.baselines.tfidf import (
    DEFAULT_TFIDF_CONFIG,
    DEFAULT_WORDCHAR_TFIDF_CONFIG,
    build_tfidf_pipeline,
    build_tfidf_wordchar_pipeline,
    extract_feature_weights,
)
from detectgpt.data.io import JsonRow, load_dataset_splits, write_jsonl
from detectgpt.data.validation import REQUIRED_SPLITS, validate_dataset
from detectgpt.evaluation.metrics import evaluate_split
from detectgpt.evaluation.reporting import write_run_summary
from detectgpt.utils.seed import set_seed


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Train and evaluate the TF-IDF baseline.")
    parser.add_argument("--data-dir", required=True, type=Path, help="Dataset directory containing train/validation/test JSONL files.")
    parser.add_argument("--out-dir", required=True, type=Path, help="Output directory for this run.")
    parser.add_argument("--run-name", default=None, help="Optional human-readable run name.")
    parser.add_argument(
        "--feature-mode",
        default="word",
        choices=["word", "wordchar"],
        help="'word' is the original word-ngram-only shared baseline (unchanged default). "
        "'wordchar' adds a char_wb(3,5) TF-IDF FeatureUnion alongside word(1,2), per proposal section 4.3.",
    )
    return parser.parse_args()


def split_texts_and_labels(rows: list[JsonRow]) -> tuple[list[str], list[int]]:
    return [str(row["text"]) for row in rows], [int(row["label_id"]) for row in rows]


def make_predictions(model: Pipeline, rows: list[JsonRow]) -> tuple[list[int], list[float], list[JsonRow]]:
    texts = [str(row["text"]) for row in rows]
    predicted_labels = [int(label) for label in model.predict(texts)]
    machine_probabilities = [float(probability) for probability in model.predict_proba(texts)[:, 1]]

    prediction_rows: list[JsonRow] = []
    for row, predicted_label, machine_probability in zip(rows, predicted_labels, machine_probabilities, strict=True):
        prediction_rows.append(
            {
                "id": row["id"],
                "source_id": row["source_id"],
                "split": row["split"],
                "domain": row["domain"],
                "generator": row["generator"],
                "attack": row["attack"],
                "decoding": row["decoding"],
                "label": row["label"],
                "label_id": int(row["label_id"]),
                "predicted_label_id": predicted_label,
                "predicted_label": "machine" if predicted_label == 1 else "human",
                "machine_probability": machine_probability,
                "correct": predicted_label == int(row["label_id"]),
            }
        )

    return predicted_labels, machine_probabilities, prediction_rows


def save_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def main() -> None:
    args = parse_args()
    run_name = args.run_name or args.out_dir.name
    seed = 42
    set_seed(seed)

    rows_by_split = load_dataset_splits(args.data_dir, REQUIRED_SPLITS)
    validate_dataset(args.data_dir, rows_by_split)

    if args.feature_mode == "wordchar":
        config = copy.deepcopy(DEFAULT_WORDCHAR_TFIDF_CONFIG)
    else:
        config = copy.deepcopy(DEFAULT_TFIDF_CONFIG)
    config.update(
        {
            "run_name": run_name,
            "data_dir": str(args.data_dir),
            "seed": seed,
            "feature_mode": args.feature_mode,
            "splits": {split: len(rows) for split, rows in rows_by_split.items()},
        }
    )

    train_texts, train_labels = split_texts_and_labels(rows_by_split["train"])
    if args.feature_mode == "wordchar":
        model = build_tfidf_wordchar_pipeline(config)
    else:
        model = build_tfidf_pipeline(config)
    model.fit(train_texts, train_labels)

    metrics: dict[str, Any] = {"run_name": run_name, "data_dir": str(args.data_dir)}
    all_prediction_rows: dict[str, list[JsonRow]] = {}

    for split in ("validation", "test"):
        predicted_labels, machine_probabilities, prediction_rows = make_predictions(model, rows_by_split[split])
        metrics[split] = evaluate_split(rows_by_split[split], predicted_labels, machine_probabilities)
        all_prediction_rows[split] = prediction_rows

    feature_weights = extract_feature_weights(model)

    args.out_dir.mkdir(parents=True, exist_ok=True)
    save_json(args.out_dir / "config.json", config)
    save_json(args.out_dir / "metrics.json", metrics)
    save_json(args.out_dir / "feature_weights.json", feature_weights)
    write_jsonl(args.out_dir / "validation_predictions.jsonl", all_prediction_rows["validation"])
    write_jsonl(args.out_dir / "test_predictions.jsonl", all_prediction_rows["test"])
    write_run_summary(args.out_dir / "run_summary.md", run_name, config, metrics)

    for split in ("validation", "test"):
        overall = metrics[split]["overall"]
        print(
            f"{run_name} {split}: "
            f"accuracy={overall['accuracy']:.4f}, "
            f"precision={overall['machine_precision']:.4f}, "
            f"recall={overall['machine_recall']:.4f}, "
            f"f1={overall['machine_f1']:.4f}"
        )
    print(f"Saved outputs to {args.out_dir}")


if __name__ == "__main__":
    main()

