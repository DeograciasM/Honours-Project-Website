#!/usr/bin/env python3
"""Independently verify one completed adaptive-selection HardKuma run."""

from __future__ import annotations

import argparse
import json
import math
import statistics
from pathlib import Path
from typing import Any


REPO_ROOT = Path(__file__).resolve().parents[1]
TEST_DATA = REPO_ROOT / "data/processed/raid_en_balanced/test.jsonl"
REQUIRED_FILES = (
    "config.json",
    "metrics.json",
    "validation_predictions.jsonl",
    "test_predictions.jsonl",
    "model.pt",
)


def read_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line]


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def close(actual: float, expected: float, *, tolerance: float = 1e-10) -> bool:
    return math.isclose(float(actual), float(expected), rel_tol=tolerance, abs_tol=tolerance)


def manual_auroc(labels: list[int], scores: list[float]) -> float:
    """Mann-Whitney rank-sum AUROC with midranks for tied scores."""
    positive = sum(labels)
    negative = len(labels) - positive
    require(positive > 0 and negative > 0, "AUROC requires both classes")
    order = sorted(range(len(scores)), key=scores.__getitem__)
    ranks = [0.0] * len(scores)
    start = 0
    while start < len(order):
        end = start
        while end + 1 < len(order) and scores[order[end + 1]] == scores[order[start]]:
            end += 1
        midrank = (start + end) / 2.0 + 1.0
        for offset in range(start, end + 1):
            ranks[order[offset]] = midrank
        start = end + 1
    positive_rank_sum = sum(rank for rank, label in zip(ranks, labels, strict=True) if label == 1)
    return (positive_rank_sum - positive * (positive + 1) / 2.0) / (positive * negative)


def independent_metrics(rows: list[dict[str, Any]]) -> dict[str, float | int]:
    labels = [int(row["label_id"]) for row in rows]
    predictions = [int(row["predicted_label_id"]) for row in rows]
    scores = [float(row["probability_machine"]) for row in rows]
    tp = sum(label == 1 and prediction == 1 for label, prediction in zip(labels, predictions, strict=True))
    tn = sum(label == 0 and prediction == 0 for label, prediction in zip(labels, predictions, strict=True))
    fp = sum(label == 0 and prediction == 1 for label, prediction in zip(labels, predictions, strict=True))
    fn = sum(label == 1 and prediction == 0 for label, prediction in zip(labels, predictions, strict=True))
    precision = tp / (tp + fp) if tp + fp else 0.0
    recall = tp / (tp + fn) if tp + fn else 0.0
    f1 = 2.0 * precision * recall / (precision + recall) if precision + recall else 0.0
    return {
        "examples": len(rows),
        "accuracy": (tp + tn) / len(rows),
        "machine_precision": precision,
        "machine_recall": recall,
        "machine_f1": f1,
        "auroc": manual_auroc(labels, scores),
        "true_positive": tp,
        "true_negative": tn,
        "false_positive": fp,
        "false_negative": fn,
    }


def require_finite(value: Any, location: str = "root") -> None:
    if isinstance(value, float):
        require(math.isfinite(value), f"Non-finite value at {location}: {value}")
    elif isinstance(value, dict):
        for key, child in value.items():
            require_finite(child, f"{location}.{key}")
    elif isinstance(value, list):
        for index, child in enumerate(value):
            require_finite(child, f"{location}[{index}]")


def verify_run(
    run_dir: Path,
    *,
    seed: int,
    max_tokens: int,
    target_selection: float | None,
    selection_budget: int | None,
    expected_git_commit: str | None = None,
    require_launch_command: bool = False,
) -> dict[str, Any]:
    run_dir = run_dir.resolve()
    for filename in REQUIRED_FILES:
        require((run_dir / filename).is_file(), f"Missing required file: {run_dir / filename}")

    config = read_json(run_dir / "config.json")
    metrics = read_json(run_dir / "metrics.json")
    validation_rows = read_jsonl(run_dir / "validation_predictions.jsonl")
    test_rows = read_jsonl(run_dir / "test_predictions.jsonl")
    dataset_rows = read_jsonl(TEST_DATA)
    require_finite(metrics, "metrics")

    require(config.get("run_name") == run_dir.name, "run_name does not match isolated output directory")
    configured_output = Path(str(config["output_dir"]))
    if not configured_output.is_absolute():
        configured_output = REPO_ROOT / configured_output
    require(configured_output.resolve() == run_dir, "config output_dir does not match actual run directory")
    require(config.get("rate_control_enabled") is True, "adaptive selection controller is not enabled")
    require(config.get("coherence_control_enabled") is False, "coherence controller must be disabled")
    if target_selection is None:
        require(config.get("target_selection") is None, "fixed-budget run must not set target_selection")
    else:
        require(close(config.get("target_selection"), target_selection), "target_selection mismatch")
    require(int(config.get("max_tokens")) == max_tokens, "max_tokens mismatch")
    require(config.get("inference_mode") == "topk", "deterministic evaluation is not top-k")
    expected_prediction_mode = (
        "hardkuma_fixed_budget_tokens"
        if selection_budget is not None
        else "hardkuma_topk_tokens"
    )
    require(config.get("prediction_mode") == expected_prediction_mode, "prediction mode is not the requested deterministic token top-k")
    require(config.get("device") == "mps", "resolved scientific device is not MPS")
    require(config.get("device_requested") == "mps", "requested scientific device is not MPS")
    require(int(config.get("seed")) == seed, "seed mismatch")
    require(config.get("selection_budget") == selection_budget, "selection_budget mismatch")
    if selection_budget is None:
        require(config.get("selection_constraint_mode", "fraction") == "fraction", "fractional constraint mode mismatch")
        require(close(config.get("selection_controller_target", target_selection), target_selection), "fractional controller target mismatch")
    else:
        require(config.get("selection_constraint_mode") == "fixed_count_ratio", "fixed-budget constraint is not length-aware")
        require(close(config.get("selection_controller_target"), 1.0), "fixed-budget controller target must be 1.0")
        fixed_targets = config.get("fixed_budget_effective_targets")
        require(isinstance(fixed_targets, dict), "fixed-budget effective targets are missing")
    require(config.get("git_commit"), "config is missing git_commit")
    if expected_git_commit is not None:
        require(config["git_commit"] == expected_git_commit, "run git_commit does not match queue HEAD")
    if require_launch_command:
        require(bool(config.get("launch_command")), "config is missing launch_command")

    history = metrics.get("train_history")
    require(isinstance(history, list) and history, "controller train_history is missing")
    lambda_sel = [float(row["lambda_sel"]) for row in history]
    lambda_coh = [float(row["lambda_coh"]) for row in history]
    expected_rates = [float(row["expected_selection_rate"]) for row in history]
    control_values = [
        float(row.get("selection_control_value", row["expected_selection_rate"]))
        for row in history
    ]
    require(max(lambda_sel) - min(lambda_sel) > 1e-9, "selection multiplier did not change")
    require(all(abs(value) <= 1e-12 for value in lambda_coh), "coherence multiplier did not remain zero")
    require(all(math.isfinite(value) for value in expected_rates), "expected selection trace is non-finite")
    require(all(math.isfinite(value) for value in control_values), "selection-control trace is non-finite")
    require(close(metrics["expected_selection_rate"], expected_rates[-1]), "final expected selection rate mismatch")
    require(close(metrics.get("selection_control_value", metrics["expected_selection_rate"]), control_values[-1]), "final selection-control value mismatch")
    configured_controller_target = config.get("selection_controller_target", target_selection)
    require(close(metrics.get("selection_controller_target", configured_controller_target), configured_controller_target), "metrics controller target mismatch")
    configured_constraint_mode = config.get("selection_constraint_mode", "fraction")
    require(metrics.get("selection_constraint_mode", configured_constraint_mode) == configured_constraint_mode, "metrics constraint mode mismatch")
    if selection_budget is not None:
        require(abs(control_values[-1] - 1.0) <= 0.15, "fixed-budget expected-count ratio missed its target")
        require(metrics.get("constraint_satisfied") is True, "fixed-budget checkpoint did not satisfy its count constraint")
        require(float(metrics["best_selection_control_value"]) <= 1.25, "selected checkpoint exceeded the fixed-budget count constraint")
        require(close(metrics["best_selection_control_value"], config["best_selection_control_value"]), "best checkpoint control value mismatch")
        train_targets = config["fixed_budget_effective_targets"]["train"]
        require(close(history[-1]["target_selection_rate"], train_targets["mean_target_fraction"], tolerance=1e-7), "train target fraction does not match real lengths")
        require(close(history[-1]["target_selected_tokens"], train_targets["mean_target_tokens"], tolerance=1e-7), "train target count does not match real lengths")

    dataset_ids = [str(row["id"]) for row in dataset_rows]
    test_ids = [str(row["id"]) for row in test_rows]
    validation_ids = [str(row["id"]) for row in validation_rows]
    require(test_ids == dataset_ids, "test prediction IDs/order do not exactly match RAID test.jsonl")
    require(len(test_ids) == len(set(test_ids)), "duplicate test prediction IDs")
    require(len(validation_ids) == len(set(validation_ids)), "duplicate validation prediction IDs")
    require(len(test_rows) == 1200, f"expected 1200 test examples, found {len(test_rows)}")
    require(len(validation_rows) == 1200, f"expected 1200 validation examples, found {len(validation_rows)}")

    selected_counts: list[int] = []
    selected_fractions: list[float] = []
    fallback_count = 0
    for index, row in enumerate(test_rows):
        valid_count = len(row["token_gate_values"])
        selected = [int(value) for value in row["selected_token_indices"]]
        require(valid_count > 0, f"empty visible sequence at test row {index}")
        require(selected == sorted(set(selected)), f"selected indices are not unique and sorted at test row {index}")
        require(all(0 <= value < valid_count for value in selected), f"selected padding/out-of-range token at test row {index}")
        expected_count = (
            min(selection_budget, valid_count)
            if selection_budget is not None
            else max(1, math.ceil(float(target_selection) * valid_count))
        )
        require(len(selected) == expected_count, f"top-k count mismatch at test row {index}")
        fraction = len(selected) / valid_count
        require(close(row["selected_fraction"], fraction), f"selected_fraction mismatch at test row {index}")
        require(row.get("prediction_mode") == "hardkuma_topk_tokens", f"non-top-k prediction at test row {index}")
        selected_counts.append(len(selected))
        selected_fractions.append(fraction)
        fallback_count += bool(row["used_empty_selection_fallback"])

    recomputed = independent_metrics(test_rows)
    saved = metrics["test"]["overall"]
    for key in ("accuracy", "machine_precision", "machine_recall", "machine_f1", "auroc"):
        require(saved.get(key) is not None, f"saved test {key} is missing")
        require(close(saved[key], recomputed[key]), f"saved test {key} differs from independent recomputation")

    rationale = metrics["test"]["rationales"]
    deterministic_rate = statistics.mean(selected_fractions)
    mean_selected_tokens = statistics.mean(selected_counts)
    require(close(rationale["average_selected_fraction"], deterministic_rate), "saved deterministic selection rate mismatch")
    require(close(rationale["average_selected_tokens"], mean_selected_tokens), "saved selected-token mean mismatch")
    require(int(rationale["empty_selection_fallback_count"]) == fallback_count, "saved fallback count mismatch")
    if selection_budget is not None:
        test_targets = config["fixed_budget_effective_targets"]["test"]
        require(close(test_targets["mean_target_fraction"], deterministic_rate), "fixed-budget test target fraction mismatch")
        require(close(test_targets["mean_target_tokens"], mean_selected_tokens), "fixed-budget test target count mismatch")

    return {
        "verified": True,
        "run_name": run_dir.name,
        "run_dir": str(run_dir.relative_to(REPO_ROOT)),
        "git_commit": config["git_commit"],
        "seed": seed,
        "max_tokens": max_tokens,
        "target_selection": target_selection,
        "selection_budget": selection_budget,
        "validation_f1": float(metrics["validation"]["overall"]["machine_f1"]),
        "test": recomputed,
        "expected_selection_rate": float(metrics["expected_selection_rate"]),
        "selection_control_value": float(metrics.get("selection_control_value", metrics["expected_selection_rate"])),
        "selection_controller_target": float(configured_controller_target),
        "selection_constraint_mode": configured_constraint_mode,
        "deterministic_selection_rate": deterministic_rate,
        "mean_selected_tokens": mean_selected_tokens,
        "fallback_count": fallback_count,
        "lambda_sel_initial": lambda_sel[0],
        "lambda_sel_final": lambda_sel[-1],
        "lambda_sel_range": [min(lambda_sel), max(lambda_sel)],
        "lambda_coh_unique": sorted(set(lambda_coh)),
        "test_ids_exactly_aligned": True,
        "metrics_exactly_recomputed": True,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-dir", required=True, type=Path)
    parser.add_argument("--seed", required=True, type=int)
    parser.add_argument("--max-tokens", required=True, type=int)
    parser.add_argument("--target-selection", required=True, type=float)
    parser.add_argument("--selection-budget", type=int)
    parser.add_argument("--expected-git-commit")
    parser.add_argument("--require-launch-command", action="store_true")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = verify_run(
        args.run_dir,
        seed=args.seed,
        max_tokens=args.max_tokens,
        target_selection=args.target_selection,
        selection_budget=args.selection_budget,
        expected_git_commit=args.expected_git_commit,
        require_launch_command=args.require_launch_command,
    )
    payload = json.dumps(result, indent=2, sort_keys=True) + "\n"
    if args.output is not None:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(payload, encoding="utf-8")
    print(payload, end="")


if __name__ == "__main__":
    main()
