import json
import random
from collections import Counter, defaultdict
from pathlib import Path
from typing import Dict, List, Any, Tuple


SEED = 42
random.seed(SEED)

IN_DIR = Path("data/processed/raid_core_en_v1")
OUT_DIR = Path("data/processed/raid_en_balanced")
OUT_DIR.mkdir(parents=True, exist_ok=True)

DOMAINS = ["abstracts", "news", "books", "poetry"]

MACHINE_MODELS = [
    "gpt2",
    "mistral",
    "mistral-chat",
    "llama-chat",
    "chatgpt",
    "gpt4",
]

PER_MODEL_SPLIT_COUNTS = {
    "train": 120,
    "validation": 25,
    "test": 25,
}

SPLITS = ["train", "validation", "test"]


def read_jsonl(path: Path) -> List[Dict[str, Any]]:
    rows = []
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            rows.append(json.loads(line))
    return rows


def write_jsonl(path: Path, rows: List[Dict[str, Any]]) -> None:
    with path.open("w", encoding="utf-8") as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")


def dedupe_exact_text(rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    seen_texts = set()
    deduped = []

    for row in rows:
        text = row["text"].strip()

        if text in seen_texts:
            continue

        seen_texts.add(text)
        deduped.append(row)

    return deduped


def group_rows(rows: List[Dict[str, Any]]):
    grouped = defaultdict(lambda: defaultdict(list))

    for row in rows:
        domain = row["domain"]
        source_id = row["source_id"]
        generator = row["generator"]

        grouped[(domain, source_id)][generator].append(row)

    return grouped


def assign_source_ids_for_domain(
    domain: str,
    grouped,
) -> Dict[str, List[Tuple[str, str]]]:
    """
    Returns:
      {
        "train": [(source_id, selected_machine_model), ...],
        "validation": [...],
        "test": [...]
      }

    Each source_id is used only once within the domain.
    Each chosen source_id contributes:
      - one human row
      - one machine row from selected_machine_model
    """

    source_ids = [
        source_id
        for (row_domain, source_id), by_generator in grouped.items()
        if row_domain == domain and "human" in by_generator
    ]

    random.shuffle(source_ids)

    used_source_ids = set()
    assignments = {split: [] for split in SPLITS}

    for split in SPLITS:
        needed = {
            model: PER_MODEL_SPLIT_COUNTS[split]
            for model in MACHINE_MODELS
        }

        for source_id in source_ids:
            if source_id in used_source_ids:
                continue

            by_generator = grouped[(domain, source_id)]

            available_models = [
                model
                for model in MACHINE_MODELS
                if model in by_generator and needed[model] > 0
            ]

            if not available_models:
                continue

            # Pick the model with the largest remaining need.
            selected_model = max(available_models, key=lambda m: needed[m])

            assignments[split].append((source_id, selected_model))
            used_source_ids.add(source_id)
            needed[selected_model] -= 1

            if all(v == 0 for v in needed.values()):
                break

        if any(v != 0 for v in needed.values()):
            raise RuntimeError(
                f"Could not fill {split} for domain={domain}. Remaining needs: {needed}"
            )

    return assignments


def main() -> None:
    all_rows = []
    for split_name in ["train", "validation", "test"]:
        all_rows.extend(read_jsonl(IN_DIR / f"{split_name}.jsonl"))

    before_dedupe = len(all_rows)
    all_rows = dedupe_exact_text(all_rows)
    after_dedupe = len(all_rows)

    grouped = group_rows(all_rows)

    output = {
        "train": [],
        "validation": [],
        "test": [],
    }

    for domain in DOMAINS:
        assignments = assign_source_ids_for_domain(domain, grouped)

        for split, pairs in assignments.items():
            for source_id, selected_model in pairs:
                by_generator = grouped[(domain, source_id)]

                human_row = dict(by_generator["human"][0])
                machine_row = dict(by_generator[selected_model][0])

                human_row["split"] = split
                machine_row["split"] = split

                output[split].append(human_row)
                output[split].append(machine_row)

    for split in SPLITS:
        random.shuffle(output[split])
        write_jsonl(OUT_DIR / f"{split}.jsonl", output[split])

    split_counts = Counter()
    label_counts = Counter()
    domain_counts = Counter()
    generator_counts = Counter()
    counts_by_domain_generator_split = defaultdict(Counter)
    source_id_splits = defaultdict(set)
    seen_texts = set()
    duplicate_text_count = 0

    for split, rows in output.items():
        split_counts[split] = len(rows)

        for row in rows:
            label_counts[row["label"]] += 1
            domain_counts[row["domain"]] += 1
            generator_counts[row["generator"]] += 1
            counts_by_domain_generator_split[(row["domain"], row["generator"])][split] += 1
            source_id_splits[row["source_id"]].add(split)

            text = row["text"].strip()
            if text in seen_texts:
                duplicate_text_count += 1
            seen_texts.add(text)

    source_leakage_count = sum(
        1 for splits in source_id_splits.values()
        if len(splits) > 1
    )

    stats = {
        "dataset_name": "raid_en_balanced",
        "source_dataset": "liamdugan/raid",
        "derived_from": str(IN_DIR),
        "seed": SEED,
        "domains": DOMAINS,
        "machine_models": MACHINE_MODELS,
        "attack": "none",
        "machine_decoding": "sampling",
        "exact_text_rows_before_dedupe": before_dedupe,
        "exact_text_rows_after_dedupe": after_dedupe,
        "exact_duplicate_texts_in_final": duplicate_text_count,
        "source_ids_crossing_splits": source_leakage_count,
        "per_model_split_counts": PER_MODEL_SPLIT_COUNTS,
        "human_split_counts_per_domain": {
            split: PER_MODEL_SPLIT_COUNTS[split] * len(MACHINE_MODELS)
            for split in SPLITS
        },
        "split_counts": dict(split_counts),
        "label_counts": dict(label_counts),
        "domain_counts": dict(domain_counts),
        "generator_counts": dict(generator_counts),
        "counts_by_domain_generator_split": {
            f"{domain}::{generator}": dict(counter)
            for (domain, generator), counter in counts_by_domain_generator_split.items()
        },
    }

    with (OUT_DIR / "stats.json").open("w", encoding="utf-8") as f:
        json.dump(stats, f, indent=2, ensure_ascii=False)

    dataset_card = f"""# RAID English Balanced

Controlled English subset of the RAID benchmark for human-written vs machine-generated text detection.

## Source

Source benchmark: `liamdugan/raid`

Derived from local `raid_core_en_v1` extraction.

## Selection

Domains:
{DOMAINS}

Machine generators:
{MACHINE_MODELS}

Human source:
`human`

Attack setting:
`none`

Machine decoding:
`sampling`

Minimum word count:
80 words

## Splitting

Rows are split by `source_id` so that examples from the same source do not appear across train, validation, and test.

## Labels

- `label_id = 0`: human
- `label_id = 1`: machine

## Files

- `train.jsonl`
- `validation.jsonl`
- `test.jsonl`
- `stats.json`
"""

    with (OUT_DIR / "dataset_card.md").open("w", encoding="utf-8") as f:
        f.write(dataset_card)

    print(json.dumps(stats, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
