#!/usr/bin/env python3
"""Verify and freeze all predeclared final-evaluation models before holdout creation."""
from __future__ import annotations

import csv
import hashlib
import json
import os
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import joblib
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import FeatureUnion, Pipeline

from detectgpt.data.io import load_jsonl

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "outputs/final_evaluation"
FROZEN = OUT / "frozen_models"
DATA = ROOT / "data/processed/raid_en_balanced"
SEEDS = (42, 43, 44)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path: Path, payload: dict[str, Any]) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    os.replace(temporary, path)


def git_commit() -> str | None:
    try:
        return subprocess.run(
            ["git", "rev-parse", "HEAD"], cwd=ROOT, check=True, capture_output=True, text=True
        ).stdout.strip()
    except (OSError, subprocess.CalledProcessError):
        return None


def verify_rationale(path: Path, seed: int) -> dict[str, Any]:
    required = ("model.pt", "config.json", "metrics.json", "vocab.json", "validation_predictions.jsonl")
    missing = [name for name in required if not (path / name).is_file()]
    if missing:
        raise RuntimeError(f"Missing rationale artifacts for seed {seed}: {missing}")
    config = read_json(path / "config.json")
    metrics = read_json(path / "metrics.json")
    expected = {
        "seed": seed,
        "max_tokens": 512,
        "target_selection": 0.4,
        "selection_budget": None,
        "inference_mode": "topk",
        "device": "mps",
        "controller_mode": "current",
        "penalty_mu": 10.0,
        "lambda_continuity": 0.0,
        "coherence_control_enabled": False,
        "epochs": 25,
        "batch_size": 32,
        "lr": 0.0004,
        "max_grad_norm": 5.0,
        "freeze_embeddings": False,
    }
    for key, value in expected.items():
        if config.get(key) != value:
            raise RuntimeError(f"Rationale seed {seed} mismatch: {key}={config.get(key)!r}, expected {value!r}")
    if config["model"]["hidden_dim"] != 128 or config["model"]["dropout"] != 0.2:
        raise RuntimeError(f"Rationale seed {seed} model architecture mismatch")
    if "test" in metrics or (path / "test_predictions.jsonl").exists():
        raise RuntimeError(f"Historical-test output detected for rationale seed {seed}")
    return {
        "seed": seed,
        "directory": str(path.relative_to(ROOT)),
        "checkpoint": str((path / "model.pt").relative_to(ROOT)),
        "checkpoint_sha256": sha256(path / "model.pt"),
        "config": str((path / "config.json").relative_to(ROOT)),
        "config_sha256": sha256(path / "config.json"),
        "training_git_commit": config["git_commit"],
        "validation_f1": metrics["validation"]["overall"]["machine_f1"],
        "validation_selection_fraction": metrics["validation"]["rationales"]["average_selected_fraction"],
        "constraint_satisfied": metrics["constraint_satisfied"],
    }


def verify_full_context(path: Path, seed: int) -> dict[str, Any]:
    required = ("model.pt", "config.json", "metrics.json", "vocab.json", "validation_predictions.jsonl")
    missing = [name for name in required if not (path / name).is_file()]
    if missing:
        raise RuntimeError(f"Missing full-context artifacts for seed {seed}: {missing}")
    config = read_json(path / "config.json")
    metrics = read_json(path / "metrics.json")
    expected = {
        "seed": seed,
        "max_tokens": 512,
        "device": "mps",
        "epochs": 25,
        "batch_size": 32,
        "lr": 0.0004,
        "freeze_embeddings": False,
    }
    for key, value in expected.items():
        if config.get(key) != value:
            raise RuntimeError(f"Full-context seed {seed} mismatch: {key}={config.get(key)!r}, expected {value!r}")
    if config["model"]["hidden_dim"] != 128 or config["model"]["dropout"] != 0.2:
        raise RuntimeError(f"Full-context seed {seed} model architecture mismatch")
    queue = read_json(ROOT / "outputs/corrected_surface_v1/queue_status.json")
    queue_entry = next((entry for entry in queue["runs"] if entry["name"] == path.name), None)
    if queue_entry is None or "--max-grad-norm 5" not in queue_entry["command"]:
        raise RuntimeError(f"Full-context seed {seed} max-gradient-norm provenance is missing")
    if "test" in metrics or (path / "test_predictions.jsonl").exists():
        raise RuntimeError(f"Historical-test output detected for full-context seed {seed}")
    return {
        "seed": seed,
        "directory": str(path.relative_to(ROOT)),
        "checkpoint": str((path / "model.pt").relative_to(ROOT)),
        "checkpoint_sha256": sha256(path / "model.pt"),
        "config": str((path / "config.json").relative_to(ROOT)),
        "config_sha256": sha256(path / "config.json"),
        "training_git_commit": config["git_commit"],
        "validation_f1": metrics["validation"]["overall"]["machine_f1"],
    }


def freeze_tfidf() -> dict[str, Any]:
    validation_reference = ROOT / "outputs/corrected_surface_v1/tfidf/combined/validation_predictions.jsonl"
    metrics_reference = ROOT / "outputs/corrected_surface_v1/tfidf/combined/metrics.json"
    if not validation_reference.is_file() or not metrics_reference.is_file():
        raise FileNotFoundError("Corrected combined TF-IDF validation references are missing")

    config = {
        "type": "TF-IDF FeatureUnion plus logistic regression",
        "feature_mode": "corrected_surface_word_plus_character",
        "training_split": "raid_en_balanced/train.jsonl",
        "validation_selection_split": "raid_en_balanced/validation.jsonl",
        "word_vectorizer": {
            "analyzer": "word", "ngram_range": [1, 2], "max_features": 100000,
            "min_df": 2, "lowercase": True,
        },
        "character_vectorizer": {
            "analyzer": "char_wb", "ngram_range": [3, 5], "max_features": 100000,
            "min_df": 2, "lowercase": True,
        },
        "classifier": {
            "type": "LogisticRegression", "class_weight": "balanced", "max_iter": 1000,
            "solver": "liblinear", "random_state": 42,
        },
        "source_script": "scripts/train_surface_tfidf.py",
        "source_script_sha256": sha256(ROOT / "scripts/train_surface_tfidf.py"),
    }
    train = load_jsonl(DATA / "train.jsonl")
    validation = load_jsonl(DATA / "validation.jsonl")
    word = TfidfVectorizer(analyzer="word", ngram_range=(1, 2), max_features=100000, min_df=2, lowercase=True)
    char = TfidfVectorizer(analyzer="char_wb", ngram_range=(3, 5), max_features=100000, min_df=2, lowercase=True)
    model = Pipeline([
        ("tfidf", FeatureUnion([("word", word), ("char", char)])),
        ("classifier", LogisticRegression(
            class_weight="balanced", max_iter=1000, solver="liblinear", random_state=42
        )),
    ])
    model.fit([row["text"] for row in train], [row["label_id"] for row in train])
    predictions = model.predict([row["text"] for row in validation]).astype(int)
    probabilities = model.predict_proba([row["text"] for row in validation])[:, 1]
    reference = load_jsonl(validation_reference)
    if [row["id"] for row in validation] != [row["id"] for row in reference]:
        raise RuntimeError("TF-IDF reconstruction validation row order differs from frozen reference")
    if predictions.tolist() != [int(row["predicted_label_id"]) for row in reference]:
        raise RuntimeError("TF-IDF reconstruction does not reproduce frozen validation predictions")
    reference_probabilities = np.array([float(row["machine_probability"]) for row in reference])
    maximum_probability_difference = float(np.max(np.abs(probabilities - reference_probabilities)))
    if maximum_probability_difference > 1e-12:
        raise RuntimeError(
            f"TF-IDF reconstruction probability mismatch: max difference {maximum_probability_difference}"
        )

    artifact = FROZEN / "tfidf_wordchar.joblib"
    config_path = FROZEN / "tfidf_wordchar_config.json"
    joblib.dump(model, artifact)
    write_json(config_path, config)
    metrics = read_json(metrics_reference)
    return {
        "artifact": str(artifact.relative_to(ROOT)),
        "artifact_sha256": sha256(artifact),
        "config": str(config_path.relative_to(ROOT)),
        "config_sha256": sha256(config_path),
        "validation_reference": str(validation_reference.relative_to(ROOT)),
        "validation_reference_sha256": sha256(validation_reference),
        "validation_f1": metrics["validation"]["overall"]["machine_f1"],
        "reconstruction_max_probability_difference": maximum_probability_difference,
        "reconstruction_predictions_exact": True,
    }


def main() -> None:
    os.chdir(ROOT)
    manifest_path = OUT / "freeze_manifest.json"
    if manifest_path.exists():
        raise FileExistsError(f"Refusing to overwrite existing {manifest_path}")
    OUT.mkdir(parents=True, exist_ok=True)
    if FROZEN.exists() and any(FROZEN.iterdir()):
        raise FileExistsError(f"Refusing to overwrite non-empty {FROZEN}")
    FROZEN.mkdir(parents=True, exist_ok=True)

    rationale = [
        verify_rationale(
            ROOT / f"outputs/final_model_campaign/stage2_runs/stage2_rationale_ctx512_budget40_seed{seed}",
            seed,
        )
        for seed in SEEDS
    ]
    full_context = [
        verify_full_context(
            ROOT / f"outputs/corrected_surface_v1/runs/priority3_full_context_bilstm_ctx512_seed{seed}",
            seed,
        )
        for seed in SEEDS
    ]
    tfidf = freeze_tfidf()

    with (ROOT / "outputs/final_model_campaign/stage1_aggregate.csv").open(newline="", encoding="utf-8") as handle:
        stage1 = list(csv.DictReader(handle))
    with (ROOT / "outputs/final_model_campaign/stage2_aggregate.csv").open(newline="", encoding="utf-8") as handle:
        stage2 = list(csv.DictReader(handle))

    current_commit = git_commit()
    tokenizer = ROOT / "src/detectgpt/rationales/vocab.py"
    manifest = {
        "freeze_status": "approved_and_frozen",
        "frozen_at": datetime.now(timezone.utc).isoformat(),
        "current_git_commit": current_commit,
        "decision_data": "validation_only",
        "historical_test_used_for_model_selection_or_evaluation": False,
        "frozen_operating_point": {
            "context_tokens": 512,
            "rationale_budget_fraction": 0.4,
            "seeds": list(SEEDS),
            "seed_policy": "report_all_predeclared_seeds_and_mean_sd; no preferred seed",
        },
        "rationale_models": rationale,
        "matched_full_context_models": full_context,
        "traditional_baseline": tfidf,
        "preprocessing": {
            "dataset_builder": "scripts/build_raid_en_balanced.py",
            "dataset_builder_sha256": sha256(ROOT / "scripts/build_raid_en_balanced.py"),
            "tokenizer": "src/detectgpt/rationales/vocab.py",
            "tokenizer_sha256": sha256(tokenizer),
            "tokenizer_version": "case-and-punctuation-preserving Unicode surface tokenizer",
            "token_pattern": r"\w+|[^\w\s]",
        },
        "training_dataset_hashes": {
            "train.jsonl": sha256(DATA / "train.jsonl"),
            "validation.jsonl": sha256(DATA / "validation.jsonl"),
            "stats.json": sha256(DATA / "stats.json"),
        },
        "validation_results_used_for_decision": {
            "context_experiment": stage1,
            "budget_experiment": stage2,
        },
        "freeze_rules": {
            "additional_tuning_permitted": False,
            "seed_selection_permitted": False,
            "ensemble_predeclared": False,
            "historical_test_retired": True,
            "human_study_model_separate_and_untouched": True,
        },
    }
    write_json(manifest_path, manifest)
    print(json.dumps({
        "freeze_manifest": str(manifest_path),
        "rationale_checkpoints": len(rationale),
        "full_context_checkpoints": len(full_context),
        "tfidf_reproduced": True,
        "tfidf_validation_max_probability_difference": tfidf["reconstruction_max_probability_difference"],
    }, indent=2))


if __name__ == "__main__":
    main()
