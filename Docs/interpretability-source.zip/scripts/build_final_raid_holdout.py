#!/usr/bin/env python3
"""Construct the immutable, detector-blind final RAID holdout."""
from __future__ import annotations

import csv
import hashlib
import json
import os
import random
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import datasets
from datasets import load_dataset

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "outputs/final_evaluation"
HOLDOUT = OUT / "holdout"
SEED = 20260818
DOMAINS = ("abstracts", "books", "news", "poetry")
GENERATORS = ("gpt2", "mistral", "mistral-chat", "llama-chat", "chatgpt", "gpt4")
PER_DOMAIN_GENERATOR = 25
TARGET_ROWS = 1200
SHUFFLE_BUFFER = 100_000


def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def text_key(text: str) -> str:
    return sha256_bytes(text.strip().encode("utf-8"))


def read_jsonl(path: Path):
    with path.open(encoding="utf-8") as handle:
        for line in handle:
            if line.strip():
                yield json.loads(line)


def write_json(path: Path, payload: dict[str, Any]) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    os.replace(temporary, path)


def prior_exclusions() -> tuple[set[str], set[str], dict[str, set[str]], dict[str, set[str]]]:
    all_sources: set[str] = set()
    all_texts: set[str] = set()
    v3_sources: dict[str, set[str]] = {}
    v3_texts: dict[str, set[str]] = {}
    for version in ("raid_core_en_v1", "raid_core_en_v2", "raid_core_en_v3"):
        base = ROOT / "data/processed" / version
        for split in ("train", "validation", "test"):
            rows = list(read_jsonl(base / f"{split}.jsonl"))
            sources = {str(row["source_id"]) for row in rows}
            texts = {text_key(str(row["text"])) for row in rows}
            all_sources.update(sources)
            all_texts.update(texts)
            if version == "raid_core_en_v3":
                v3_sources[split] = sources
                v3_texts[split] = texts

    human_study_sources: set[str] = set()
    human_study_ids: set[str] = set()
    with (ROOT / "outputs/human_study_final/final_20_pool.csv").open(newline="", encoding="utf-8") as handle:
        for row in csv.DictReader(handle):
            human_study_ids.add(row["passage_id"])
            human_study_sources.add(row["source_id"])
    all_sources.update(human_study_sources)
    return all_sources, all_texts, v3_sources, v3_texts


def eligible(row: dict[str, Any], excluded_sources: set[str], excluded_texts: set[str]) -> bool:
    text = row.get("generation")
    source_id = row.get("source_id")
    model = row.get("model")
    if not isinstance(text, str) or not text.strip() or not isinstance(source_id, str) or not source_id:
        return False
    if source_id in excluded_sources or text_key(text) in excluded_texts:
        return False
    if row.get("domain") not in DOMAINS or model not in ("human", *GENERATORS):
        return False
    if row.get("attack") != "none" or len(text.split()) < 80:
        return False
    if model == "human":
        return row.get("decoding") is None
    return row.get("decoding") == "sampling"


def choose_assignments(
    humans: dict[tuple[str, str], dict[str, Any]],
    machines: dict[tuple[str, str], dict[str, dict[str, Any]]],
) -> dict[str, list[tuple[str, str]]] | None:
    result: dict[str, list[tuple[str, str]]] = {}
    for domain in DOMAINS:
        triples: list[tuple[str, str, str]] = []
        for (candidate_domain, source_id), by_generator in machines.items():
            if candidate_domain != domain or (domain, source_id) not in humans:
                continue
            for generator in GENERATORS:
                if generator in by_generator:
                    rank = sha256_bytes(f"{SEED}:{domain}:{generator}:{source_id}".encode())
                    triples.append((rank, source_id, generator))
        triples.sort()
        counts = Counter()
        used_sources: set[str] = set()
        assignments: list[tuple[str, str]] = []
        for _, source_id, generator in triples:
            if source_id in used_sources or counts[generator] >= PER_DOMAIN_GENERATOR:
                continue
            used_sources.add(source_id)
            counts[generator] += 1
            assignments.append((source_id, generator))
            if all(counts[generator] == PER_DOMAIN_GENERATOR for generator in GENERATORS):
                break
        if any(counts[generator] != PER_DOMAIN_GENERATOR for generator in GENERATORS):
            return None
        result[domain] = assignments
    return result


def generator_type(generator: str) -> str:
    if generator == "human":
        return "human"
    if generator in {"gpt2", "mistral", "mistral-chat", "llama-chat"}:
        return "open_weight_or_open_available"
    return "closed"


def convert(row: dict[str, Any], *, final_id: str) -> dict[str, Any]:
    generator = str(row["model"])
    label = "human" if generator == "human" else "machine"
    text = str(row["generation"])
    return {
        "id": final_id,
        "raid_id": row["id"],
        "text": text,
        "label": label,
        "label_id": 0 if label == "human" else 1,
        "language": "en",
        "domain": row["domain"],
        "source_dataset": "RAID",
        "source_id": row["source_id"],
        "adv_source_id": row.get("adv_source_id"),
        "generator": generator,
        "generator_type": generator_type(generator),
        "decoding": row.get("decoding"),
        "repetition_penalty": row.get("repetition_penalty"),
        "attack": row.get("attack"),
        "title": row.get("title"),
        "prompt": row.get("prompt"),
        "split": "final_holdout",
        "word_count": len(text.split()),
    }


def audit(
    rows: list[dict[str, Any]],
    all_prior_sources: set[str],
    all_prior_texts: set[str],
    v3_sources: dict[str, set[str]],
    v3_texts: dict[str, set[str]],
    human_study_sources: set[str],
    human_study_ids: set[str],
) -> dict[str, Any]:
    sources = {row["source_id"] for row in rows}
    texts = [text_key(row["text"]) for row in rows]
    ids = [row["id"] for row in rows]
    label_counts = Counter(row["label"] for row in rows)
    domain_counts = Counter(row["domain"] for row in rows)
    generator_counts = Counter(row["generator"] for row in rows if row["label"] == "machine")
    domain_label_counts = Counter((row["domain"], row["label"]) for row in rows)
    domain_generator_counts = Counter(
        (row["domain"], row["generator"]) for row in rows if row["label"] == "machine"
    )
    checks = {
        "row_count_1200": len(rows) == 1200,
        "label_balance_600_600": label_counts == {"human": 600, "machine": 600},
        "domains_300_each": all(domain_counts[domain] == 300 for domain in DOMAINS),
        "domain_labels_150_each": all(
            domain_label_counts[(domain, label)] == 150
            for domain in DOMAINS for label in ("human", "machine")
        ),
        "machine_generators_100_each": all(generator_counts[g] == 100 for g in GENERATORS),
        "domain_generators_25_each": all(
            domain_generator_counts[(domain, generator)] == 25
            for domain in DOMAINS for generator in GENERATORS
        ),
        "source_overlap_train_zero": not (sources & v3_sources["train"]),
        "source_overlap_validation_zero": not (sources & v3_sources["validation"]),
        "source_overlap_historical_test_zero": not (sources & v3_sources["test"]),
        "source_overlap_all_prior_processed_zero": not (sources & all_prior_sources),
        "source_overlap_human_study_zero": not (sources & human_study_sources),
        "id_overlap_human_study_zero": not (set(ids) & human_study_ids),
        "exact_text_overlap_train_zero": not (set(texts) & v3_texts["train"]),
        "exact_text_overlap_validation_zero": not (set(texts) & v3_texts["validation"]),
        "exact_text_overlap_historical_test_zero": not (set(texts) & v3_texts["test"]),
        "exact_text_overlap_all_prior_processed_zero": not (set(texts) & all_prior_texts),
        "internal_exact_text_duplicates_zero": len(texts) == len(set(texts)),
        "internal_id_duplicates_zero": len(ids) == len(set(ids)),
        "paired_unique_sources_600": len(sources) == 600 and all(
            sum(row["source_id"] == source for row in rows) == 2 for source in sources
        ),
        "eligibility_all_satisfied": all(
            row["language"] == "en"
            and row["domain"] in DOMAINS
            and row["attack"] == "none"
            and row["word_count"] >= 80
            and (
                (row["generator"] == "human" and row["decoding"] is None)
                or (row["generator"] in GENERATORS and row["decoding"] == "sampling")
            )
            for row in rows
        ),
    }
    return {
        "checks": checks,
        "all_checks_passed": all(checks.values()),
        "counts": {
            "rows": len(rows),
            "unique_source_ids": len(sources),
            "labels": dict(label_counts),
            "domains": dict(domain_counts),
            "machine_generators": dict(generator_counts),
            "domain_labels": {f"{d}::{l}": n for (d, l), n in sorted(domain_label_counts.items())},
            "domain_machine_generators": {
                f"{d}::{g}": n for (d, g), n in sorted(domain_generator_counts.items())
            },
        },
        "overlap_counts": {
            "source_train": len(sources & v3_sources["train"]),
            "source_validation": len(sources & v3_sources["validation"]),
            "source_historical_test": len(sources & v3_sources["test"]),
            "source_all_prior_processed": len(sources & all_prior_sources),
            "source_human_study": len(sources & human_study_sources),
            "id_human_study": len(set(ids) & human_study_ids),
            "text_train": len(set(texts) & v3_texts["train"]),
            "text_validation": len(set(texts) & v3_texts["validation"]),
            "text_historical_test": len(set(texts) & v3_texts["test"]),
            "text_all_prior_processed": len(set(texts) & all_prior_texts),
            "internal_text_duplicates": len(texts) - len(set(texts)),
            "internal_id_duplicates": len(ids) - len(set(ids)),
        },
    }


def main() -> None:
    if not (OUT / "freeze_manifest.json").is_file():
        raise RuntimeError("Freeze manifest must exist before holdout construction")
    if HOLDOUT.exists():
        raise FileExistsError(f"Refusing to overwrite existing {HOLDOUT}")
    HOLDOUT.mkdir(parents=True)

    all_sources, all_texts, v3_sources, v3_texts = prior_exclusions()
    human_study_sources: set[str] = set()
    human_study_ids: set[str] = set()
    with (ROOT / "outputs/human_study_final/final_20_pool.csv").open(newline="", encoding="utf-8") as handle:
        for row in csv.DictReader(handle):
            human_study_ids.add(row["passage_id"])
            human_study_sources.add(row["source_id"])

    stream = load_dataset("liamdugan/raid", streaming=True)["train"].shuffle(
        buffer_size=SHUFFLE_BUFFER, seed=SEED
    )
    humans: dict[tuple[str, str], dict[str, Any]] = {}
    machines: dict[tuple[str, str], dict[str, dict[str, Any]]] = defaultdict(dict)
    seen_row_ids: set[str] = set()
    rows_scanned = 0
    eligible_rows = 0
    assignments = None
    for row in stream:
        rows_scanned += 1
        row_id = str(row.get("id"))
        if row_id in seen_row_ids or not eligible(row, all_sources, all_texts):
            continue
        seen_row_ids.add(row_id)
        eligible_rows += 1
        key = (str(row["domain"]), str(row["source_id"]))
        if row["model"] == "human":
            humans.setdefault(key, row)
        else:
            machines[key].setdefault(str(row["model"]), row)
        if eligible_rows % 1000 == 0:
            assignments = choose_assignments(humans, machines)
            print(
                f"scanned={rows_scanned} eligible={eligible_rows} humans={len(humans)} "
                f"machine_sources={len(machines)} feasible={'yes' if assignments else 'no'}",
                flush=True,
            )
            if assignments is not None:
                break

    if assignments is None:
        assignments = choose_assignments(humans, machines)
    if assignments is None:
        failure = {
            "status": "exact_design_not_feasible",
            "rows_scanned": rows_scanned,
            "eligible_rows": eligible_rows,
            "candidate_human_sources": len(humans),
            "candidate_machine_sources": len(machines),
            "selection_seed": SEED,
            "design_changed": False,
            "models_loaded_or_run": False,
        }
        write_json(HOLDOUT / "feasibility_failure.json", failure)
        raise RuntimeError("Exact 1,200-row balanced holdout was not feasible; no holdout or inference created")

    rows: list[dict[str, Any]] = []
    for domain in DOMAINS:
        for source_id, generator in assignments[domain]:
            human = humans[(domain, source_id)]
            machine = machines[(domain, source_id)][generator]
            rows.append(convert(human, final_id=f"final-{human['id']}"))
            rows.append(convert(machine, final_id=f"final-{machine['id']}"))
    random.Random(SEED).shuffle(rows)
    if len(rows) != TARGET_ROWS:
        raise RuntimeError(f"Internal selection error: selected {len(rows)} rows")

    audit_result = audit(
        rows, all_sources, all_texts, v3_sources, v3_texts, human_study_sources, human_study_ids
    )
    if not audit_result["all_checks_passed"]:
        write_json(HOLDOUT / "failed_holdout_audit.json", audit_result)
        raise RuntimeError("Holdout audit failed; final holdout was not frozen")

    holdout_path = HOLDOUT / "final_holdout.jsonl"
    with holdout_path.open("w", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n")
    ids_path = HOLDOUT / "final_holdout_ids.txt"
    ids_path.write_text("\n".join(row["id"] for row in rows) + "\n", encoding="utf-8")
    holdout_hash = sha256(holdout_path)
    hash_path = HOLDOUT / "final_holdout_sha256.txt"
    hash_path.write_text(f"{holdout_hash}  final_holdout.jsonl\n", encoding="utf-8")

    manifest = {
        "status": "immutable_frozen_before_inference",
        "frozen_at": datetime.now(timezone.utc).isoformat(),
        "source_dataset": "liamdugan/raid",
        "source_split": "train",
        "datasets_library_version": datasets.__version__,
        "selection_seed": SEED,
        "selection_method": (
            "fixed-seed 100,000-row-buffer stream shuffle; detector-blind eligibility filtering; "
            "SHA-256 seeded candidate ordering with unique source assignment"
        ),
        "shuffle_buffer": SHUFFLE_BUFFER,
        "rows_scanned": rows_scanned,
        "eligible_rows_seen": eligible_rows,
        "models_loaded_or_run_during_selection": False,
        "detector_outputs_used_for_selection": False,
        "historical_test_access": "identifiers and exact-text hashes only for exclusion audit; never inference",
        "excluded_processed_dataset_versions": ["raid_core_en_v1", "raid_core_en_v2", "raid_core_en_v3"],
        "holdout_file": "final_holdout.jsonl",
        "holdout_sha256": holdout_hash,
        "ids_file": "final_holdout_ids.txt",
        "ids_sha256": sha256(ids_path),
        "audit": audit_result,
        "immutable_after_hash": True,
    }
    write_json(HOLDOUT / "final_holdout_manifest.json", manifest)

    counts = audit_result["counts"]
    overlaps = audit_result["overlap_counts"]
    lines = [
        "# Final holdout audit",
        "",
        "**Status: PASS — immutable holdout frozen before model inference.**",
        "",
        f"- Rows: {counts['rows']}",
        f"- Labels: {counts['labels']}",
        f"- Domains: {counts['domains']}",
        f"- Machine generators: {counts['machine_generators']}",
        f"- Unique paired source IDs: {counts['unique_source_ids']}",
        f"- SHA-256: `{holdout_hash}`",
        f"- Selection seed: {SEED}",
        f"- Raw rows scanned: {rows_scanned}",
        "",
        "## Exclusion and integrity checks",
        "",
    ]
    for name, passed in audit_result["checks"].items():
        lines.append(f"- {'PASS' if passed else 'FAIL'}: {name}")
    lines += [
        "",
        "Historical test rows were accessed only to construct source-ID and exact-text exclusion sets. "
        "No model was run on the historical test, and no historical-test outcome was inspected.",
        "",
        f"Overlap counts: `{json.dumps(overlaps, sort_keys=True)}`",
    ]
    (HOLDOUT / "holdout_audit.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(json.dumps({
        "status": "PASS",
        "rows": len(rows),
        "holdout_sha256": holdout_hash,
        "rows_scanned": rows_scanned,
        "all_checks_passed": True,
    }, indent=2))


if __name__ == "__main__":
    main()
