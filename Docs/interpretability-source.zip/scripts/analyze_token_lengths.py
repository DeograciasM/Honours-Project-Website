from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

from detectgpt.data.io import load_dataset_splits
from detectgpt.rationales.vocab import tokenize


def main() -> None:
    parser = argparse.ArgumentParser(description="Measure RAID token coverage at max lengths 256 and 512.")
    parser.add_argument("--data-dir", required=True, type=Path)
    parser.add_argument("--output", default=None, type=Path)
    args = parser.parse_args()
    rows = load_dataset_splits(args.data_dir, ("train", "validation", "test"))
    result = {"dataset_version": args.data_dir.name, "splits": {}}
    for split, split_rows in rows.items():
        lengths = np.array([len(tokenize(str(row["text"]))) for row in split_rows], dtype=int)
        split_result = {
            "documents": len(lengths),
            "mean_tokens": float(lengths.mean()),
            "median_tokens": float(np.median(lengths)),
            "p90_tokens": float(np.percentile(lengths, 90)),
            "p95_tokens": float(np.percentile(lengths, 95)),
            "p99_tokens": float(np.percentile(lengths, 99)),
            "maximum_tokens": int(lengths.max()),
        }
        for limit in (256, 512):
            split_result[f"limit_{limit}"] = {
                "documents_truncated": int((lengths > limit).sum()),
                "document_coverage": float((lengths <= limit).mean()),
                "token_coverage": float(np.minimum(lengths, limit).sum() / lengths.sum()),
            }
        result["splits"][split] = split_result
    payload = json.dumps(result, indent=2, sort_keys=True) + "\n"
    print(payload, end="")
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(payload, encoding="utf-8")


if __name__ == "__main__":
    main()
