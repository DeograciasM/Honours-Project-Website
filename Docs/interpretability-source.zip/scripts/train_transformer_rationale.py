from __future__ import annotations

import argparse

from detectgpt.rationales.transformer_experiment import add_common_arguments, run_experiment


def main() -> None:
    parser = argparse.ArgumentParser(description="Train a word-level HardKuma Transformer rationale model.")
    add_common_arguments(parser, rationale=True)
    run_experiment(parser.parse_args(), "rationale")


if __name__ == "__main__":
    main()
