from __future__ import annotations

import argparse
import json
import math
import random
import sys
from pathlib import Path
from typing import Any

import torch

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from detectgpt.data.io import load_dataset_splits
from detectgpt.evaluation.metrics import evaluate_split
from detectgpt.rationales.kuma_model import KumaRationaleModel
from detectgpt.rationales.vocab import Vocabulary
from scripts.train_kuma_rationale import TokenDataset, make_loader


def load_model(run_dir: Path, device: torch.device) -> tuple[KumaRationaleModel, Vocabulary, dict[str, Any]]:
    config = json.loads((run_dir / "config.json").read_text(encoding="utf-8"))
    vocab_payload = json.loads((run_dir / "vocab.json").read_text(encoding="utf-8"))
    token_to_id = vocab_payload.get("token_to_id", vocab_payload)
    vocab = Vocabulary(token_to_id={str(token): int(index) for token, index in token_to_id.items()})
    model_config = config["model"]
    gate_config = model_config.get("gate", {})
    model = KumaRationaleModel(
        vocab_size=len(vocab),
        embed_dim=int(model_config.get("embed_dim", 128)),
        hidden_dim=int(model_config.get("hidden_dim", 128)),
        dropout=float(model_config.get("dropout", 0.2)),
        kuma_left=float(gate_config.get("left", -0.1)),
        kuma_right=float(gate_config.get("right", 1.1)),
        a_max=float(gate_config.get("a_max", 2.0)),
        b_min=float(gate_config.get("b_min", 0.1)),
        padding_idx=vocab.pad_id,
    ).to(device)
    checkpoint = torch.load(run_dir / "model.pt", map_location=device, weights_only=False)
    model.load_state_dict(checkpoint["model_state_dict"])
    model.eval()
    return model, vocab, config


def selected_indices(
    strategy: str,
    gate_values: list[float],
    valid_count: int,
    count: int,
    rng: random.Random,
) -> list[int]:
    count = min(valid_count, max(1, count))
    if strategy == "learned":
        return sorted(sorted(range(valid_count), key=lambda index: gate_values[index], reverse=True)[:count])
    if strategy == "random":
        return sorted(rng.sample(range(valid_count), count))
    if strategy == "first":
        return list(range(count))
    if strategy == "last":
        return list(range(valid_count - count, valid_count))
    raise ValueError(strategy)


def evaluate(args: argparse.Namespace) -> dict[str, Any]:
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model, vocab, config = load_model(args.run_dir, device)
    data_dir = args.data_dir or Path(config["data_dir"])
    rows = load_dataset_splits(data_dir, (args.split,))[args.split]
    dataset = TokenDataset(rows, vocab, max_tokens=int(config.get("max_tokens", 256)))
    loader = make_loader(dataset, args.batch_size, False, args.seed, vocab.pad_id)
    strategies = ("learned", "random", "first", "last")
    outputs = {name: {"rows": [], "predictions": [], "scores": [], "counts": []} for name in strategies}
    rng = random.Random(args.seed)
    with torch.no_grad():
        for batch in loader:
            input_ids = batch["input_ids"].to(device)
            mask = batch["mask"].to(device)
            embeddings = model.embed_tokens(input_ids)
            a, b = model.gate_parameters(embeddings, mask)
            gates = model.deterministic_gates(a, b, mask)
            for strategy in strategies:
                hard_mask = torch.zeros_like(gates)
                counts = []
                for index, (gate_row, mask_row) in enumerate(zip(gates.tolist(), mask.tolist(), strict=True)):
                    valid_count = sum(mask_row)
                    requested = args.budget if args.budget is not None else math.ceil(args.target_fraction * valid_count)
                    selected = selected_indices(strategy, gate_row, valid_count, requested, rng)
                    hard_mask[index, selected] = 1.0
                    counts.append(len(selected))
                probabilities = torch.softmax(model.predict_from_gates(embeddings, hard_mask, mask), dim=1)[:, 1]
                predictions = (probabilities >= 0.5).long().tolist()
                outputs[strategy]["rows"].extend(example.row for example in batch["examples"])
                outputs[strategy]["predictions"].extend(predictions)
                outputs[strategy]["scores"].extend(probabilities.tolist())
                outputs[strategy]["counts"].extend(counts)
    result = {}
    for strategy, values in outputs.items():
        metrics = evaluate_split(values["rows"], values["predictions"], values["scores"])
        metrics["selection"] = {
            "average_selected_tokens": sum(values["counts"]) / len(values["counts"]),
            "minimum_selected_tokens": min(values["counts"]),
            "maximum_selected_tokens": max(values["counts"]),
            "fixed_budget": args.budget,
            "target_fraction": None if args.budget is not None else args.target_fraction,
        }
        result[strategy] = metrics
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    for strategy in strategies:
        overall = result[strategy]["overall"]
        auroc = f"{overall['auroc']:.4f}" if overall["auroc"] is not None else "undefined"
        print(
            f"{strategy}: accuracy={overall['accuracy']:.4f} f1={overall['machine_f1']:.4f} "
            f"auroc={auroc} avg_tokens={result[strategy]['selection']['average_selected_tokens']:.2f}"
        )
    return result


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Compare learned top-k rationales with matched position/random controls.")
    parser.add_argument("--run-dir", required=True, type=Path)
    parser.add_argument("--data-dir", default=None, type=Path)
    parser.add_argument("--split", default="test", choices=["validation", "test"])
    group = parser.add_mutually_exclusive_group()
    group.add_argument("--target-fraction", default=0.30, type=float)
    group.add_argument("--budget", default=None, type=int, help="Fixed token count per document, capped by length.")
    parser.add_argument("--batch-size", default=32, type=int)
    parser.add_argument("--seed", default=42, type=int)
    parser.add_argument("--output", default=None, type=Path)
    return parser.parse_args()


if __name__ == "__main__":
    evaluate(parse_args())
