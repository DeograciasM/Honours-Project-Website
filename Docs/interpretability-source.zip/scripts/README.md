# Script index

Active scripts use repository-relative paths and are grouped by purpose below. Exact final commands and configuration values are in `../docs/final_pipeline_manifest.md` and `../configs/final/`.

## Data

- `build_raid_en_balanced.py`: deterministic final split builder. It requires a removed historical intermediate and is not currently an upstream-only bootstrap.
- `validate_raid_en_balanced.py`: validates fields, labels, split annotations, IDs, and duplicate text.
- `check_source_leakage.py`: reports any `source_id` occurring in more than one split.
- `analyze_token_lengths.py` and `audit_surface_representation.py`: representation diagnostics.
- `build_final_raid_holdout.py`: provenance source for the detector-blind holdout construction; its historical inputs are not retained.

## Training

- `train_surface_tfidf.py`: final word/character TF-IDF selection entry point.
- `train_tfidf_baseline.py`: earlier reusable TF-IDF entry point.
- `train_full_context_bilstm.py`: matched full-context BiLSTM.
- `train_kuma_rationale.py`: final HardKuma BiLSTM rationale model.
- `train_transformer_full_context.py`: local Transformer full-context entry point.
- `train_transformer_rationale.py`: local Transformer HardKuma entry point.
- `train_heldout_generator.py`: exploratory TF-IDF transfer diagnostic, not a final experiment.

Every active final trainer writes to a caller-supplied output directory and refuses to overwrite a non-empty directory.

## Evaluation

- `evaluate_rationale_strategies.py`: saved-checkpoint rationale controls and faithfulness diagnostics.
- `evaluate_transformer.py`: evaluates a restored Transformer run directory.
- `verify_hardkuma_ratefix.py`: independent HardKuma artifact checks.
- `run_punctuation_diagnostic.py`: surface-tokenizer diagnostic.

The following scripts preserve the closed final-evaluation procedure:

- `prepare_final_evaluation_freeze.py`
- `prepare_final_evaluation.py`
- `run_final_evaluation.py`
- `finalize_final_evaluation.py`

They are provenance code, not permission to repeat final-test model selection. `finalize_final_evaluation.py` uses saved predictions only and records the one-class AUROC reporting recovery.

## Analysis and figures

- `analysis/generate_sweep_figures.py`: regenerates compact context/budget figures from frozen aggregate metrics.
- `analysis/plot_selected_tokens.py`: renders the selected-token illustration.

Final compact outputs are under `../results/final/`.

## Submission validation

- `submission_inventory.py`: enforces the examiner-package allowlist, verifies model and file checksums, reports the exact uncompressed payload size, and can load every selected model on CPU. It never creates an archive.

## Human study

The active analysis lives under `../human_study_analysis/scripts/`. The exact final 512/40/seed-44 stimulus renderer is missing; superseded 256-token builders remain recoverable from Git history but are deliberately not presented as active scripts. See `../docs/human_study_reproducibility.md`.

## Historical code

`legacy/pre_surface_analysis/` contains the old-tokenizer analysis formerly named `final_analysis`. It is retained for provenance only. Other deleted one-off launch queues and superseded model scripts remain recoverable from Git history and are reviewed in `../docs/archive/tracked_deletions_review_2026_09_17.md`.
