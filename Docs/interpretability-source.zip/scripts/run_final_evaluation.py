#!/usr/bin/env python3
"""Run the approved, frozen corrected-pipeline evaluation on the final test split once."""
from __future__ import annotations

import csv
import hashlib
import json
import math
import os
import platform
import random
import statistics
import subprocess
import sys
import time
from collections import defaultdict
from datetime import datetime, timezone
from itertools import combinations
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
for import_root in (ROOT, SRC):
    if str(import_root) not in sys.path:
        sys.path.insert(0, str(import_root))

import joblib
import numpy as np
import torch
from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score, roc_auc_score

from detectgpt.baselines.bilstm import FullContextBiLSTM
from detectgpt.data.io import load_dataset_splits, write_jsonl
from detectgpt.evaluation.metrics import paired_bootstrap_f1
from detectgpt.rationales.vocab import Vocabulary, tokenize
from scripts.evaluate_rationale_strategies import load_model as load_rationale_model
from scripts.train_kuma_rationale import TokenDataset, make_loader, select_topk_tokens


OUT = ROOT / "outputs/final_evaluation/raid_en_balanced"
DATA = ROOT / "data/processed/raid_en_balanced"
MODEL_ROOT = ROOT / "artifacts/models"
SEEDS = (42, 43, 44)
RANDOM_CONTROL_SEEDS = (3101, 3102, 3103, 3104, 3105)
BOOTSTRAP_SEED = 20260818
BOOTSTRAP_RESAMPLES = 10_000
REQUIRED_DEVICE = "mps"


def read_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line]


def write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    os.replace(temporary, path)


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        raise ValueError(f"Refusing to write empty CSV: {path}")
    fields: list[str] = []
    for row in rows:
        for key in row:
            if key not in fields:
                fields.append(key)
    temporary = path.with_suffix(path.suffix + ".tmp")
    with temporary.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)
    os.replace(temporary, path)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def git_commit() -> str | None:
    try:
        return subprocess.run(
            ["git", "rev-parse", "HEAD"], cwd=ROOT, check=True, capture_output=True, text=True
        ).stdout.strip()
    except (OSError, subprocess.CalledProcessError):
        return None


def load_vocab(run_dir: Path) -> Vocabulary:
    payload = read_json(run_dir / "vocab.json")
    token_to_id = payload.get("token_to_id", payload)
    return Vocabulary(token_to_id={str(token): int(index) for token, index in token_to_id.items()})


def machine_probability(row: dict[str, Any]) -> float:
    return float(row.get("probability_machine", row.get("machine_probability")))


def overall_metrics(rows: list[dict[str, Any]]) -> dict[str, Any]:
    truth = [int(row["label_id"]) for row in rows]
    probabilities = [machine_probability(row) for row in rows]
    predictions = [int(row["predicted_label_id"]) for row in rows]
    return {
        "support": len(rows),
        "accuracy": float(accuracy_score(truth, predictions)),
        "machine_precision": float(precision_score(truth, predictions, zero_division=0)),
        "machine_recall": float(recall_score(truth, predictions, zero_division=0)),
        "machine_f1": float(f1_score(truth, predictions, zero_division=0)),
        "auroc": float(roc_auc_score(truth, probabilities)) if len(set(truth)) == 2 else None,
    }


def length_band(token_count: int) -> str:
    if token_count <= 128:
        return "1-128"
    if token_count <= 256:
        return "129-256"
    if token_count <= 512:
        return "257-512"
    return ">512"


def load_full_context(run_dir: Path, device: torch.device) -> tuple[FullContextBiLSTM, Vocabulary, dict[str, Any]]:
    config = read_json(run_dir / "config.json")
    vocab = load_vocab(run_dir)
    model_config = config["model"]
    model = FullContextBiLSTM(
        len(vocab),
        embed_dim=int(model_config["embed_dim"]),
        hidden_dim=int(model_config["hidden_dim"]),
        dropout=float(model_config["dropout"]),
        pretrained_embeddings=None,
        freeze_embeddings=False,
        padding_idx=vocab.pad_id,
    )
    checkpoint = torch.load(run_dir / "model.pt", map_location="cpu", weights_only=False)
    model.load_state_dict(checkpoint["model_state_dict"])
    model.to(device).eval()
    return model, vocab, config


def evaluate_tfidf(test_rows: list[dict[str, Any]]) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    started = time.monotonic()
    artifact = MODEL_ROOT / "tfidf/model.joblib"
    model = joblib.load(artifact)
    texts = [str(row["text"]) for row in test_rows]
    predictions = model.predict(texts).astype(int).tolist()
    probabilities = model.predict_proba(texts)[:, 1].astype(float).tolist()
    rows = []
    for source, prediction, probability in zip(test_rows, predictions, probabilities, strict=True):
        rows.append(
            {
                **source,
                "predicted_label_id": int(prediction),
                "predicted_label": "machine" if prediction else "human",
                "machine_probability": float(probability),
                "prediction_mode": "surface_word_character_tfidf_logistic_regression",
                "original_token_count": len(tokenize(str(source["text"]))),
            }
        )
    metrics = {"overall": overall_metrics(rows), "runtime_seconds": time.monotonic() - started, "device": "cpu"}
    return rows, metrics


def evaluate_full_context(
    run_dir: Path,
    test_rows: list[dict[str, Any]],
    device: torch.device,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    started = time.monotonic()
    model, vocab, config = load_full_context(run_dir, device)
    loader = make_loader(
        TokenDataset(test_rows, vocab, max_tokens=512),
        int(config["batch_size"]),
        False,
        int(config["seed"]),
        vocab.pad_id,
    )
    rows: list[dict[str, Any]] = []
    with torch.no_grad():
        for batch in loader:
            probabilities = torch.softmax(
                model(batch["input_ids"].to(device), batch["mask"].to(device)), dim=1
            )[:, 1].cpu().tolist()
            for example, probability in zip(batch["examples"], probabilities, strict=True):
                prediction = int(probability >= 0.5)
                rows.append(
                    {
                        **example.row,
                        "predicted_label_id": prediction,
                        "predicted_label": "machine" if prediction else "human",
                        "probability_machine": float(probability),
                        "prediction_mode": "full_context_bilstm",
                        "original_token_count": len(tokenize(str(example.row["text"]))),
                        "visible_token_count": len(example.tokens),
                    }
                )
    metrics = {
        "overall": overall_metrics(rows),
        "runtime_seconds": time.monotonic() - started,
        "device": str(device),
        "seed": int(config["seed"]),
        "context_tokens": 512,
    }
    return rows, metrics


def deterministic_control_indices(
    strategy: str,
    gate_values: list[float],
    valid_count: int,
    count: int,
    example_id: str,
    random_seed: int | None = None,
) -> list[int]:
    count = min(valid_count, max(1, count))
    if strategy == "learned":
        return sorted(sorted(range(valid_count), key=lambda index: (-gate_values[index], index))[:count])
    if strategy == "first":
        return list(range(count))
    if strategy == "last":
        return list(range(valid_count - count, valid_count))
    if strategy == "random":
        if random_seed is None:
            raise ValueError("random control requires a seed")
        rng = random.Random(f"{random_seed}:{example_id}")
        return sorted(rng.sample(range(valid_count), count))
    raise ValueError(strategy)


def metrics_from_probability_key(rows: list[dict[str, Any]], key: str) -> dict[str, Any]:
    truth = [int(row["label_id"]) for row in rows]
    probabilities = [float(row[key]) for row in rows]
    predictions = [int(value >= 0.5) for value in probabilities]
    return {
        "support": len(rows),
        "accuracy": float(accuracy_score(truth, predictions)),
        "machine_precision": float(precision_score(truth, predictions, zero_division=0)),
        "machine_recall": float(recall_score(truth, predictions, zero_division=0)),
        "machine_f1": float(f1_score(truth, predictions, zero_division=0)),
        "auroc": float(roc_auc_score(truth, probabilities)),
        "mean_true_class_probability": float(
            statistics.mean(value if label else 1.0 - value for label, value in zip(truth, probabilities, strict=True))
        ),
    }


def evaluate_rationale(
    run_dir: Path,
    test_rows: list[dict[str, Any]],
    device: torch.device,
) -> tuple[list[dict[str, Any]], dict[str, Any], dict[str, Any], list[dict[str, Any]]]:
    started = time.monotonic()
    model, vocab, config = load_rationale_model(run_dir, device)
    loader = make_loader(
        TokenDataset(test_rows, vocab, max_tokens=512),
        int(config["batch_size"]),
        False,
        int(config["seed"]),
        vocab.pad_id,
    )
    primary_rows: list[dict[str, Any]] = []
    control_rows: list[dict[str, Any]] = []

    with torch.no_grad():
        for batch in loader:
            input_ids = batch["input_ids"].to(device)
            mask = batch["mask"].to(device)
            embeddings = model.embed_tokens(input_ids)
            a, b = model.gate_parameters(embeddings, mask)
            deterministic = model.deterministic_gates(a, b, mask)
            expected = model.expected_selection(a, b, mask)
            gate_rows = deterministic.cpu().tolist()
            expected_rows = expected.cpu().tolist()
            mask_rows = mask.cpu().tolist()

            selections: dict[str, list[list[int]]] = {"learned": [], "first": [], "last": []}
            for random_seed in RANDOM_CONTROL_SEEDS:
                selections[f"random_{random_seed}"] = []
            for index, example in enumerate(batch["examples"]):
                valid_count = int(sum(mask_rows[index]))
                count = min(valid_count, max(1, math.ceil(0.40 * valid_count)))
                example_id = str(example.row["id"])
                learned, fallback = select_topk_tokens(gate_rows[index], valid_count, 0.40)
                if fallback:
                    raise RuntimeError(f"Unexpected top-k fallback for {example_id}")
                stable_learned = deterministic_control_indices(
                    "learned", gate_rows[index], valid_count, count, example_id
                )
                if learned != stable_learned:
                    # Tie handling in the established evaluator is index-stable; enforce that exact result here.
                    learned = stable_learned
                selections["learned"].append(learned)
                selections["first"].append(
                    deterministic_control_indices("first", gate_rows[index], valid_count, count, example_id)
                )
                selections["last"].append(
                    deterministic_control_indices("last", gate_rows[index], valid_count, count, example_id)
                )
                for random_seed in RANDOM_CONTROL_SEEDS:
                    selections[f"random_{random_seed}"].append(
                        deterministic_control_indices(
                            "random", gate_rows[index], valid_count, count, example_id, random_seed
                        )
                    )

            probabilities: dict[str, list[float]] = {}
            hard_masks: dict[str, torch.Tensor] = {}
            for strategy, selected_by_example in selections.items():
                hard_mask = torch.zeros_like(deterministic)
                for local, selected in enumerate(selected_by_example):
                    hard_mask[local, selected] = 1.0
                hard_masks[strategy] = hard_mask
                probabilities[strategy] = torch.softmax(
                    model.predict_from_gates(embeddings, hard_mask, mask), dim=1
                )[:, 1].cpu().tolist()

            full_probability = torch.softmax(
                model.predict_from_gates(embeddings, mask.float(), mask), dim=1
            )[:, 1].cpu().tolist()
            complement_probability = torch.softmax(
                model.predict_from_gates(embeddings, mask.float() - hard_masks["learned"], mask), dim=1
            )[:, 1].cpu().tolist()

            for local, example in enumerate(batch["examples"]):
                valid_count = int(sum(mask_rows[local]))
                selected = selections["learned"][local]
                probability = float(probabilities["learned"][local])
                prediction = int(probability >= 0.5)
                full_machine = float(full_probability[local])
                complement_machine = float(complement_probability[local])
                predicted_full = full_machine if prediction else 1.0 - full_machine
                predicted_rationale = probability if prediction else 1.0 - probability
                predicted_complement = complement_machine if prediction else 1.0 - complement_machine
                primary_rows.append(
                    {
                        **example.row,
                        "predicted_label_id": prediction,
                        "predicted_label": "machine" if prediction else "human",
                        "probability_machine": probability,
                        "selected_token_indices": selected,
                        "selected_tokens": [example.tokens[index] for index in selected],
                        "token_offsets": [list(offset) for offset in example.token_offsets],
                        "selected_token_offsets": [list(example.token_offsets[index]) for index in selected],
                        "token_gate_values": [float(value) for value in gate_rows[local][:valid_count]],
                        "selected_fraction": len(selected) / valid_count,
                        "visible_token_count": valid_count,
                        "original_token_count": len(tokenize(str(example.row["text"]))),
                        "prediction_mode": "hardkuma_topk_tokens",
                        "used_empty_selection_fallback": False,
                        "full_text_probability_for_predicted_class": predicted_full,
                        "rationale_only_probability_for_predicted_class": predicted_rationale,
                        "without_rationale_probability_for_predicted_class": predicted_complement,
                        "sufficiency_drop": predicted_full - predicted_rationale,
                        "comprehensiveness_drop": predicted_full - predicted_complement,
                        "expected_nonzero_fraction": float(
                            statistics.mean(expected_rows[local][:valid_count])
                        ),
                    }
                )
                control = {
                    "id": example.row["id"],
                    "label_id": int(example.row["label_id"]),
                    "domain": example.row["domain"],
                    "generator": example.row["generator"],
                    "visible_token_count": valid_count,
                    "selected_token_count": len(selected),
                    "probability_learned": probability,
                    "probability_first": float(probabilities["first"][local]),
                    "probability_last": float(probabilities["last"][local]),
                    "indices_learned": selected,
                    "indices_first": selections["first"][local],
                    "indices_last": selections["last"][local],
                }
                random_values = []
                for random_seed in RANDOM_CONTROL_SEEDS:
                    key = f"random_{random_seed}"
                    value = float(probabilities[key][local])
                    control[f"probability_{key}"] = value
                    control[f"indices_{key}"] = selections[key][local]
                    random_values.append(value)
                control["probability_random_mean"] = float(statistics.mean(random_values))
                control_rows.append(control)

    selected_counts = [len(row["selected_token_indices"]) for row in primary_rows]
    selected_fractions = [float(row["selected_fraction"]) for row in primary_rows]
    sufficiency = [float(row["sufficiency_drop"]) for row in primary_rows]
    comprehensiveness = [float(row["comprehensiveness_drop"]) for row in primary_rows]
    expected_fractions = [float(row["expected_nonzero_fraction"]) for row in primary_rows]
    training_metrics = read_json(run_dir / "metrics.json")
    metrics = {
        "overall": overall_metrics(primary_rows),
        "runtime_seconds_including_controls": time.monotonic() - started,
        "device": str(device),
        "seed": int(config["seed"]),
        "context_tokens": 512,
        "target_selection": 0.4,
        "rationales": {
            "average_selected_fraction": float(statistics.mean(selected_fractions)),
            "average_selected_tokens": float(statistics.mean(selected_counts)),
            "median_selected_tokens": float(statistics.median(selected_counts)),
            "minimum_selected_tokens": min(selected_counts),
            "maximum_selected_tokens": max(selected_counts),
            "zero_selection_count": sum(count == 0 for count in selected_counts),
            "empty_selection_fallback_count": sum(bool(row["used_empty_selection_fallback"]) for row in primary_rows),
            "mean_expected_nonzero_fraction": float(statistics.mean(expected_fractions)),
            "mean_sufficiency_drop": float(statistics.mean(sufficiency)),
            "median_sufficiency_drop": float(statistics.median(sufficiency)),
            "mean_comprehensiveness_drop": float(statistics.mean(comprehensiveness)),
            "median_comprehensiveness_drop": float(statistics.median(comprehensiveness)),
            "constraint_satisfied_at_validation_selection": bool(training_metrics["constraint_satisfied"]),
            "best_validation_selection_fraction": float(training_metrics["best_val_fraction"]),
        },
    }
    controls = {
        "definition": "matched selected-token count at 40%; five deterministic per-example random replicates",
        "random_control_seeds": list(RANDOM_CONTROL_SEEDS),
        "learned": metrics_from_probability_key(control_rows, "probability_learned"),
        "first": metrics_from_probability_key(control_rows, "probability_first"),
        "last": metrics_from_probability_key(control_rows, "probability_last"),
        "random_mean_probability": metrics_from_probability_key(control_rows, "probability_random_mean"),
        "random_replicates": {
            str(random_seed): metrics_from_probability_key(control_rows, f"probability_random_{random_seed}")
            for random_seed in RANDOM_CONTROL_SEEDS
        },
        "faithfulness": {
            "sufficiency_definition": "p(predicted class | full visible input) - p(predicted class | learned rationale)",
            "comprehensiveness_definition": "p(predicted class | full visible input) - p(predicted class | complement)",
            "mean_sufficiency_drop": float(statistics.mean(sufficiency)),
            "median_sufficiency_drop": float(statistics.median(sufficiency)),
            "sd_sufficiency_drop": float(statistics.stdev(sufficiency)),
            "mean_comprehensiveness_drop": float(statistics.mean(comprehensiveness)),
            "median_comprehensiveness_drop": float(statistics.median(comprehensiveness)),
            "sd_comprehensiveness_drop": float(statistics.stdev(comprehensiveness)),
            "caveat": (
                "The predictor is trained on selected evidence, so sufficiency is structurally advantaged; "
                "complement-only inputs may be out of distribution. These are diagnostics, not standalone proof of faithfulness."
            ),
        },
    }
    return primary_rows, metrics, controls, control_rows


def system_label(system: str) -> str:
    return {
        "tfidf": "Corrected word+character TF-IDF",
        "full_context": "Full-context BiLSTM 512",
        "rationale": "HardKuma 512/40%",
    }[system]


def prediction_record_rows(
    tfidf_rows: list[dict[str, Any]],
    full_rows: dict[int, list[dict[str, Any]]],
    rationale_rows: dict[int, list[dict[str, Any]]],
) -> list[tuple[str, int | None, list[dict[str, Any]]]]:
    output: list[tuple[str, int | None, list[dict[str, Any]]]] = [("tfidf", None, tfidf_rows)]
    output.extend(("full_context", seed, full_rows[seed]) for seed in SEEDS)
    output.extend(("rationale", seed, rationale_rows[seed]) for seed in SEEDS)
    return output


def breakdowns(
    records: list[tuple[str, int | None, list[dict[str, Any]]]],
) -> tuple[list[dict[str, Any]], list[dict[str, Any]], list[dict[str, Any]]]:
    domain_rows: list[dict[str, Any]] = []
    length_rows: list[dict[str, Any]] = []
    generator_rows: list[dict[str, Any]] = []
    for system, seed, rows in records:
        by_domain: dict[str, list[dict[str, Any]]] = defaultdict(list)
        by_length: dict[str, list[dict[str, Any]]] = defaultdict(list)
        by_generator: dict[str, list[dict[str, Any]]] = defaultdict(list)
        for row in rows:
            by_domain[str(row["domain"])].append(row)
            by_length[length_band(int(row["original_token_count"]))].append(row)
            if int(row["label_id"]) == 1:
                by_generator[str(row["generator"])].append(row)
        for domain, group in sorted(by_domain.items()):
            metrics = overall_metrics(group)
            domain_rows.append({"system": system, "seed": seed, "domain": domain, **metrics})
        for band in ("1-128", "129-256", "257-512", ">512"):
            group = by_length[band]
            if not group:
                continue
            metrics = overall_metrics(group)
            length_rows.append({"system": system, "seed": seed, "length_band": band, **metrics})
        for generator, group in sorted(by_generator.items()):
            predictions = [int(row["predicted_label_id"]) for row in group]
            probabilities = [machine_probability(row) for row in group]
            generator_rows.append(
                {
                    "system": system,
                    "seed": seed,
                    "generator": generator,
                    "machine_support": len(group),
                    "machine_recall_detection_rate": float(statistics.mean(predictions)),
                    "mean_machine_probability": float(statistics.mean(probabilities)),
                }
            )
    return domain_rows, length_rows, generator_rows


def add_neural_aggregates(rows: list[dict[str, Any]], group_key: str, metrics: list[str]) -> list[dict[str, Any]]:
    output = list(rows)
    grouped: dict[tuple[str, str], list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        if row["seed"] is not None and row["system"] in ("full_context", "rationale"):
            grouped[(str(row["system"]), str(row[group_key]))].append(row)
    for (system, group), values in sorted(grouped.items()):
        if len(values) != 3:
            raise RuntimeError(f"Expected three seeds for {system}/{group_key}={group}")
        aggregate: dict[str, Any] = {"system": system, "seed": "mean_sd", group_key: group}
        support_key = "machine_support" if "machine_support" in values[0] else "support"
        aggregate[support_key] = values[0][support_key]
        for metric in metrics:
            numbers = [float(row[metric]) for row in values if row.get(metric) is not None and math.isfinite(float(row[metric]))]
            aggregate[f"{metric}_mean"] = statistics.mean(numbers) if numbers else None
            aggregate[f"{metric}_sd"] = statistics.stdev(numbers) if len(numbers) > 1 else None
        output.append(aggregate)
    return output


def aggregate_result_rows(per_run: list[dict[str, Any]]) -> list[dict[str, Any]]:
    output = list(per_run)
    for system in ("full_context", "rationale"):
        rows = [row for row in per_run if row["system"] == system]
        if len(rows) != 3:
            raise RuntimeError(f"Expected three result rows for {system}")
        aggregate: dict[str, Any] = {"row_type": "mean_sd", "system": system, "model": system_label(system), "seed": "mean_sd"}
        for metric in ("accuracy", "machine_f1", "auroc", "machine_precision", "machine_recall", "runtime_seconds"):
            values = [float(row[metric]) for row in rows]
            aggregate[f"{metric}_mean"] = statistics.mean(values)
            aggregate[f"{metric}_sd"] = statistics.stdev(values)
        if system == "rationale":
            for metric in (
                "selected_fraction", "mean_selected_tokens", "median_selected_tokens",
                "minimum_selected_tokens", "maximum_selected_tokens", "fallback_count",
            ):
                values = [float(row[metric]) for row in rows]
                aggregate[f"{metric}_mean"] = statistics.mean(values)
                aggregate[f"{metric}_sd"] = statistics.stdev(values)
            aggregate["constraint_satisfied_all_seeds"] = all(bool(row["constraint_satisfied"]) for row in rows)
        output.append(aggregate)
    return output


def f1_for_predictions(truth: np.ndarray, predictions: np.ndarray, indices: np.ndarray) -> float:
    y = truth[indices]
    p = predictions[indices]
    tp = int(np.sum((y == 1) & (p == 1)))
    fp = int(np.sum((y == 0) & (p == 1)))
    fn = int(np.sum((y == 1) & (p == 0)))
    denominator = 2 * tp + fp + fn
    return 2 * tp / denominator if denominator else 0.0


def paired_bootstrap_mean_models(
    truth: list[int],
    predictions_a: list[list[int]],
    predictions_b: list[list[int]],
    seed: int,
) -> dict[str, Any]:
    truth_array = np.asarray(truth, dtype=np.int8)
    a_arrays = [np.asarray(values, dtype=np.int8) for values in predictions_a]
    b_arrays = [np.asarray(values, dtype=np.int8) for values in predictions_b]
    all_indices = np.arange(len(truth_array))
    observed_a = statistics.mean(f1_for_predictions(truth_array, values, all_indices) for values in a_arrays)
    observed_b = statistics.mean(f1_for_predictions(truth_array, values, all_indices) for values in b_arrays)
    rng = np.random.default_rng(seed)
    differences = np.empty(BOOTSTRAP_RESAMPLES, dtype=np.float64)
    for index in range(BOOTSTRAP_RESAMPLES):
        sample = rng.integers(0, len(truth_array), size=len(truth_array))
        f1_a = statistics.mean(f1_for_predictions(truth_array, values, sample) for values in a_arrays)
        f1_b = statistics.mean(f1_for_predictions(truth_array, values, sample) for values in b_arrays)
        differences[index] = f1_b - f1_a
    lower, upper = np.quantile(differences, [0.025, 0.975])
    return {
        "definition": "mean seed-wise machine F1(B) - mean seed-wise machine F1(A), paired resampling of examples",
        "observed_difference": observed_b - observed_a,
        "confidence_interval_95": [float(lower), float(upper)],
        "resamples": BOOTSTRAP_RESAMPLES,
        "seed": seed,
    }


def statistical_comparisons(
    test_rows: list[dict[str, Any]],
    tfidf_rows: list[dict[str, Any]],
    full_rows: dict[int, list[dict[str, Any]]],
    rationale_rows: dict[int, list[dict[str, Any]]],
) -> dict[str, Any]:
    truth = [int(row["label_id"]) for row in test_rows]
    tfidf = [[int(row["predicted_label_id"]) for row in tfidf_rows]]
    full = [[int(row["predicted_label_id"]) for row in full_rows[seed]] for seed in SEEDS]
    rationale = [[int(row["predicted_label_id"]) for row in rationale_rows[seed]] for seed in SEEDS]
    aggregate = {
        "rationale_minus_full_context": paired_bootstrap_mean_models(truth, full, rationale, BOOTSTRAP_SEED),
        "rationale_minus_tfidf": paired_bootstrap_mean_models(truth, tfidf, rationale, BOOTSTRAP_SEED + 1),
        "full_context_minus_tfidf": paired_bootstrap_mean_models(truth, tfidf, full, BOOTSTRAP_SEED + 2),
    }
    per_seed: dict[str, dict[str, Any]] = {}
    for seed_index, seed in enumerate(SEEDS):
        per_seed[f"rationale_minus_full_context_seed{seed}"] = paired_bootstrap_f1(
            truth, full[seed_index], rationale[seed_index], resamples=BOOTSTRAP_RESAMPLES, seed=BOOTSTRAP_SEED + 10 + seed_index
        )
        per_seed[f"rationale_seed{seed}_minus_tfidf"] = paired_bootstrap_f1(
            truth, tfidf[0], rationale[seed_index], resamples=BOOTSTRAP_RESAMPLES, seed=BOOTSTRAP_SEED + 20 + seed_index
        )
        per_seed[f"full_context_seed{seed}_minus_tfidf"] = paired_bootstrap_f1(
            truth, tfidf[0], full[seed_index], resamples=BOOTSTRAP_RESAMPLES, seed=BOOTSTRAP_SEED + 30 + seed_index
        )
    return {
        "method": "paired nonparametric bootstrap over the same 1,200 test examples; seeds are not treated as independent examples",
        "aggregate_mean_f1_differences": aggregate,
        "per_seed_differences": per_seed,
    }


def describe(values: list[float]) -> dict[str, float]:
    array = np.asarray(values, dtype=float)
    return {
        "mean": float(np.mean(array)),
        "median": float(np.median(array)),
        "sd": float(np.std(array, ddof=1)) if len(array) > 1 else 0.0,
        "q05": float(np.quantile(array, 0.05)),
        "q25": float(np.quantile(array, 0.25)),
        "q75": float(np.quantile(array, 0.75)),
        "q95": float(np.quantile(array, 0.95)),
    }


def rationale_stability(rationale_rows: dict[int, list[dict[str, Any]]]) -> tuple[dict[str, Any], list[dict[str, Any]], list[dict[str, Any]]]:
    maps = {seed: {str(row["id"]): row for row in rationale_rows[seed]} for seed in SEEDS}
    if len({tuple(sorted(mapping)) for mapping in maps.values()}) != 1:
        raise RuntimeError("Rationale prediction IDs differ across seeds")
    per_example: list[dict[str, Any]] = []
    pair_values: dict[tuple[int, int], list[float]] = defaultdict(list)
    pair_intersections: dict[tuple[int, int], list[float]] = defaultdict(list)
    for example_id in sorted(maps[42]):
        rows = [maps[seed][example_id] for seed in SEEDS]
        visible_counts = {int(row["visible_token_count"]) for row in rows}
        if len(visible_counts) != 1:
            raise RuntimeError(f"Visible token count differs across seeds for {example_id}")
        sets = {seed: set(maps[seed][example_id]["selected_token_indices"]) for seed in SEEDS}
        pairwise = []
        intersections = []
        overlaps = []
        for left, right in combinations(SEEDS, 2):
            intersection = len(sets[left] & sets[right])
            union = len(sets[left] | sets[right])
            jaccard = intersection / union if union else 1.0
            overlap = intersection / min(len(sets[left]), len(sets[right])) if sets[left] and sets[right] else 1.0
            pair_values[(left, right)].append(jaccard)
            pair_intersections[(left, right)].append(float(intersection))
            pairwise.append(jaccard)
            intersections.append(intersection)
            overlaps.append(overlap)
        per_example.append(
            {
                "id": example_id,
                "label_id": int(rows[0]["label_id"]),
                "domain": rows[0]["domain"],
                "generator": rows[0]["generator"],
                "visible_token_count": int(rows[0]["visible_token_count"]),
                "selected_token_count": len(sets[42]),
                "mean_pairwise_jaccard": statistics.mean(pairwise),
                "mean_pairwise_intersection_size": statistics.mean(intersections),
                "mean_pairwise_overlap_coefficient": statistics.mean(overlaps),
                "three_way_intersection_size": len(set.intersection(*sets.values())),
                "three_way_union_size": len(set.union(*sets.values())),
                "prediction_label_agreement": len({int(row["predicted_label_id"]) for row in rows}) == 1,
            }
        )
    summary_rows: list[dict[str, Any]] = []
    all_jaccards = []
    all_intersections = []
    for pair in combinations(SEEDS, 2):
        all_jaccards.extend(pair_values[pair])
        all_intersections.extend(pair_intersections[pair])
        summary_rows.append(
            {
                "seed_pair": f"{pair[0]}-{pair[1]}",
                "n": len(pair_values[pair]),
                **{f"jaccard_{key}": value for key, value in describe(pair_values[pair]).items()},
                **{f"intersection_{key}": value for key, value in describe(pair_intersections[pair]).items()},
            }
        )
    summary_rows.append(
        {
            "seed_pair": "all_pairs",
            "n": len(all_jaccards),
            **{f"jaccard_{key}": value for key, value in describe(all_jaccards).items()},
            **{f"intersection_{key}": value for key, value in describe(all_intersections).items()},
        }
    )
    summary = {
        "scope": "exact visible-token index overlap; not semantic equivalence",
        "support": len(per_example),
        "prediction_label_agreement_rate": float(
            statistics.mean(row["prediction_label_agreement"] for row in per_example)
        ),
        "mean_pairwise_jaccard": describe([row["mean_pairwise_jaccard"] for row in per_example]),
        "mean_pairwise_overlap_coefficient": describe(
            [row["mean_pairwise_overlap_coefficient"] for row in per_example]
        ),
        "mean_pairwise_intersection_size": describe(
            [row["mean_pairwise_intersection_size"] for row in per_example]
        ),
        "three_way_intersection_size": describe([row["three_way_intersection_size"] for row in per_example]),
    }
    return summary, per_example, summary_rows


def stage_tables() -> tuple[list[dict[str, str]], list[dict[str, str]]]:
    with (ROOT / "results/final/metrics/stage1_aggregate.csv").open(newline="", encoding="utf-8") as handle:
        stage1 = list(csv.DictReader(handle))
    with (ROOT / "results/final/metrics/stage2_aggregate.csv").open(newline="", encoding="utf-8") as handle:
        stage2 = list(csv.DictReader(handle))
    return stage1, stage2


def fmt(value: float) -> str:
    return f"{value:.4f}"


def mean_result(per_run: list[dict[str, Any]], system: str, metric: str) -> tuple[float, float]:
    values = [float(row[metric]) for row in per_run if row["system"] == system]
    return statistics.mean(values), statistics.stdev(values)


def weakest_breakdowns(
    domain_rows: list[dict[str, Any]], generator_rows: list[dict[str, Any]]
) -> dict[str, dict[str, Any]]:
    output = {}
    for system in ("tfidf", "full_context", "rationale"):
        system_domains = [row for row in domain_rows if row["system"] == system]
        system_generators = [row for row in generator_rows if row["system"] == system]
        if system == "tfidf":
            domain_values = [(row["domain"], float(row["machine_f1"])) for row in system_domains]
            generator_values = [
                (row["generator"], float(row["machine_recall_detection_rate"])) for row in system_generators
            ]
        else:
            domain_group: dict[str, list[float]] = defaultdict(list)
            generator_group: dict[str, list[float]] = defaultdict(list)
            for row in system_domains:
                domain_group[str(row["domain"])].append(float(row["machine_f1"]))
            for row in system_generators:
                generator_group[str(row["generator"])].append(float(row["machine_recall_detection_rate"]))
            domain_values = [(key, statistics.mean(values)) for key, values in domain_group.items()]
            generator_values = [(key, statistics.mean(values)) for key, values in generator_group.items()]
        output[system] = {
            "weakest_domain": min(domain_values, key=lambda item: item[1])[0],
            "weakest_domain_f1": min(domain_values, key=lambda item: item[1])[1],
            "weakest_generator": min(generator_values, key=lambda item: item[1])[0],
            "weakest_generator_detection_rate": min(generator_values, key=lambda item: item[1])[1],
        }
    return output


def render_statistical_markdown(stats: dict[str, Any]) -> str:
    lines = [
        "# Statistical comparisons",
        "",
        "Differences are machine-class F1(B) − machine-class F1(A). Confidence intervals use 10,000 paired bootstrap resamples of the same 1,200 test examples. The aggregate comparison recomputes each seed's F1 within every resample and then averages across the three frozen seeds; seeds are not treated as independent examples.",
        "",
        "| Comparison | Observed ΔF1 | 95% paired-bootstrap CI |",
        "|---|---:|---:|",
    ]
    labels = {
        "rationale_minus_full_context": "Rationale − full-context",
        "rationale_minus_tfidf": "Rationale − TF-IDF",
        "full_context_minus_tfidf": "Full-context − TF-IDF",
    }
    for key, values in stats["aggregate_mean_f1_differences"].items():
        lower, upper = values["confidence_interval_95"]
        lines.append(f"| {labels[key]} | {values['observed_difference']:.4f} | [{lower:.4f}, {upper:.4f}] |")
    lines.extend(["", "## Seed-specific paired comparisons", "", "| Comparison | ΔF1 | 95% CI |", "|---|---:|---:|"])
    for key, values in stats["per_seed_differences"].items():
        lower, upper = values["confidence_interval_95"]
        lines.append(f"| {key.replace('_', ' ')} | {values['observed_difference']:.4f} | [{lower:.4f}, {upper:.4f}] |")
    lines.extend(["", "No equivalence or statistical-sameness claim is made.", ""])
    return "\n".join(lines)


def render_final_markdown(
    per_run: list[dict[str, Any]],
    stats: dict[str, Any],
    controls: dict[int, dict[str, Any]],
    stability: dict[str, Any],
    weaknesses: dict[str, dict[str, Any]],
    stage1: list[dict[str, str]],
    stage2: list[dict[str, str]],
) -> str:
    full_mean, full_sd = mean_result(per_run, "full_context", "machine_f1")
    rationale_mean, rationale_sd = mean_result(per_run, "rationale", "machine_f1")
    tfidf = next(row for row in per_run if row["system"] == "tfidf")
    stage1_full_512 = next(row for row in stage1 if int(float(row["context_tokens"])) == 512)
    lines = [
        "# Final corrected-pipeline evaluation",
        "",
        "## A. Validation model-selection results",
        "",
        "Stage 1 context selection used validation results only.",
        "",
        "| Context | Mean validation F1 | SD |",
        "|---:|---:|---:|",
    ]
    for row in stage1:
        lines.append(f"| {row['context_tokens']} | {float(row['f1_mean']):.4f} | {float(row['f1_sd']):.4f} |")
    lines.extend(
        [
            "",
            "Stage 2 rationale-budget selection used validation results only.",
            "",
            "| Rationale budget | Mean validation F1 | SD |",
            "|---:|---:|---:|",
        ]
    )
    for row in stage2:
        lines.append(f"| {int(float(row['budget_percent']))}% | {float(row['f1_mean']):.4f} | {float(row['f1_sd']):.4f} |")
    lines.extend(
        [
            f"| Full-context 512 | {float(stage1_full_512['f1_mean']):.4f} | {float(stage1_full_512['f1_sd']):.4f} |",
            "",
            "Final configurations and seed policy were frozen before final test evaluation. The final test split was not used for training, checkpoint selection, context selection, rationale-budget selection, or seed selection for the final corrected pipeline.",
            "",
            "## B. Final test results",
            "",
            "| System | Seed | Accuracy | Precision | Recall | Machine F1 | AUROC |",
            "|---|---:|---:|---:|---:|---:|---:|",
            f"| {system_label('tfidf')} | — | {tfidf['accuracy']:.4f} | {tfidf['machine_precision']:.4f} | {tfidf['machine_recall']:.4f} | {tfidf['machine_f1']:.4f} | {tfidf['auroc']:.4f} |",
        ]
    )
    for system in ("full_context", "rationale"):
        for row in [item for item in per_run if item["system"] == system]:
            lines.append(
                f"| {system_label(system)} | {row['seed']} | {row['accuracy']:.4f} | {row['machine_precision']:.4f} | {row['machine_recall']:.4f} | {row['machine_f1']:.4f} | {row['auroc']:.4f} |"
            )
        values = [item for item in per_run if item["system"] == system]
        means = {metric: statistics.mean(float(row[metric]) for row in values) for metric in ("accuracy", "machine_precision", "machine_recall", "machine_f1", "auroc")}
        sds = {metric: statistics.stdev(float(row[metric]) for row in values) for metric in means}
        lines.append(
            f"| {system_label(system)} | mean ± SD | {means['accuracy']:.4f} ± {sds['accuracy']:.4f} | {means['machine_precision']:.4f} ± {sds['machine_precision']:.4f} | {means['machine_recall']:.4f} ± {sds['machine_recall']:.4f} | {means['machine_f1']:.4f} ± {sds['machine_f1']:.4f} | {means['auroc']:.4f} ± {sds['auroc']:.4f} |"
        )
    comparisons = stats["aggregate_mean_f1_differences"]
    lines.extend(
        [
            "",
            "## Observed performance differences",
            "",
            "| Comparison | Δ machine F1 | 95% paired-bootstrap CI |",
            "|---|---:|---:|",
        ]
    )
    for key, label in (
        ("rationale_minus_full_context", "Rationale − full-context"),
        ("rationale_minus_tfidf", "Rationale − TF-IDF"),
        ("full_context_minus_tfidf", "Full-context − TF-IDF"),
    ):
        value = comparisons[key]
        lower, upper = value["confidence_interval_95"]
        lines.append(f"| {label} | {value['observed_difference']:.4f} | [{lower:.4f}, {upper:.4f}] |")

    rationale_result_rows = [row for row in per_run if row["system"] == "rationale"]
    lines.extend(
        [
            "",
            "## Rationale size and constraint",
            "",
            f"Across seeds, deterministic top-k inference selected {statistics.mean(row['selected_fraction'] for row in rationale_result_rows):.4f} of visible tokens on average. Mean selected-token count was {statistics.mean(row['mean_selected_tokens'] for row in rationale_result_rows):.2f}; median selected-token count was {statistics.mean(row['median_selected_tokens'] for row in rationale_result_rows):.2f}; observed per-document range was {int(min(row['minimum_selected_tokens'] for row in rationale_result_rows))}–{int(max(row['maximum_selected_tokens'] for row in rationale_result_rows))}. There were {int(sum(row['fallback_count'] for row in rationale_result_rows))} empty-selection fallbacks, and the validation constraint was satisfied for all seeds.",
            "",
            "## Rationale diagnostics",
            "",
            "| Seed | Sufficiency drop | Comprehensiveness drop | Learned F1 | Random-control F1 | First-token F1 | Last-token F1 |",
            "|---:|---:|---:|---:|---:|---:|---:|",
        ]
    )
    for seed in SEEDS:
        faith = controls[seed]["faithfulness"]
        lines.append(
            f"| {seed} | {faith['mean_sufficiency_drop']:.4f} | {faith['mean_comprehensiveness_drop']:.4f} | {controls[seed]['learned']['machine_f1']:.4f} | {controls[seed]['random_mean_probability']['machine_f1']:.4f} | {controls[seed]['first']['machine_f1']:.4f} | {controls[seed]['last']['machine_f1']:.4f} |"
        )
    lines.extend(
        [
            "",
            f"Mean exact token-index cross-seed Jaccard was {stability['mean_pairwise_jaccard']['mean']:.4f} (median {stability['mean_pairwise_jaccard']['median']:.4f}); prediction-label agreement across all three seeds was {stability['prediction_label_agreement_rate']:.4f}.",
            "",
            "The predictor is trained on selected evidence, so sufficiency is structurally advantaged; complement-only inputs may be out of distribution. These diagnostics are not standalone proof of faithfulness.",
            "",
            "## Descriptive breakdowns",
            "",
        ]
    )
    for system in ("tfidf", "full_context", "rationale"):
        weakness = weaknesses[system]
        lines.append(
            f"- {system_label(system)}: lowest domain F1 was {weakness['weakest_domain']} ({weakness['weakest_domain_f1']:.4f}); lowest machine-generator detection rate was {weakness['weakest_generator']} ({weakness['weakest_generator_detection_rate']:.4f})."
        )
    lines.extend(
        [
            "",
            "The document-length bands are 1–128, 129–256, 257–512 and >512 surface tokens, computed with the frozen case- and punctuation-preserving tokenizer for every system. Generator-only rows report machine recall/detection rate rather than binary F1.",
            "",
            "Full domain, length and generator results are in `breakdowns/`. Seed-specific confidence intervals are in `statistical_comparisons.md`.",
            "",
            "## Closure",
            "",
            "The final models are closed. Test results were not used to retrain, alter preprocessing, change context or budget, select a seed, or modify any human-study material.",
            "",
        ]
    )
    return "\n".join(lines)


def render_latex(per_run: list[dict[str, Any]], controls: dict[int, dict[str, Any]], stability: dict[str, Any]) -> str:
    tfidf = next(row for row in per_run if row["system"] == "tfidf")
    lines = [
        r"\begin{table}[t]",
        r"\centering",
        r"\caption{Final performance on the source-disjoint test split. Neural aggregate rows show mean $\pm$ sample standard deviation over the three frozen seeds.}",
        r"\label{tab:final}",
        r"\begin{tabular}{llccccc}",
        r"\toprule",
        r"System & Seed & Accuracy & Precision & Recall & F1 & AUROC \\",
        r"\midrule",
        f"TF--IDF & -- & {tfidf['accuracy']:.4f} & {tfidf['machine_precision']:.4f} & {tfidf['machine_recall']:.4f} & {tfidf['machine_f1']:.4f} & {tfidf['auroc']:.4f} \\\\",
    ]
    for system, label in (("full_context", "Full-context BiLSTM"), ("rationale", "HardKuma 40\\%")):
        rows = [row for row in per_run if row["system"] == system]
        for row in rows:
            lines.append(
                f"{label} & {row['seed']} & {row['accuracy']:.4f} & {row['machine_precision']:.4f} & {row['machine_recall']:.4f} & {row['machine_f1']:.4f} & {row['auroc']:.4f} \\\\"
            )
        values = {}
        for metric in ("accuracy", "machine_precision", "machine_recall", "machine_f1", "auroc"):
            numbers = [float(row[metric]) for row in rows]
            values[metric] = (statistics.mean(numbers), statistics.stdev(numbers))
        lines.append(
            f"{label} & Mean $\\pm$ SD & "
            + " & ".join(f"{values[metric][0]:.4f} $\\pm$ {values[metric][1]:.4f}" for metric in ("accuracy", "machine_precision", "machine_recall", "machine_f1", "auroc"))
            + r" \\"
        )
    lines.extend(
        [
            r"\bottomrule",
            r"\end{tabular}",
            r"\end{table}",
            "",
            r"\begin{table}[t]",
            r"\centering",
            r"\caption{Final HardKuma rationale diagnostics. Random is the mean probability over five matched-count random controls.}",
            r"\label{tab:final-rationale-diagnostics}",
            r"\begin{tabular}{lrrrrrr}",
            r"\toprule",
            r"Seed & Suff. drop & Comp. drop & Learned F1 & Random F1 & First F1 & Last F1 \\",
            r"\midrule",
        ]
    )
    for seed in SEEDS:
        faith = controls[seed]["faithfulness"]
        lines.append(
            f"{seed} & {faith['mean_sufficiency_drop']:.4f} & {faith['mean_comprehensiveness_drop']:.4f} & {controls[seed]['learned']['machine_f1']:.4f} & {controls[seed]['random_mean_probability']['machine_f1']:.4f} & {controls[seed]['first']['machine_f1']:.4f} & {controls[seed]['last']['machine_f1']:.4f} \\\\"
        )
    lines.extend(
        [
            r"\bottomrule",
            r"\end{tabular}",
            f"\\par\\smallskip Mean cross-seed token-index Jaccard: {stability['mean_pairwise_jaccard']['mean']:.4f}.",
            r"\end{table}",
            "",
        ]
    )
    return "\n".join(lines)


def verify_outputs(test_rows: list[dict[str, Any]], prediction_paths: list[Path]) -> dict[str, Any]:
    expected_ids = [str(row["id"]) for row in test_rows]
    checks = []
    for path in prediction_paths:
        rows = read_jsonl(path)
        ids = [str(row["id"]) for row in rows]
        passed = len(rows) == 1200 and ids == expected_ids and len(set(ids)) == 1200
        if not passed:
            raise RuntimeError(f"Prediction integrity check failed: {path}")
        probabilities = [machine_probability(row) for row in rows]
        if not all(math.isfinite(value) and 0.0 <= value <= 1.0 for value in probabilities):
            raise RuntimeError(f"Invalid probabilities in {path}")
        checks.append({"path": str(path.relative_to(ROOT)), "rows": len(rows), "ids_in_exact_test_order": True})
    return {"status": "passed", "prediction_files": checks}


def main() -> None:
    os.chdir(ROOT)
    manifest_path = OUT / "freeze_manifest.json"
    if not manifest_path.is_file() or not (OUT / "pre_test_audit.md").is_file():
        raise RuntimeError("Pre-test audit must pass before final test inference")
    manifest = read_json(manifest_path)
    if manifest["final_evaluation"]["status"] != "pre_test_audit_passed_inference_not_started":
        raise RuntimeError("Final evaluation is not in the pre-inference state")
    if any((OUT / "predictions").iterdir()) or any((OUT / "metrics").glob("*_test_metrics.json")):
        raise FileExistsError("Refusing to repeat a started or completed final test evaluation")

    if not torch.backends.mps.is_built() or not torch.backends.mps.is_available():
        raise RuntimeError("MPS is required but unavailable; no CPU fallback is permitted")
    device = torch.device("mps")
    probe = torch.ones(1, device=device)
    if str(probe.device) != "mps:0":
        raise RuntimeError(f"MPS probe used unexpected device: {probe.device}")

    test_rows = load_dataset_splits(DATA, ("test",))["test"]
    expected_ids = [str(row["id"]) for row in test_rows]
    started_all = time.monotonic()
    prediction_paths: list[Path] = []
    per_run: list[dict[str, Any]] = []

    tfidf_rows, tfidf_metrics = evaluate_tfidf(test_rows)
    tfidf_path = OUT / "predictions/tfidf_test_predictions.jsonl"
    write_jsonl(tfidf_path, tfidf_rows)
    write_json(OUT / "metrics/tfidf_test_metrics.json", tfidf_metrics)
    prediction_paths.append(tfidf_path)
    per_run.append(
        {
            "row_type": "per_run", "system": "tfidf", "model": system_label("tfidf"), "seed": None,
            **tfidf_metrics["overall"], "runtime_seconds": tfidf_metrics["runtime_seconds"],
        }
    )
    print(f"completed TF-IDF: F1={tfidf_metrics['overall']['machine_f1']:.4f}", flush=True)

    full_rows: dict[int, list[dict[str, Any]]] = {}
    rationale_rows: dict[int, list[dict[str, Any]]] = {}
    controls: dict[int, dict[str, Any]] = {}
    for seed in SEEDS:
        run_dir = MODEL_ROOT / f"bilstm_full/seed{seed}"
        rows, metrics = evaluate_full_context(run_dir, test_rows, device)
        if [str(row["id"]) for row in rows] != expected_ids:
            raise RuntimeError(f"Full-context seed {seed} changed test order")
        full_rows[seed] = rows
        path = OUT / f"predictions/full_context_seed{seed}_test_predictions.jsonl"
        write_jsonl(path, rows)
        write_json(OUT / f"metrics/full_context_seed{seed}_test_metrics.json", metrics)
        prediction_paths.append(path)
        per_run.append(
            {
                "row_type": "per_run", "system": "full_context", "model": system_label("full_context"),
                "seed": seed, **metrics["overall"], "runtime_seconds": metrics["runtime_seconds"],
            }
        )
        print(f"completed full-context seed {seed}: F1={metrics['overall']['machine_f1']:.4f}", flush=True)

    for seed in SEEDS:
        run_dir = MODEL_ROOT / f"bilstm_hardkuma/seed{seed}"
        rows, metrics, seed_controls, control_rows = evaluate_rationale(run_dir, test_rows, device)
        if [str(row["id"]) for row in rows] != expected_ids:
            raise RuntimeError(f"Rationale seed {seed} changed test order")
        rationale_rows[seed] = rows
        controls[seed] = seed_controls
        path = OUT / f"predictions/rationale_seed{seed}_test_predictions.jsonl"
        write_jsonl(path, rows)
        write_json(OUT / f"metrics/rationale_seed{seed}_test_metrics.json", metrics)
        write_json(OUT / f"rationale_quality/rationale_seed{seed}_controls.json", seed_controls)
        write_jsonl(OUT / f"rationale_quality/rationale_seed{seed}_controls_per_example.jsonl", control_rows)
        prediction_paths.append(path)
        rationale = metrics["rationales"]
        per_run.append(
            {
                "row_type": "per_run", "system": "rationale", "model": system_label("rationale"), "seed": seed,
                **metrics["overall"], "runtime_seconds": metrics["runtime_seconds_including_controls"],
                "selected_fraction": rationale["average_selected_fraction"],
                "mean_selected_tokens": rationale["average_selected_tokens"],
                "median_selected_tokens": rationale["median_selected_tokens"],
                "minimum_selected_tokens": rationale["minimum_selected_tokens"],
                "maximum_selected_tokens": rationale["maximum_selected_tokens"],
                "fallback_count": rationale["empty_selection_fallback_count"],
                "constraint_satisfied": rationale["constraint_satisfied_at_validation_selection"],
            }
        )
        print(
            f"completed rationale seed {seed}: F1={metrics['overall']['machine_f1']:.4f} "
            f"selection={rationale['average_selected_fraction']:.4f}", flush=True
        )

    records = prediction_record_rows(tfidf_rows, full_rows, rationale_rows)
    domain_rows, length_rows, generator_rows = breakdowns(records)
    write_csv(
        OUT / "breakdowns/domain_breakdown.csv",
        add_neural_aggregates(domain_rows, "domain", ["accuracy", "machine_precision", "machine_recall", "machine_f1", "auroc"]),
    )
    write_csv(
        OUT / "breakdowns/length_breakdown.csv",
        add_neural_aggregates(length_rows, "length_band", ["accuracy", "machine_precision", "machine_recall", "machine_f1", "auroc"]),
    )
    write_csv(
        OUT / "breakdowns/generator_breakdown.csv",
        add_neural_aggregates(generator_rows, "generator", ["machine_recall_detection_rate", "mean_machine_probability"]),
    )
    write_json(
        OUT / "breakdowns/length_band_definition.json",
        {"tokenizer": "frozen case- and punctuation-preserving surface tokenizer", "bands": ["1-128", "129-256", "257-512", ">512"], "count_scope": "complete original document before 512-token model truncation"},
    )

    stats = statistical_comparisons(test_rows, tfidf_rows, full_rows, rationale_rows)
    write_json(OUT / "metrics/statistical_comparisons.json", stats)
    (OUT / "statistical_comparisons.md").write_text(render_statistical_markdown(stats), encoding="utf-8")

    stability, stability_per_example, stability_summary_rows = rationale_stability(rationale_rows)
    write_json(OUT / "rationale_quality/cross_seed_stability.json", stability)
    write_jsonl(OUT / "rationale_quality/cross_seed_stability_per_example.jsonl", stability_per_example)
    write_csv(OUT / "rationale_quality/cross_seed_stability_summary.csv", stability_summary_rows)
    aggregate_controls = {
        "seeds": list(SEEDS),
        "mean_learned_f1": statistics.mean(controls[seed]["learned"]["machine_f1"] for seed in SEEDS),
        "mean_random_control_f1": statistics.mean(controls[seed]["random_mean_probability"]["machine_f1"] for seed in SEEDS),
        "mean_first_control_f1": statistics.mean(controls[seed]["first"]["machine_f1"] for seed in SEEDS),
        "mean_last_control_f1": statistics.mean(controls[seed]["last"]["machine_f1"] for seed in SEEDS),
        "mean_sufficiency_drop": statistics.mean(controls[seed]["faithfulness"]["mean_sufficiency_drop"] for seed in SEEDS),
        "mean_comprehensiveness_drop": statistics.mean(controls[seed]["faithfulness"]["mean_comprehensiveness_drop"] for seed in SEEDS),
        "cross_seed_stability": stability,
        "caveat": "The predictor is trained on selected evidence, so sufficiency is structurally advantaged; complement-only inputs may be out of distribution. These are diagnostics, not standalone proof of faithfulness.",
    }
    write_json(OUT / "rationale_quality/aggregate.json", aggregate_controls)

    all_results = aggregate_result_rows(per_run)
    write_csv(OUT / "final_results.csv", all_results)
    stage1, stage2 = stage_tables()
    weaknesses = weakest_breakdowns(domain_rows, generator_rows)
    final_markdown = render_final_markdown(per_run, stats, controls, stability, weaknesses, stage1, stage2)
    (OUT / "final_results.md").write_text(final_markdown, encoding="utf-8")
    (OUT / "final_results_latex.tex").write_text(render_latex(per_run, controls, stability), encoding="utf-8")

    qa = verify_outputs(test_rows, prediction_paths)
    qa.update(
        {
            "mps_built": torch.backends.mps.is_built(),
            "mps_available": torch.backends.mps.is_available(),
            "device_used_by_neural_evaluation": str(device),
            "test_sha256": sha256(DATA / "test.jsonl"),
            "historical_model_directories_modified": False,
            "human_study_materials_modified": False,
        }
    )
    write_json(OUT / "metrics/output_validation.json", qa)

    total_runtime = time.monotonic() - started_all
    manifest["final_evaluation"].update(
        {
            "status": "complete_models_closed",
            "completed_at": datetime.now(timezone.utc).isoformat(),
            "evaluation_git_commit": git_commit(),
            "python_version": platform.python_version(),
            "torch_version": torch.__version__,
            "mps_built": torch.backends.mps.is_built(),
            "mps_available": torch.backends.mps.is_available(),
            "neural_device": str(device),
            "total_runtime_seconds": total_runtime,
            "models_closed_after_test": True,
        }
    )
    write_json(manifest_path, manifest)
    provenance = (OUT / "provenance.md").read_text(encoding="utf-8")
    provenance += "\n".join(
        [
            "",
            "## Completed evaluation",
            "",
            f"- Completed at: `{manifest['final_evaluation']['completed_at']}`",
            f"- Python: `{platform.python_version()}`",
            f"- torch: `{torch.__version__}`",
            f"- Neural device: `{device}` (MPS built and available: true)",
            f"- Total evaluation/analysis runtime: `{total_runtime:.3f}` seconds",
            f"- Prediction files: `{len(prediction_paths)}`; each contains 1,200 rows in exact test order.",
            "- All seven systems were evaluated without seed selection.",
            "- Final status: models closed; no retraining or configuration changes are permitted in response to test results.",
            "",
        ]
    )
    (OUT / "provenance.md").write_text(provenance, encoding="utf-8")

    print(
        json.dumps(
            {
                "status": "complete_models_closed",
                "output": str(OUT),
                "total_runtime_seconds": total_runtime,
                "tfidf_f1": tfidf_metrics["overall"]["machine_f1"],
                "full_context_f1": {seed: overall_metrics(full_rows[seed])["machine_f1"] for seed in SEEDS},
                "rationale_f1": {seed: overall_metrics(rationale_rows[seed])["machine_f1"] for seed in SEEDS},
            },
            indent=2,
        ),
        flush=True,
    )


if __name__ == "__main__":
    main()
