from __future__ import annotations

import argparse

from detectgpt.rationales.transformer_experiment import add_common_arguments, run_experiment


def main() -> None:
    parser = argparse.ArgumentParser(description="Train the matched word-level full-context Transformer classifier.")
    add_common_arguments(parser, rationale=False)
    run_experiment(parser.parse_args(), "full_context")


if __name__ == "__main__":
    main()
