from __future__ import annotations

import argparse
import json
from collections import Counter, defaultdict
from pathlib import Path


SPLITS = ("train", "validation", "test")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Check for source_id leakage across train/validation/test splits."
    )
    parser.add_argument(
        "--data-dir",
        default=Path("data/processed/raid_en_balanced"),
        type=Path,
        help="Dataset directory to check.",
    )
    return parser.parse_args()


def main() -> None:
    data_dir = parse_args().data_dir
    print(f"Checking source leakage in: {data_dir}\n")

    source_to_splits: dict[str, set[str]] = defaultdict(set)
    source_to_rows: dict[str, list[dict[str, object]]] = defaultdict(list)
    for split in SPLITS:
        with (data_dir / f"{split}.jsonl").open("r", encoding="utf-8") as handle:
            for line in handle:
                row = json.loads(line)
                source_id = row["source_id"]
                source_to_splits[source_id].add(split)
                source_to_rows[source_id].append(row)

    leaky_sources = {
        source_id: splits
        for source_id, splits in source_to_splits.items()
        if len(splits) > 1
    }
    print(f"Total source_ids: {len(source_to_splits)}")
    print(f"Leaky source_ids: {len(leaky_sources)}")

    split_overlap_counts = Counter(tuple(sorted(splits)) for splits in leaky_sources.values())
    print("\nLeakage patterns:")
    for pattern, count in split_overlap_counts.items():
        print(f"{pattern}: {count}")

    print("\nExamples:")
    for source_id in list(leaky_sources)[:5]:
        print("-" * 80)
        print("source_id:", source_id)
        print("splits:", sorted(leaky_sources[source_id]))
        for row in source_to_rows[source_id][:5]:
            print(
                {
                    "split": row["split"],
                    "label": row["label"],
                    "generator": row["generator"],
                    "domain": row["domain"],
                    "title": row.get("title"),
                }
            )


if __name__ == "__main__":
    main()
