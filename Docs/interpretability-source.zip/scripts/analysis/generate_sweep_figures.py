from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt


REPO_ROOT = Path(__file__).resolve().parents[2]
FIGURES_DIR = REPO_ROOT / "results" / "final" / "figures"


def configure_plotting() -> None:
    plt.rcParams.update(
        {
            "font.family": "serif",
            "font.size": 9,
            "axes.spines.top": False,
            "axes.spines.right": False,
        }
    )


def context_sweep() -> plt.Figure:
    figure, axis = plt.subplots(figsize=(3.3, 2.3))
    f1 = [0.9397018029514046, 0.9571465908991093, 0.9578297140769612]
    standard_deviation = [0.0016833640867412413, 0.005114803563868069, 0.003014366385131621]
    axis.errorbar(range(3), f1, yerr=standard_deviation, marker="o", capsize=3, color="black", lw=1.2)
    axis.set_xticks(range(3), ["256", "512", "1024"])
    axis.set_xlabel("Visible context (tokens)")
    axis.set_ylabel("Validation F1")
    for index, (coverage, value) in enumerate(zip([42.83, 91.00, 98.17], f1, strict=True)):
        axis.annotate(
            f"{coverage:.1f}% complete",
            (index, value),
            textcoords="offset points",
            xytext=(0, -14),
            ha="center",
            fontsize=7,
            color="0.4",
        )
    axis.set_ylim(0.930, 0.965)
    figure.tight_layout()
    return figure


def budget_sweep() -> plt.Figure:
    figure, axis = plt.subplots(figsize=(3.3, 2.3))
    budgets = [20, 30, 40]
    f1 = [0.9095563647765929, 0.9273805960075079, 0.9408709200170935]
    standard_deviation = [0.017783707739884167, 0.01233628606497798, 0.0024400586060070433]
    axis.errorbar(budgets, f1, yerr=standard_deviation, marker="o", capsize=3, color="black", lw=1.2)
    axis.set_xticks(budgets)
    axis.set_xlabel("Rationale budget (% of visible tokens)")
    axis.set_ylabel("Validation F1")
    axis.set_ylim(0.885, 0.950)
    figure.tight_layout()
    return figure


def main() -> None:
    configure_plotting()
    FIGURES_DIR.mkdir(parents=True, exist_ok=True)
    figures = {
        "context_sweep.pdf": context_sweep(),
        "budget_sweep.pdf": budget_sweep(),
    }
    for filename, figure in figures.items():
        figure.savefig(FIGURES_DIR / filename)
        plt.close(figure)
        print(f"saved={FIGURES_DIR / filename}")


if __name__ == "__main__":
    main()

