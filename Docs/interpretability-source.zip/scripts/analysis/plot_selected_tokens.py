from __future__ import annotations

import json
import math
import statistics as st
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np

REPO_ROOT = Path(__file__).resolve().parents[2]
PREDICTIONS_PATH = (
    REPO_ROOT
    / "outputs"
    / "final_evaluation"
    / "v3_final"
    / "predictions"
    / "rationale_seed44_test_predictions.jsonl"
)
FIGURES_DIR = REPO_ROOT / "results" / "final" / "figures"
PDF_PATH = FIGURES_DIR / "selected_tokens.pdf"
PNG_PATH = FIGURES_DIR / "selected_tokens_preview.png"

CONTEXT_LIMIT_TOKENS = 512


def load_selected_counts(path: Path) -> tuple[list[int], list[bool]]:
    """Per-passage selected-token count and whether the passage hit the visible-context limit.

    Count is len(selected_token_indices). "At the limit" means visible_token_count
    equals the 512-token context cap, i.e. the passage was truncated before selection.
    """
    if not path.is_file():
        raise FileNotFoundError(f"Frozen predictions file not found: {path}")
    counts: list[int] = []
    at_limit: list[bool] = []
    with path.open(encoding="utf-8") as handle:
        for line in handle:
            row = json.loads(line)
            counts.append(len(row["selected_token_indices"]))
            at_limit.append(int(row["visible_token_count"]) == CONTEXT_LIMIT_TOKENS)
    if not counts:
        raise ValueError(f"No rows loaded from {path}")
    return counts, at_limit


def freedman_diaconis_bins(values: list[int]) -> tuple[int, float]:
    """Bin count and width via the Freedman-Diaconis rule, with a safe fallback."""
    n = len(values)
    sorted_values = sorted(values)
    q1 = st.quantiles(sorted_values, n=4, method="inclusive")[0]
    q3 = st.quantiles(sorted_values, n=4, method="inclusive")[2]
    iqr = q3 - q1
    data_range = max(values) - min(values)
    if iqr <= 0:
        bin_width = data_range / math.sqrt(n) if n > 0 else 1.0
    else:
        bin_width = 2 * iqr * (n ** (-1 / 3))
    bin_width = max(bin_width, 1.0)
    num_bins = max(1, math.ceil(data_range / bin_width))
    # Report the realised bin width once matplotlib spaces `num_bins` bins
    # evenly across the data range, not the theoretical FD target width.
    realised_bin_width = data_range / num_bins
    return num_bins, realised_bin_width


def build_figure(counts: list[int], at_limit: list[bool], num_bins: int) -> plt.Figure:
    plt.rcParams.update(
        {
            "font.family": "serif",
            "font.size": 9,
            "axes.spines.top": False,
            "axes.spines.right": False,
        }
    )
    median_count = st.median(counts)
    ceiling_count = max(counts)
    ceiling_n = sum(at_limit)
    edges = np.linspace(min(counts), ceiling_count, num_bins + 1)
    label_fontsize = plt.rcParams["font.size"]

    fig, ax = plt.subplots(figsize=(3.3, 2.0))
    heights, _, _ = ax.hist(counts, bins=edges, color="0.85", edgecolor="0.2", linewidth=0.6)
    max_height = heights.max()
    ax.set_ylim(0, max_height * 1.38)
    ax.set_xlim(edges[0] - 2, edges[-1] + 6)

    # Right-skewed by the 512-token truncation ceiling, so the median (not the
    # mean) marks the typical passage.
    ax.axvline(median_count, color="black", linestyle="--", linewidth=0.8)
    ax.text(
        median_count - 3, max_height * 1.33, f"median = {median_count:g}",
        ha="right", va="top", fontsize=label_fontsize,
    )

    # ceil(0.4 x 512): every passage truncated at the context limit selects
    # exactly this many tokens, which is why it lands as a single value, not a bin.
    ax.axvline(ceiling_count, color="black", linestyle=":", linewidth=0.8)
    ax.text(
        ceiling_count - 3, max_height * 1.33, f"{CONTEXT_LIMIT_TOKENS}-token limit\n(n={ceiling_n})",
        ha="right", va="top", fontsize=label_fontsize, linespacing=1.15,
    )

    ax.set_xlabel("Selected tokens per passage")
    ax.set_ylabel("Passages")
    fig.tight_layout(pad=0.4)
    return fig


def pdf_has_raster_image(path: Path) -> bool:
    data = path.read_bytes()
    return b"/Subtype /Image" in data or b"/Subtype/Image" in data


def main() -> None:
    counts, at_limit = load_selected_counts(PREDICTIONS_PATH)
    n = len(counts)
    mean_count = st.mean(counts)
    median_count = st.median(counts)
    min_count = min(counts)
    max_count = max(counts)
    num_bins, bin_width = freedman_diaconis_bins(counts)

    FIGURES_DIR.mkdir(parents=True, exist_ok=True)
    fig = build_figure(counts, at_limit, num_bins)
    fig.savefig(PDF_PATH)
    fig.savefig(PNG_PATH, dpi=200)
    plt.close(fig)

    raster_found = pdf_has_raster_image(PDF_PATH)

    print(f"source_file={PREDICTIONS_PATH.relative_to(REPO_ROOT)}")
    print("field=len(selected_token_indices) per row")
    print(f"n={n}")
    print(f"mean={mean_count:.4f}")
    print(f"median={median_count}")
    print(f"min={min_count}")
    print(f"max={max_count}")
    print(f"bins={num_bins}")
    print(f"bin_width={bin_width:.4f}")
    print(f"passages_at_context_limit={sum(at_limit)}")
    print(f"pdf_contains_raster_image={raster_found}")
    print(f"saved_pdf={PDF_PATH.relative_to(REPO_ROOT)}")
    print(f"saved_png={PNG_PATH.relative_to(REPO_ROOT)}")


if __name__ == "__main__":
    main()
