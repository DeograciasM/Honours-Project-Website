#!/usr/bin/env python3
"""Freeze and audit the approved final evaluation before model inference."""
from __future__ import annotations

import hashlib
import json
import os
import subprocess
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from detectgpt.data.io import load_dataset_splits
from detectgpt.data.validation import validate_rows, validate_split_files


ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data/processed/raid_en_balanced"
SOURCE_MANIFEST = ROOT / "results/final/manifests/freeze_manifest.json"
MODEL_ROOT = ROOT / "artifacts/models"
OUT = ROOT / "outputs/final_evaluation/raid_en_balanced"
SEEDS = (42, 43, 44)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def git_commit() -> str | None:
    try:
        return subprocess.run(
            ["git", "rev-parse", "HEAD"], cwd=ROOT, check=True, capture_output=True, text=True
        ).stdout.strip()
    except (OSError, subprocess.CalledProcessError):
        return None


def read_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    os.replace(temporary, path)


def exact_text_hash(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def verify_frozen_models(manifest: dict[str, Any]) -> None:
    operating_point = manifest["frozen_operating_point"]
    if operating_point != {
        "context_tokens": 512,
        "rationale_budget_fraction": 0.4,
        "seed_policy": "report_all_predeclared_seeds_and_mean_sd; no preferred seed",
        "seeds": [42, 43, 44],
    }:
        raise RuntimeError(f"Unexpected frozen operating point: {operating_point}")

    if manifest["freeze_rules"]["seed_selection_permitted"]:
        raise RuntimeError("Freeze manifest unexpectedly permits seed selection")
    if manifest["freeze_rules"]["additional_tuning_permitted"]:
        raise RuntimeError("Freeze manifest unexpectedly permits additional tuning")

    artifact_families = {
        "matched_full_context_models": "bilstm_full",
        "rationale_models": "bilstm_hardkuma",
    }
    for family, artifact_family in artifact_families.items():
        records = manifest[family]
        if [int(record["seed"]) for record in records] != list(SEEDS):
            raise RuntimeError(f"Unexpected seed order in {family}")
        for record in records:
            run_dir = MODEL_ROOT / artifact_family / f"seed{record['seed']}"
            checkpoint = run_dir / "model.pt"
            config = run_dir / "config.json"
            if sha256(checkpoint) != record["checkpoint_sha256"]:
                raise RuntimeError(f"Checkpoint hash changed: {checkpoint}")
            if sha256(config) != record["config_sha256"]:
                raise RuntimeError(f"Config hash changed: {config}")
            metrics = read_json(run_dir / "metrics.json")
            if "test" in metrics or (run_dir / "test_predictions.jsonl").exists():
                raise RuntimeError(f"Current final campaign already contains test output: {run_dir}")

    traditional = manifest["traditional_baseline"]
    for key, hash_key in (("artifact", "artifact_sha256"), ("config", "config_sha256")):
        filename = "model.joblib" if key == "artifact" else "config.json"
        path = MODEL_ROOT / "tfidf" / filename
        if sha256(path) != traditional[hash_key]:
            raise RuntimeError(f"Frozen TF-IDF hash changed: {path}")

    tokenizer = ROOT / manifest["preprocessing"]["tokenizer"]
    builder = ROOT / manifest["preprocessing"]["dataset_builder"]
    if sha256(tokenizer) != manifest["preprocessing"]["tokenizer_sha256"]:
        raise RuntimeError("Tokenizer hash changed after freeze")
    if sha256(builder) != manifest["preprocessing"]["dataset_builder_sha256"]:
        raise RuntimeError("Dataset-builder hash changed after freeze")
    if manifest["preprocessing"]["token_pattern"] != r"\w+|[^\w\s]":
        raise RuntimeError("Unexpected frozen token pattern")


def dataset_audit() -> dict[str, Any]:
    splits = ("train", "validation", "test")
    validate_split_files(DATA, splits)
    rows = load_dataset_splits(DATA, splits)
    validate_rows(rows)

    source_sets = {name: {str(row["source_id"]) for row in values} for name, values in rows.items()}
    id_sets = {name: {str(row["id"]) for row in values} for name, values in rows.items()}
    text_sets = {name: {exact_text_hash(str(row["text"])) for row in values} for name, values in rows.items()}
    pair_names = (("train", "validation"), ("train", "test"), ("validation", "test"))
    source_overlap = {f"{left}_vs_{right}": len(source_sets[left] & source_sets[right]) for left, right in pair_names}
    id_overlap = {f"{left}_vs_{right}": len(id_sets[left] & id_sets[right]) for left, right in pair_names}
    exact_duplicate_overlap = {
        f"{left}_vs_{right}": len(text_sets[left] & text_sets[right]) for left, right in pair_names
    }
    if any(source_overlap.values()):
        raise RuntimeError(f"Cross-split source overlap detected: {source_overlap}")
    if any(id_overlap.values()):
        raise RuntimeError(f"Cross-split row-ID overlap detected: {id_overlap}")
    if any(exact_duplicate_overlap.values()):
        raise RuntimeError(f"Cross-split exact-text duplicate overlap detected: {exact_duplicate_overlap}")

    test = rows["test"]
    label_counts = Counter(str(row["label"]) for row in test)
    domain_counts = Counter(str(row["domain"]) for row in test)
    machine_generator_counts = Counter(str(row["generator"]) for row in test if int(row["label_id"]) == 1)
    domain_label_counts = Counter((str(row["domain"]), str(row["label"])) for row in test)
    expected_generators = {"gpt2", "mistral", "mistral-chat", "llama-chat", "chatgpt", "gpt4"}
    if len(test) != 1200 or label_counts != Counter({"human": 600, "machine": 600}):
        raise RuntimeError(f"Unexpected test size/class balance: n={len(test)}, labels={label_counts}")
    if domain_counts != Counter({"abstracts": 300, "books": 300, "news": 300, "poetry": 300}):
        raise RuntimeError(f"Unexpected test domain balance: {domain_counts}")
    if any(domain_label_counts[(domain, label)] != 150 for domain in domain_counts for label in ("human", "machine")):
        raise RuntimeError(f"Unexpected domain/class balance: {domain_label_counts}")
    if set(machine_generator_counts) != expected_generators or any(value != 100 for value in machine_generator_counts.values()):
        raise RuntimeError(f"Unexpected machine-generator composition: {machine_generator_counts}")

    return {
        "status": "passed",
        "split_sizes": {name: len(values) for name, values in rows.items()},
        "file_sha256": {f"{name}.jsonl": sha256(DATA / f"{name}.jsonl") for name in splits},
        "source_set_sizes": {name: len(values) for name, values in source_sets.items()},
        "source_overlap": source_overlap,
        "row_id_overlap": id_overlap,
        "exact_text_duplicate_overlap": exact_duplicate_overlap,
        "test_label_counts": dict(sorted(label_counts.items())),
        "test_domain_counts": dict(sorted(domain_counts.items())),
        "test_domain_label_counts": {
            f"{domain}/{label}": domain_label_counts[(domain, label)]
            for domain in sorted(domain_counts)
            for label in ("human", "machine")
        },
        "test_machine_generator_counts": dict(sorted(machine_generator_counts.items())),
    }


def render_pre_test_audit(audit: dict[str, Any], manifest: dict[str, Any]) -> str:
    domain_counts = audit["test_domain_counts"]
    generator_counts = audit["test_machine_generator_counts"]
    return "\n".join(
        [
            "# Pre-test audit",
            "",
            f"Completed: **{manifest['final_evaluation']['pre_test_audit_completed_at']}**  ",
            "Status: **PASSED**  ",
            "Inference status at audit completion: **not started**",
            "",
            "## Frozen systems",
            "",
            "- Corrected surface-preserving word + character TF-IDF.",
            "- Full-context BiLSTM, 512 visible tokens, seeds 42/43/44.",
            "- HardKuma, 512 visible tokens, 40% deterministic top-k rationale, seeds 42/43/44.",
            "- Seed policy: report every seed and mean ± SD; no preferred seed and no ensemble.",
            "- All frozen checkpoint, config, tokenizer and dataset-builder hashes matched the prior freeze manifest.",
            "- No frozen final-campaign run contained a test metric or test-prediction artifact.",
            "",
            "## Dataset checks",
            "",
            f"- Split sizes: train {audit['split_sizes']['train']:,}; validation {audit['split_sizes']['validation']:,}; test {audit['split_sizes']['test']:,}.",
            f"- Test classes: human {audit['test_label_counts']['human']:,}; machine {audit['test_label_counts']['machine']:,}.",
            f"- Test domains: {', '.join(f'{key} {value}' for key, value in domain_counts.items())}.",
            f"- Machine generators: {', '.join(f'{key} {value}' for key, value in generator_counts.items())}.",
            f"- Cross-split source overlap: {audit['source_overlap']}.",
            f"- Cross-split row-ID overlap: {audit['row_id_overlap']}.",
            f"- Cross-split exact-text duplicate overlap: {audit['exact_text_duplicate_overlap']}.",
            "",
            "## Frozen procedure",
            "",
            "- Stage 1 context selection used validation results only.",
            "- Stage 2 rationale-budget selection used validation results only.",
            "- Final configurations and seed policy were frozen before final test evaluation.",
            "- The final test split was not used for training, checkpoint selection, context selection, rationale-budget selection, or seed selection for the final corrected pipeline.",
            "",
        ]
    )


def render_provenance(audit: dict[str, Any], manifest: dict[str, Any]) -> str:
    return "\n".join(
        [
            "# Final evaluation provenance",
            "",
            f"- Evaluation-decision commit: `{manifest['final_evaluation']['current_git_commit']}`",
            f"- Original freeze time: `{manifest['frozen_at']}`",
            f"- Pre-test audit time: `{manifest['final_evaluation']['pre_test_audit_completed_at']}`",
            "- Dataset directory: `data/processed/raid_en_balanced`",
            f"- Test SHA-256: `{audit['file_sha256']['test.jsonl']}`",
            f"- Tokenizer: `{manifest['preprocessing']['tokenizer']}`",
            f"- Tokenizer SHA-256: `{manifest['preprocessing']['tokenizer_sha256']}`",
            f"- Tokenizer version: {manifest['preprocessing']['tokenizer_version']}",
            f"- Token pattern: `{manifest['preprocessing']['token_pattern']}`",
            "- Final output directory did not exist before this pre-test freeze was written.",
            "- Historical development outputs are not overwritten by this evaluation.",
            "- Human-study materials are outside this task and are not modified.",
            "",
        ]
    )


def main() -> None:
    os.chdir(ROOT)
    if not SOURCE_MANIFEST.is_file():
        raise FileNotFoundError(SOURCE_MANIFEST)
    if OUT.exists():
        raise FileExistsError(f"Refusing to overwrite existing final-evaluation directory: {OUT}")

    source_manifest = read_json(SOURCE_MANIFEST)
    verify_frozen_models(source_manifest)
    audit = dataset_audit()
    now = datetime.now(timezone.utc).isoformat()
    manifest = json.loads(json.dumps(source_manifest))
    manifest["final_evaluation"] = {
        "status": "pre_test_audit_passed_inference_not_started",
        "decision": "approved_existing_raid_en_balanced_test",
        "current_git_commit": git_commit(),
        "pre_test_audit_completed_at": now,
        "primary_metric": "machine_class_f1",
        "secondary_metrics": ["accuracy", "auroc", "machine_precision", "machine_recall"],
        "length_bands": ["1-128", "129-256", "257-512", ">512"],
        "paired_bootstrap": {"resamples": 10000, "seed": 20260818},
        "no_seed_selection": True,
        "test_loaded_for_integrity_audit_only_before_inference": True,
    }
    manifest["dataset_hashes_at_final_evaluation"] = audit["file_sha256"]

    OUT.mkdir(parents=True)
    for directory in ("predictions", "metrics", "breakdowns", "rationale_quality"):
        (OUT / directory).mkdir()
    write_json(OUT / "freeze_manifest.json", manifest)
    write_json(OUT / "metrics/pre_test_audit.json", audit)
    (OUT / "pre_test_audit.md").write_text(render_pre_test_audit(audit, manifest), encoding="utf-8")
    (OUT / "provenance.md").write_text(render_provenance(audit, manifest), encoding="utf-8")

    # Confirm the copied manifest is byte-independent from the historical provenance file.
    if OUT.joinpath("freeze_manifest.json").resolve() == SOURCE_MANIFEST.resolve():
        raise RuntimeError("Final freeze manifest must not overwrite the historical provenance manifest")
    print(json.dumps({"status": "passed", "output": str(OUT), "test_rows": 1200}, indent=2))


if __name__ == "__main__":
    main()
