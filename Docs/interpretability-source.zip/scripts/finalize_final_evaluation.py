#!/usr/bin/env python3
"""Finalize the final evaluation from saved predictions after a reporting-only failure.

This script performs no model loading or inference.
"""
from __future__ import annotations

import json
import os
import platform
import statistics
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import torch


ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
for import_root in (ROOT, SRC):
    if str(import_root) not in sys.path:
        sys.path.insert(0, str(import_root))

from detectgpt.data.io import load_dataset_splits
import scripts.run_final_evaluation as evaluation


OUT = ROOT / "outputs/final_evaluation/v3_final"
DATA = ROOT / "data/processed/raid_en_balanced"
SEEDS = (42, 43, 44)


def load_preserved() -> tuple[
    list[dict[str, Any]],
    list[dict[str, Any]],
    dict[int, list[dict[str, Any]]],
    dict[int, list[dict[str, Any]]],
    dict[int, dict[str, Any]],
    list[dict[str, Any]],
]:
    test_rows = load_dataset_splits(DATA, ("test",))["test"]
    tfidf_rows = evaluation.read_jsonl(OUT / "predictions/tfidf_test_predictions.jsonl")
    full_rows = {
        seed: evaluation.read_jsonl(OUT / f"predictions/full_context_seed{seed}_test_predictions.jsonl")
        for seed in SEEDS
    }
    rationale_rows = {
        seed: evaluation.read_jsonl(OUT / f"predictions/rationale_seed{seed}_test_predictions.jsonl")
        for seed in SEEDS
    }
    controls = {
        seed: evaluation.read_json(OUT / f"rationale_quality/rationale_seed{seed}_controls.json")
        for seed in SEEDS
    }

    per_run: list[dict[str, Any]] = []
    tfidf_metrics = evaluation.read_json(OUT / "metrics/tfidf_test_metrics.json")
    per_run.append(
        {
            "row_type": "per_run",
            "system": "tfidf",
            "model": evaluation.system_label("tfidf"),
            "seed": None,
            **tfidf_metrics["overall"],
            "runtime_seconds": tfidf_metrics["runtime_seconds"],
        }
    )
    for seed in SEEDS:
        metrics = evaluation.read_json(OUT / f"metrics/full_context_seed{seed}_test_metrics.json")
        per_run.append(
            {
                "row_type": "per_run",
                "system": "full_context",
                "model": evaluation.system_label("full_context"),
                "seed": seed,
                **metrics["overall"],
                "runtime_seconds": metrics["runtime_seconds"],
            }
        )
    for seed in SEEDS:
        metrics = evaluation.read_json(OUT / f"metrics/rationale_seed{seed}_test_metrics.json")
        rationale = metrics["rationales"]
        per_run.append(
            {
                "row_type": "per_run",
                "system": "rationale",
                "model": evaluation.system_label("rationale"),
                "seed": seed,
                **metrics["overall"],
                "runtime_seconds": metrics["runtime_seconds_including_controls"],
                "selected_fraction": rationale["average_selected_fraction"],
                "mean_selected_tokens": rationale["average_selected_tokens"],
                "median_selected_tokens": rationale["median_selected_tokens"],
                "minimum_selected_tokens": rationale["minimum_selected_tokens"],
                "maximum_selected_tokens": rationale["maximum_selected_tokens"],
                "fallback_count": rationale["empty_selection_fallback_count"],
                "constraint_satisfied": rationale["constraint_satisfied_at_validation_selection"],
            }
        )
    return test_rows, tfidf_rows, full_rows, rationale_rows, controls, per_run


def main() -> None:
    os.chdir(ROOT)
    started = time.monotonic()
    manifest_path = OUT / "freeze_manifest.json"
    manifest = evaluation.read_json(manifest_path)
    if manifest["final_evaluation"]["status"] != "pre_test_audit_passed_inference_not_started":
        raise RuntimeError("Unexpected evaluation state; refusing analysis-only recovery")

    test_rows, tfidf_rows, full_rows, rationale_rows, controls, per_run = load_preserved()
    prediction_paths = [OUT / "predictions/tfidf_test_predictions.jsonl"]
    prediction_paths.extend(OUT / f"predictions/full_context_seed{seed}_test_predictions.jsonl" for seed in SEEDS)
    prediction_paths.extend(OUT / f"predictions/rationale_seed{seed}_test_predictions.jsonl" for seed in SEEDS)
    evaluation.verify_outputs(test_rows, prediction_paths)

    records = evaluation.prediction_record_rows(tfidf_rows, full_rows, rationale_rows)
    domain_rows, length_rows, generator_rows = evaluation.breakdowns(records)
    evaluation.write_csv(
        OUT / "breakdowns/domain_breakdown.csv",
        evaluation.add_neural_aggregates(
            domain_rows,
            "domain",
            ["accuracy", "machine_precision", "machine_recall", "machine_f1", "auroc"],
        ),
    )
    evaluation.write_csv(
        OUT / "breakdowns/length_breakdown.csv",
        evaluation.add_neural_aggregates(
            length_rows,
            "length_band",
            ["accuracy", "machine_precision", "machine_recall", "machine_f1", "auroc"],
        ),
    )
    evaluation.write_csv(
        OUT / "breakdowns/generator_breakdown.csv",
        evaluation.add_neural_aggregates(
            generator_rows,
            "generator",
            ["machine_recall_detection_rate", "mean_machine_probability"],
        ),
    )
    evaluation.write_json(
        OUT / "breakdowns/length_band_definition.json",
        {
            "tokenizer": "frozen case- and punctuation-preserving surface tokenizer",
            "bands": ["1-128", "129-256", "257-512", ">512"],
            "count_scope": "complete original document before 512-token model truncation",
        },
    )

    stats = evaluation.statistical_comparisons(test_rows, tfidf_rows, full_rows, rationale_rows)
    evaluation.write_json(OUT / "metrics/statistical_comparisons.json", stats)
    (OUT / "statistical_comparisons.md").write_text(
        evaluation.render_statistical_markdown(stats), encoding="utf-8"
    )

    stability, stability_per_example, stability_summary_rows = evaluation.rationale_stability(rationale_rows)
    evaluation.write_json(OUT / "rationale_quality/cross_seed_stability.json", stability)
    evaluation.write_jsonl(
        OUT / "rationale_quality/cross_seed_stability_per_example.jsonl", stability_per_example
    )
    evaluation.write_csv(
        OUT / "rationale_quality/cross_seed_stability_summary.csv", stability_summary_rows
    )
    aggregate_controls = {
        "seeds": list(SEEDS),
        "mean_learned_f1": statistics.mean(controls[seed]["learned"]["machine_f1"] for seed in SEEDS),
        "mean_random_control_f1": statistics.mean(
            controls[seed]["random_mean_probability"]["machine_f1"] for seed in SEEDS
        ),
        "mean_first_control_f1": statistics.mean(controls[seed]["first"]["machine_f1"] for seed in SEEDS),
        "mean_last_control_f1": statistics.mean(controls[seed]["last"]["machine_f1"] for seed in SEEDS),
        "mean_sufficiency_drop": statistics.mean(
            controls[seed]["faithfulness"]["mean_sufficiency_drop"] for seed in SEEDS
        ),
        "mean_comprehensiveness_drop": statistics.mean(
            controls[seed]["faithfulness"]["mean_comprehensiveness_drop"] for seed in SEEDS
        ),
        "cross_seed_stability": stability,
        "caveat": (
            "The predictor is trained on selected evidence, so sufficiency is structurally advantaged; "
            "complement-only inputs may be out of distribution. These are diagnostics, not standalone proof of faithfulness."
        ),
    }
    evaluation.write_json(OUT / "rationale_quality/aggregate.json", aggregate_controls)

    evaluation.write_csv(OUT / "final_results.csv", evaluation.aggregate_result_rows(per_run))
    stage1, stage2 = evaluation.stage_tables()
    weaknesses = evaluation.weakest_breakdowns(domain_rows, generator_rows)
    (OUT / "final_results.md").write_text(
        evaluation.render_final_markdown(per_run, stats, controls, stability, weaknesses, stage1, stage2),
        encoding="utf-8",
    )
    (OUT / "final_results_latex.tex").write_text(
        evaluation.render_latex(per_run, controls, stability), encoding="utf-8"
    )

    qa = evaluation.verify_outputs(test_rows, prediction_paths)
    qa.update(
        {
            "mps_built_at_finalization": torch.backends.mps.is_built(),
            "neural_device_recorded_in_all_metrics": all(
                evaluation.read_json(OUT / f"metrics/{family}_seed{seed}_test_metrics.json")["device"] == "mps"
                for family in ("full_context", "rationale")
                for seed in SEEDS
            ),
            "test_sha256": evaluation.sha256(DATA / "test.jsonl"),
            "historical_model_directories_modified": False,
            "human_study_materials_modified": False,
            "reporting_recovery_used_saved_predictions_only": True,
        }
    )
    evaluation.write_json(OUT / "metrics/output_validation.json", qa)

    model_runtime_sum = sum(float(row["runtime_seconds"]) for row in per_run)
    analysis_runtime = time.monotonic() - started
    manifest["final_evaluation"].update(
        {
            "status": "complete_models_closed",
            "completed_at": datetime.now(timezone.utc).isoformat(),
            "evaluation_git_commit": evaluation.git_commit(),
            "python_version": platform.python_version(),
            "torch_version": torch.__version__,
            "neural_device": "mps",
            "model_evaluation_runtime_seconds_sum": model_runtime_sum,
            "analysis_recovery_runtime_seconds": analysis_runtime,
            "models_closed_after_test": True,
            "scientific_issue": False,
            "reporting_issue": (
                "Initial post-inference aggregation encountered undefined AUROC in a one-class length band. "
                "The aggregation code was corrected to record AUROC as undefined, and finalization used only "
                "the already-preserved predictions; no model was rerun."
            ),
        }
    )
    evaluation.write_json(manifest_path, manifest)
    provenance_path = OUT / "provenance.md"
    provenance = provenance_path.read_text(encoding="utf-8")
    provenance += "\n".join(
        [
            "",
            "## Completed evaluation",
            "",
            f"- Completed at: `{manifest['final_evaluation']['completed_at']}`",
            f"- Python: `{platform.python_version()}`",
            f"- torch: `{torch.__version__}`",
            "- Neural device recorded in all six model metrics: `mps`.",
            f"- Sum of seven per-system evaluation runtimes: `{model_runtime_sum:.3f}` seconds.",
            f"- Analysis-only recovery runtime: `{analysis_runtime:.3f}` seconds.",
            "- Prediction files: `7`; each contains 1,200 rows in exact test order.",
            "- A reporting-only aggregation error occurred after all inference completed: AUROC was undefined in a one-class length band. The correction records that AUROC as undefined. Finalization loaded only preserved predictions and did not rerun a model.",
            "- Scientific status: no model/configuration issue; all models are closed.",
            "",
        ]
    )
    provenance_path.write_text(provenance, encoding="utf-8")

    print(
        json.dumps(
            {
                "status": "complete_models_closed",
                "reporting_recovery_only": True,
                "model_reruns": 0,
                "output": str(OUT),
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
