from __future__ import annotations

import argparse
import copy
import json
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

import torch
from torch import nn

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from detectgpt.baselines.bilstm import FullContextBiLSTM
from detectgpt.data.io import load_dataset_splits, write_jsonl
from detectgpt.data.validation import validate_rows, validate_split_files
from detectgpt.evaluation.metrics import evaluate_split
from detectgpt.rationales.kuma_model import load_pretrained_embeddings
from detectgpt.rationales.vocab import build_vocabulary
from detectgpt.utils.device import DEVICE_CHOICES, resolve_device
from detectgpt.utils.seed import set_seed
from scripts.train_kuma_rationale import TokenDataset, make_loader


def git_commit() -> str | None:
    """Return the current Git commit when available."""
    try:
        return subprocess.run(
            ["git", "rev-parse", "HEAD"], check=True, capture_output=True, text=True
        ).stdout.strip()
    except (OSError, subprocess.CalledProcessError):
        return None


def save_json(path: Path, payload: dict[str, Any]) -> None:
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def evaluate(model: FullContextBiLSTM, loader: torch.utils.data.DataLoader, device: torch.device):
    model.eval()
    rows, predictions, scores, output_rows = [], [], [], []
    with torch.no_grad():
        for batch in loader:
            probabilities = torch.softmax(model(batch["input_ids"].to(device), batch["mask"].to(device)), dim=1)[:, 1]
            for example, probability in zip(batch["examples"], probabilities.tolist(), strict=True):
                prediction = int(probability >= 0.5)
                rows.append(example.row)
                predictions.append(prediction)
                scores.append(probability)
                output_rows.append(
                    {
                        **example.row,
                        "predicted_label_id": prediction,
                        "predicted_label": "machine" if prediction else "human",
                        "probability_machine": probability,
                        "prediction_mode": "full_context_bilstm",
                    }
                )
    return evaluate_split(rows, predictions, scores), output_rows


def run(args: argparse.Namespace) -> dict[str, Any]:
    set_seed(args.seed)
    started = time.monotonic()
    output_dir = args.output_dir
    if output_dir.exists() and any(output_dir.iterdir()):
        raise FileExistsError(f"Refusing to overwrite {output_dir}")
    requested_splits = ("train", "validation") if args.validation_only else ("train", "validation", "test")
    rows = load_dataset_splits(args.data_dir, requested_splits)
    validate_split_files(args.data_dir, requested_splits); validate_rows(rows)
    limits = {"train": args.limit_train, "validation": args.limit_val, "test": args.limit_test}
    rows = {name: values[: limits[name]] if limits[name] is not None else values for name, values in rows.items()}
    vocab = build_vocabulary((row["text"] for row in rows["train"]), args.max_vocab, args.min_freq)
    loaders = {
        name: make_loader(TokenDataset(values, vocab, args.max_tokens), args.batch_size, name == "train", args.seed, vocab.pad_id)
        for name, values in rows.items()
    }
    pretrained = None
    embedding_stats = None
    if args.embeddings_path:
        pretrained, embedding_stats = load_pretrained_embeddings(args.embeddings_path, vocab)
    device = resolve_device(getattr(args, "device", "auto"))
    model = FullContextBiLSTM(
        len(vocab), args.embed_dim, args.hidden_dim, args.dropout, pretrained, args.freeze_embeddings, vocab.pad_id
    ).to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr)
    loss_fn = nn.CrossEntropyLoss()
    best_f1, best_epoch, best_state = -1.0, 0, None
    history = []
    for epoch in range(1, args.epochs + 1):
        model.train()
        total_loss, count = 0.0, 0
        for batch in loaders["train"]:
            optimizer.zero_grad()
            labels = batch["labels"].to(device)
            loss = loss_fn(model(batch["input_ids"].to(device), batch["mask"].to(device)), labels)
            if not torch.isfinite(loss):
                raise FloatingPointError("Non-finite full-context BiLSTM loss")
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), args.max_grad_norm)
            optimizer.step()
            total_loss += float(loss.item()) * labels.size(0)
            count += labels.size(0)
        validation, _ = evaluate(model, loaders["validation"], device)
        val_f1 = validation["overall"]["machine_f1"]
        history.append({"epoch": epoch, "loss": total_loss / count, "validation_f1": val_f1})
        print(f"epoch={epoch} loss={total_loss / count:.4f} val_f1={val_f1:.4f}")
        if val_f1 > best_f1:
            best_f1, best_epoch, best_state = val_f1, epoch, copy.deepcopy(model.state_dict())
    model.load_state_dict(best_state)
    metrics: dict[str, Any] = {"best_epoch": best_epoch, "best_val_f1": best_f1, "train_history": history}
    predictions = {}
    for split in (("validation",) if args.validation_only else ("validation", "test")):
        metrics[split], predictions[split] = evaluate(model, loaders[split], device)
    elapsed = time.monotonic() - started
    parameter_count = sum(parameter.numel() for parameter in model.parameters())
    config = {
        "run_name": args.run_name,
        "device_requested": getattr(args, "device", "auto"), "device": str(device),
        "model": {"type": "full_context_bilstm", "embed_dim": model.embedding.embedding_dim, "hidden_dim": args.hidden_dim, "dropout": args.dropout},
        "data_dir": str(args.data_dir), "dataset_version": args.data_dir.name, "git_commit": git_commit(),
        "seed": args.seed, "epochs": args.epochs, "batch_size": args.batch_size, "lr": args.lr,
        "max_tokens": args.max_tokens, "max_vocab": args.max_vocab, "min_freq": args.min_freq,
        "embeddings_path": str(args.embeddings_path) if args.embeddings_path else None,
        "freeze_embeddings": args.freeze_embeddings, "embedding_stats": embedding_stats,
        "best_epoch": best_epoch, "best_val_f1": best_f1, "parameter_count": parameter_count,
        "training_time_seconds": elapsed, "limits": limits,
    }
    metrics.update({"parameter_count": parameter_count, "training_time_seconds": elapsed, "device": str(device)})
    output_dir.mkdir(parents=True, exist_ok=True)
    save_json(output_dir / "config.json", config)
    save_json(output_dir / "metrics.json", metrics)
    save_json(output_dir / "vocab.json", {"token_to_id": vocab.to_dict()})
    torch.save({"model_state_dict": {key: value.cpu() for key, value in model.state_dict().items()}, "config": config}, output_dir / "model.pt")
    for split in predictions:
        write_jsonl(output_dir / f"{split}_predictions.jsonl", predictions[split])
    return metrics


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Train the matched full-context BiLSTM baseline.")
    parser.add_argument("--data-dir", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--run-name", default="full_context_bilstm")
    parser.add_argument("--device", default="auto", choices=DEVICE_CHOICES)
    parser.add_argument("--embeddings-path", default=None, type=Path)
    parser.add_argument("--freeze-embeddings", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument("--epochs", default=25, type=int)
    parser.add_argument("--batch-size", default=32, type=int)
    parser.add_argument("--lr", default=4e-4, type=float)
    parser.add_argument("--max-grad-norm", default=5.0, type=float)
    parser.add_argument("--max-tokens", default=256, type=int)
    parser.add_argument("--max-vocab", default=10000, type=int)
    parser.add_argument("--min-freq", default=2, type=int)
    parser.add_argument("--embed-dim", default=300, type=int)
    parser.add_argument("--hidden-dim", default=128, type=int)
    parser.add_argument("--dropout", default=0.2, type=float)
    parser.add_argument("--seed", default=42, type=int)
    parser.add_argument("--limit-train", default=None, type=int)
    parser.add_argument("--limit-val", default=None, type=int)
    parser.add_argument("--limit-test", default=None, type=int)
    parser.add_argument("--validation-only", action="store_true")
    return parser.parse_args()


if __name__ == "__main__":
    run(parse_args())
