#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import FeatureUnion, Pipeline

from detectgpt.data.io import load_dataset_splits, write_jsonl
from detectgpt.data.validation import validate_rows, validate_split_files
from detectgpt.evaluation.metrics import evaluate_split


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Train one corrected-surface TF-IDF candidate using validation only."
    )
    parser.add_argument("--data-dir", type=Path, required=True)
    parser.add_argument("--out-dir", type=Path, required=True)
    parser.add_argument("--mode", choices=("word", "char", "combined"), required=True)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if args.out_dir.exists():
        raise FileExistsError(f"Refusing to overwrite existing output directory: {args.out_dir}")

    rows = load_dataset_splits(args.data_dir, ("train", "validation"))
    validate_split_files(args.data_dir, ("train", "validation"))
    validate_rows(rows)
    word = TfidfVectorizer(
        analyzer="word", ngram_range=(1, 2), max_features=100_000, min_df=2, lowercase=True
    )
    character = TfidfVectorizer(
        analyzer="char_wb", ngram_range=(3, 5), max_features=100_000, min_df=2, lowercase=True
    )
    features = {
        "word": word,
        "char": character,
        "combined": FeatureUnion([("word", word), ("char", character)]),
    }[args.mode]
    model = Pipeline(
        [
            ("tfidf", features),
            (
                "classifier",
                LogisticRegression(
                    class_weight="balanced", max_iter=1000, solver="liblinear", random_state=42
                ),
            ),
        ]
    )
    model.fit(
        [row["text"] for row in rows["train"]],
        [row["label_id"] for row in rows["train"]],
    )

    validation = rows["validation"]
    predictions = model.predict([row["text"] for row in validation]).astype(int).tolist()
    probabilities = model.predict_proba([row["text"] for row in validation])[:, 1].tolist()
    metrics = {
        "mode": args.mode,
        "splits_loaded": ["train", "validation"],
        "test_split_loaded": False,
        "validation": evaluate_split(validation, predictions, probabilities),
    }
    args.out_dir.mkdir(parents=True)
    (args.out_dir / "metrics.json").write_text(
        json.dumps(metrics, indent=2) + "\n", encoding="utf-8"
    )
    write_jsonl(
        args.out_dir / "validation_predictions.jsonl",
        [
            {
                "id": row["id"],
                "label_id": row["label_id"],
                "predicted_label_id": prediction,
                "machine_probability": probability,
            }
            for row, prediction, probability in zip(
                validation, predictions, probabilities, strict=True
            )
        ],
    )
    print(json.dumps(metrics["validation"]["overall"], indent=2))


if __name__ == "__main__":
    main()
