# Final experiment configurations

These TOML files are authoritative, human- and machine-readable records of the frozen final experiments. The historical training scripts use CLI arguments rather than config files; exact command templates are in `docs/final_pipeline_manifest.md` and the root README. Do not change these records to describe a new run: create a separate experiment config instead.

All paths are repository-relative. Kaggle paths embedded in historical per-run JSON files are deliberately normalized here to the corresponding repository package/download locations.

